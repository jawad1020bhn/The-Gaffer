# OpenFoot Manager 0.4.0 — complete UI source

This is a **source-code archive**, not an installer, executable or compiled game.
It contains the complete tracked frontend and the supporting files needed to understand,
edit and review the UI. Original source paths are preserved.

## Snapshot

- Repository: https://github.com/jawad1020bhn/the-gaffer-v0.4
- Commit: `b38e5043e3321d9ae6e7399ae9bdbd184aaecc1d`
- Source branch: `arena/5b8fdec4-the-gaffer-v0-4`
- 1171 original files; 305 non-test TSX files; 12 locales.
- See **UI_FILE_MAP.md** for every file and **SOURCE_MANIFEST.json** for hashes.

## Included

All of `src/`: pages, feature components, shared primitives, app shell, hooks, theme,
CSS/design tokens, stores, generated TypeScript IPC types, services, utilities,
translations, tests and development harnesses. Also public assets, brand/reference
images, app icons, frontend build configuration and the exact npm dependency lock,
relevant UI checks/scripts, design documentation, and the GPLv3 license.

A few small `src-tauri` files are included because the UI uses them: window/version
configuration, frontend capabilities, app icons, and the colour palette read by a
UI test. **The Rust implementation and full desktop build environment are not included.**
No `node_modules`, build output, Git history, credentials, game saves or `.ofm` databases
are included. npm packages (including bundled fonts) are restored from the lockfile.

## Browse or edit

Open this folder in an editor. Start with `src/App.css`, `src/components/ui/`,
`src/components/gameShell/`, then the relevant feature folder. `docs/DESIGN_SYSTEM.md`
explains the tokens and primitives. Some original documentation links point to files
outside this UI-only archive; those remain in the full repository linked above.

## Preview the backend-free style guide

Use Node.js 22.12+ (or a supported newer Node release), then run:

```sh
npm ci
npm run dev -- --host 127.0.0.1
```

Open **http://localhost:1420/style-guide.html**. This guide works without the Rust
backend. The root app route needs Tauri commands for actual game data; this archive
is not a playable standalone browser game. Stop the server with Ctrl+C.

Run the targeted checks that passed on this archive:

```sh
npm exec -- vitest run src/dev/styleGuide/StyleGuide.test.tsx src/designSystem.test.ts src/lib/uiDensity.test.ts src/context/ThemeContext.test.tsx --maxWorkers=2
```

The style-guide tests render without Tauri. They log caught position-loading
warnings because the backend is absent; these do not fail the tests.

## Full app and full test suite

Use the complete repository for `npm run tauri dev`, a desktop release, the full
frontend type-check/build, and all tests. `npm run build` and `npm test` have a
pre-hook that generates `src/dev/pageHarness/fixture.generated.ts` using the Rust
workspace. That generated file is intentionally not committed and is absent here.
Do not create an empty substitute just to silence the hook. A production build of
the style-guide entry also needs this fixture: its entry dynamically imports the
page harness, so the bundler resolves the fixture even though the guide itself
does not use it. Some checks also read Rust sources or CI files that are
intentionally outside this source subset.

The npm scripts and configuration are copied unchanged, so commands outside the
scope above may require the full repository. No claim is made that this archive is
a complete desktop application source tree.

## Validation

See **VALIDATION.md** for the checks actually run. Source files are byte-for-byte
copies of the recorded commit. `SHA256SUMS.txt` can be checked with
`sha256sum -c SHA256SUMS.txt` from this folder.

## License

The original project license is preserved in `LICENSE.md` (GNU GPL v3). This archive
does not relicense the source or include the optional EA FC data package.
