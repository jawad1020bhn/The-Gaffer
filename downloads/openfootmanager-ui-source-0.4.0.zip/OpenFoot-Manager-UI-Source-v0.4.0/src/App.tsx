import { useEffect, lazy, Suspense } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { isTauri } from "@tauri-apps/api/core";
import { useSettingsStore } from "./store/settingsStore";
import i18n, { changeAppLanguage } from "./i18n";
import { formatAppVersion } from "./lib/appVersion";
import { rootFontSizeFor } from "./lib/uiScale";
import { densityClassFor } from "./lib/uiDensity";
import "./App.css";

const MainMenu = lazy(() => import("./pages/MainMenu"));
const TeamSelection = lazy(() => import("./pages/TeamSelection"));
const Dashboard = lazy(() => import("./pages/Dashboard"));
const MatchSimulation = lazy(() => import("./pages/MatchSimulation"));
const Settings = lazy(() => import("./pages/Settings"));
const SimLab = lazy(() => import("./pages/SimLab"));
const WorldEditorPage = lazy(() => import("./pages/WorldEditor"));

function LazyFallback() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-page">
      <div className="w-8 h-8 border-4 border-selected border-t-transparent rounded-full animate-spin" />
    </div>
  );
}

function App() {
  const { settings, loaded, loadSettings } = useSettingsStore();

  useEffect(() => {
    if (!loaded) loadSettings();
  }, [loaded, loadSettings]);

  // The static title in tauri.conf.json cannot carry the channel/commit, so the
  // real one is applied here from the build-time version constants.
  useEffect(() => {
    if (!isTauri()) return;

    void (async () => {
      try {
        const { getCurrentWindow } = await import("@tauri-apps/api/window");
        await getCurrentWindow().setTitle(`Openfoot Manager ${formatAppVersion()}`);
      } catch (error) {
        console.error("Failed to set window title:", error);
      }
    })();
  }, []);

  useEffect(() => {
    const size = rootFontSizeFor(settings.ui_scale);
    document.documentElement.style.fontSize = size;
  }, [settings.ui_scale]);

  useEffect(() => {
    document.documentElement.classList.toggle("high-contrast", settings.high_contrast);
  }, [settings.high_contrast]);

  useEffect(() => {
    document.documentElement.classList.toggle(
      "density-compact",
      densityClassFor(settings.ui_density) === "density-compact",
    );
  }, [settings.ui_density]);

  // Apply saved language from settings once loaded (overrides OS detection)
  useEffect(() => {
    if (loaded && settings.language && settings.language !== i18n.language) {
      void changeAppLanguage(settings.language);
    }
  }, [loaded, settings.language]);

  return (
    <BrowserRouter>
      <Suspense fallback={<LazyFallback />}>
        <Routes>
          <Route path="/" element={<MainMenu />} />
          <Route path="/select-team" element={<TeamSelection />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/match" element={<MatchSimulation />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/sim-lab" element={<SimLab />} />
          <Route path="/world-editor" element={<WorldEditorPage />} />
        </Routes>
      </Suspense>
    </BrowserRouter>
  );
}

export default App;
