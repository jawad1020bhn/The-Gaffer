import { useCallback } from "react";
import { useTranslation } from "react-i18next";
import { Plus, Trash2, Users } from "lucide-react";

import type { GameStateData, PlayerData, TeamData } from "../../store/gameStore";
import {
  setPlayerTrainingFocus,
  setTrainingGroups,
  type TrainingGroupData,
} from "../../services/trainingService";
import { translatePositionAbbreviation } from "../squad/SquadTab.helpers";
import { condColor } from "../../lib/playerConditionDisplay";
import { Card, CardBody, CardHeader, Select } from "../ui";
import {
  buildPlayerGroupMap,
  reassignPlayerTrainingGroup,
  sortTrainingRoster,
} from "./trainingGroupsModel";
import { naturalPositionOf } from "../../lib/positions";
import { usePositionTable } from "../../hooks/usePositionGroups";

type TrainingGroup = TrainingGroupData;

interface TrainingGroupsCardProps {
  team: TeamData | null;
  onGameUpdate?: (state: GameStateData) => void;
  roster: PlayerData[];
  isSaving: boolean;
  setIsSaving: (value: boolean) => void;
  trainingFocusIds: readonly string[];
  trainingFocusIcons: Record<string, React.ReactNode>;
}

export default function TrainingGroupsCard({
  team,
  onGameUpdate,
  roster,
  isSaving,
  setIsSaving,
  trainingFocusIds,
  trainingFocusIcons,
}: TrainingGroupsCardProps) {
  const { t } = useTranslation();
  const positions = usePositionTable();
  const groups: TrainingGroup[] = team?.training_groups ?? [];
  const teamFocus = team?.training_focus || "Physical";

  const saveGroups = useCallback(
    async (nextGroups: TrainingGroup[]) => {
      setIsSaving(true);
      try {
        const updated = await setTrainingGroups(nextGroups);
        onGameUpdate?.(updated);
      } catch (error) {
        console.error("Failed to save training groups:", error);
      } finally {
        setIsSaving(false);
      }
    },
    [onGameUpdate, setIsSaving],
  );

  const addGroup = () => {
    if (groups.length >= 5) {
      return;
    }

    const index = groups.length;
    const defaultName = t(`training.groups.defaultGroupNames.${index}`);

    saveGroups([
      ...groups,
      {
        id: `grp_${Date.now()}`,
        name: defaultName,
        focus: "Physical",
        player_ids: [],
      },
    ]);
  };

  const removeGroup = (groupId: string) => {
    saveGroups(groups.filter((group) => group.id !== groupId));
  };

  const updateGroupFocus = (groupId: string, focus: string) => {
    saveGroups(groups.map((group) => (group.id === groupId ? { ...group, focus } : group)));
  };

  const updateGroupName = (groupId: string, name: string) => {
    saveGroups(groups.map((group) => (group.id === groupId ? { ...group, name } : group)));
  };

  const setPlayerFocus = async (playerId: string, focus: string) => {
    setIsSaving(true);
    try {
      const updated = await setPlayerTrainingFocus(playerId, focus || null);
      onGameUpdate?.(updated);
    } catch (error) {
      console.error("Failed to set player training focus:", error);
    } finally {
      setIsSaving(false);
    }
  };

  const setPlayerGroup = (playerId: string, groupId: string) => {
    saveGroups(reassignPlayerTrainingGroup(groups, playerId, groupId));
  };

  const playerGroupMap = buildPlayerGroupMap(groups);
  const sortedRoster = sortTrainingRoster(roster, positions);

  return (
    <Card>
      <CardHeader
        action={
          groups.length < 5 ? (
            <button
              type="button"
              onClick={addGroup}
              disabled={isSaving}
              className="flex items-center gap-1.5 text-caption font-heading font-bold uppercase tracking-label text-selected hover:text-selected transition-colors disabled:opacity-50"
            >
              <Plus className="w-4 h-4" /> {t("training.groups.addGroup")}
            </button>
          ) : null
        }
      >
        {t("training.groups.trainingGroups")}
      </CardHeader>
      <CardBody>
        {groups.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {groups.map((group) => {
              const count = group.player_ids.length;

              return (
                <div
                  key={group.id}
                  className="flex items-center gap-2 bg-sunken border border-line rounded-control px-3 py-1.5"
                >
                  <div className="text-fg-subtle">
                    {trainingFocusIcons[group.focus] ? (
                      <span className="[&>svg]:w-4 [&>svg]:h-4">
                        {trainingFocusIcons[group.focus]}
                      </span>
                    ) : (
                      <Users className="w-4 h-4" />
                    )}
                  </div>
                  <input
                    type="text"
                    value={group.name}
                    onChange={(event) => updateGroupName(group.id, event.target.value)}
                    className="bg-transparent text-caption font-heading font-bold uppercase tracking-label text-fg border-none outline-none w-20"
                  />
                  <Select
                    value={group.focus}
                    onChange={(event) => updateGroupFocus(group.id, event.target.value)}
                    disabled={isSaving}
                    variant="muted"
                    selectSize="xs"
                    className="w-28"
                  >
                    {trainingFocusIds.map((focusId) => (
                      <option key={focusId} value={focusId}>
                        {t(`training.focuses.${focusId}.label`)}
                      </option>
                    ))}
                  </Select>
                  <span className="text-caption text-fg-subtle tabular-nums">{count}</span>
                  <button
                    type="button"
                    onClick={() => removeGroup(group.id)}
                    disabled={isSaving}
                    className="text-danger hover:text-danger transition-colors disabled:opacity-50"
                    title={t("training.groups.removeGroup")}
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              );
            })}
          </div>
        )}

        {groups.length === 0 ? (
          <p className="text-body text-fg-muted mb-3">{t("training.groups.noGroups")}</p>
        ) : (
          <div className="overflow-x-auto rounded-control border border-line">
            <table className="w-full text-left text-body">
              <thead>
                <tr className="bg-sunken">
                  <th className="py-2 px-3 text-caption font-heading font-bold uppercase tracking-labelst text-fg-muted">
                    {t("common.player")}
                  </th>
                  <th className="py-2 px-3 text-caption font-heading font-bold uppercase tracking-labelst text-fg-muted">
                    {t("common.position")}
                  </th>
                  <th className="py-2 px-3 text-caption font-heading font-bold uppercase tracking-labelst text-fg-muted">
                    {t("common.condition")}
                  </th>
                  <th className="py-2 px-3 text-caption font-heading font-bold uppercase tracking-labelst text-fg-muted">
                    {t("training.groups.group")}
                  </th>
                  <th className="py-2 px-3 text-caption font-heading font-bold uppercase tracking-labelst text-fg-muted">
                    {t("training.effectiveFocus")}
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {sortedRoster.map((player) => {
                  const playerGroup = playerGroupMap.get(player.id);
                  const hasIndividualFocus = !!player.training_focus;
                  const fallbackFocus = playerGroup ? playerGroup.focus : teamFocus;

                  return (
                    <tr key={player.id} className="hover:bg-hover/30 transition-colors">
                      <td className="py-1.5 px-3 text-body font-medium text-fg truncate max-w-[160px]">
                        {player.match_name}
                        {player.jersey_number != null ? ` (#${player.jersey_number})` : ""}
                      </td>
                      <td className="py-1.5 px-3 text-caption text-fg-muted">
                        {translatePositionAbbreviation(t, naturalPositionOf(player))}
                      </td>
                      <td
                        className={`py-1.5 px-3 text-caption font-heading font-bold tabular-nums ${condColor(player.condition)}`}
                      >
                        {Math.round(player.condition)}%
                      </td>
                      <td className="py-1.5 px-3">
                        <Select
                          value={playerGroup?.id || ""}
                          onChange={(event) => setPlayerGroup(player.id, event.target.value)}
                          disabled={isSaving}
                          variant="muted"
                          selectSize="xs"
                          fullWidth
                          wrapperClassName="w-full max-w-[120px]"
                        >
                          <option value="">{t("training.groups.teamDefault")}</option>
                          {groups.map((group) => (
                            <option key={group.id} value={group.id}>
                              {group.name}
                            </option>
                          ))}
                        </Select>
                      </td>
                      <td className="py-1.5 px-3">
                        <Select
                          value={player.training_focus || ""}
                          onChange={(event) => setPlayerFocus(player.id, event.target.value)}
                          disabled={isSaving}
                          variant={hasIndividualFocus ? "highlighted" : "placeholder"}
                          selectSize="xs"
                          fullWidth
                          wrapperClassName="w-full max-w-[110px]"
                        >
                          <option value="">{t(`training.focuses.${fallbackFocus}.label`)} ↩</option>
                          {trainingFocusIds.map((focusId) => (
                            <option key={focusId} value={focusId}>
                              {t(`training.focuses.${focusId}.label`)}
                            </option>
                          ))}
                        </Select>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
        <p className="text-caption text-fg-subtle mt-3">
          {t("training.groups.trainingGroupsDesc")}
        </p>
      </CardBody>
    </Card>
  );
}
