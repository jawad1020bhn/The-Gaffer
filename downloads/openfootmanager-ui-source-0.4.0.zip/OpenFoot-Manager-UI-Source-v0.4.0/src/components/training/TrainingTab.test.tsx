import { fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

import type { GameStateData, PlayerData, TeamData } from "../../store/gameStore";
import TrainingTab from "./TrainingTab";
import {
  createConditionStatus,
  createSeasonContext,
  createSquadFitness,
} from "../../test-utils/factories";

const invokeMock = vi.fn();

vi.mock("@tauri-apps/api/core", () => ({
  invoke: (...args: unknown[]) => invokeMock(...args),
}));

vi.mock("react-i18next", () => ({
  useTranslation: () => ({
    t: (key: string, params?: Record<string, string | number>, fallback?: string) => {
      if (key === "common.noTeam") return "No team";
      if (key === "training.staffAlert") return "Staff alert";
      if (key === "training.goalkeepersLabel") return "Goalkeepers";
      if (key === "training.staffWarning") return "Staff warning";
      if (key === "training.staffSuggestion") return "Staff suggestion";
      if (key === "training.staffAdvice.critical")
        return `Critical advice ${params?.criticalCount} ${params?.scheduleAdvice}`;
      if (key === "training.staffAdvice.warn")
        return `Warning advice ${params?.avgCondition} ${params?.exhaustedCount} ${params?.scheduleAdvice}`;
      if (key === "training.staffAdvice.ok") return "Squad is in a good place";
      if (key === "training.criticalCondition") return `Critical players ${params?.count}`;
      if (key === "training.exhaustedPlayers") return `Exhausted players ${params?.count}`;
      if (key === "training.weeklySchedule") return "Weekly Schedule";
      if (key === "training.trainingFocus") return "Training Focus";
      if (key === "training.intensity") return "Intensity";
      if (key === "training.trainingAppliedNote") return "Applied note";
      if (key === "training.recoveryNote") return "Recovery note";
      if (key === "training.squadFitness") return "Squad Fitness";
      if (key === "training.playerFitness") return "Player Fitness";
      if (key === "training.groups.trainingGroups") return "Training Groups";
      if (key === "training.groups.noGroups") return "No groups";
      if (key === "training.todayIs") return `${params?.day} is ${params?.type}`;
      if (key === "training.aTrainingDay") return "a training day";
      if (key === "training.aRestDay") return "a rest day";
      if (key === "training.train") return "Train";
      if (key === "training.rest") return "Rest";
      if (key.startsWith("training.schedules.")) return key.replace("training.schedules.", "");
      if (key.startsWith("training.staffAdvice.scheduleAdvice.")) {
        return key.replace("training.staffAdvice.scheduleAdvice.", "");
      }
      if (key.startsWith("training.focuses.")) return key.replace("training.focuses.", "");
      if (key.startsWith("training.intensities.")) return key.replace("training.intensities.", "");
      if (key.startsWith("training.days.")) return key.replace("training.days.", "");
      if (key.startsWith("common.attributes.")) return key.replace("common.attributes.", "");
      return fallback ?? key;
    },
  }),
}));

function createTeam(overrides: Partial<TeamData> = {}): TeamData {
  return {
    id: "team-1",
    name: "Alpha FC",
    short_name: "ALP",
    country: "GB",
    city: "London",
    stadium_name: "Alpha Ground",
    stadium_capacity: 30000,
    finance: 500000,
    manager_id: "manager-1",
    reputation: 50,
    wage_budget: 50000,
    transfer_budget: 250000,
    season_income: 0,
    season_expenses: 0,
    formation: "4-4-2",
    play_style: "Balanced",
    training_focus: "Physical",
    training_intensity: "Medium",
    training_schedule: "Balanced",
    founded_year: 1900,
    colors: { primary: "#000000", secondary: "#ffffff" },
    starting_xi_ids: [],
    form: [],
    history: [],
    ...overrides,
  };
}

function createPlayer(overrides: Partial<PlayerData> = {}): PlayerData {
  return {
    id: "player-1",
    match_name: "J. Smith",
    full_name: "John Smith",
    date_of_birth: "2002-01-01",
    nationality: "GB",
    position: "Forward",
    natural_position: "Forward",
    alternate_positions: [],
    training_focus: null,
    attributes: {
      pace: 60,
      stamina: 60,
      strength: 60,
      agility: 60,
      passing: 60,
      shooting: 60,
      tackling: 60,
      dribbling: 60,
      defending: 60,
      positioning: 60,
      vision: 60,
      decisions: 60,
      composure: 60,
      aggression: 60,
      teamwork: 60,
      leadership: 60,
      handling: 20,
      reflexes: 20,
      aerial: 60,
    },
    condition: 80,
    morale: 75,
    injury: null,
    team_id: "team-1",
    retired: false,
    contract_end: "2027-06-30",
    wage: 12000,
    market_value: 350000,
    stats: {
      appearances: 0,
      goals: 0,
      assists: 0,
      clean_sheets: 0,
      yellow_cards: 0,
      red_cards: 0,
      avg_rating: 0,
      minutes_played: 0,
    },
    career: [],
    transfer_listed: false,
    loan_listed: false,
    transfer_offers: [],
    traits: [],
    ...overrides,
  };
}

function createGameState(withTeam: boolean): GameStateData {
  return {
    season_context: createSeasonContext(),
    clock: {
      current_date: "2026-08-11T00:00:00Z",
      start_date: "2026-07-01T00:00:00Z",
    },
    manager: {
      display_name: "Jane Doe",
      id: "manager-1",
      first_name: "Jane",
      last_name: "Doe",
      date_of_birth: "1980-01-01",
      nationality: "GB",
      reputation: 50,
      satisfaction: 50,
      fan_approval: 50,
      team_id: "team-1",
      career_stats: {
        matches_managed: 0,
        wins: 0,
        draws: 0,
        losses: 0,
        trophies: 0,
        best_finish: null,
      },
      career_history: [],
    },
    teams: withTeam ? [createTeam()] : [],
    players: withTeam ? [createPlayer()] : [],
    staff: [],
    messages: [],
    news: [],
    league: null,
    scouting_assignments: [],
    board_objectives: [],
  };
}

describe("TrainingTab", () => {
  beforeEach(() => {
    invokeMock.mockReset();
    const defaultState = createGameState(true);
    const defaultRoster = defaultState.players.filter((p) => p.team_id === "team-1");
    invokeMock.mockImplementation(async (command: string) => {
      if (command === "get_squad") return defaultRoster;
      if (command === "get_training_focus_attributes") return [];
      if (command === "get_squad_fitness") return createSquadFitness();
      return defaultState;
    });
  });

  it("renders the no-team state when the manager has no club", () => {
    render(<TrainingTab gameState={createGameState(false)} />);

    expect(screen.getByText("No team")).toBeInTheDocument();
  });

  // Given the backend says goalkeepers train handling and reflexes under Technical, when the tab renders, then the focus card lists them.
  it("lists the attributes the backend reports for each focus", async () => {
    const state = createGameState(true);
    const roster = state.players.filter((p) => p.team_id === "team-1");
    invokeMock.mockImplementation(async (command: string) => {
      if (command === "get_squad") return roster;
      if (command === "get_training_focus_attributes") {
        return [
          { focus: "Physical", outfield: ["pace"], goalkeeper: ["pace"] },
          { focus: "Technical", outfield: ["passing", "shooting"], goalkeeper: ["handling"] },
        ];
      }
      if (command === "get_squad_fitness") return createSquadFitness();
      return state;
    });

    render(<TrainingTab gameState={state} />);

    expect(await screen.findByText("handling")).toBeInTheDocument();
    expect(screen.getAllByText("Goalkeepers:").length).toBeGreaterThan(0);
  });

  it("updates the weekly schedule and forwards the refreshed state", async () => {
    const updatedState = createGameState(true);
    const defaultRoster = updatedState.players.filter((p) => p.team_id === "team-1");
    const onGameUpdate = vi.fn();
    invokeMock.mockImplementation(async (command: string) => {
      if (command === "get_squad") return defaultRoster;
      if (command === "get_squad_fitness") return createSquadFitness();
      return updatedState;
    });

    render(<TrainingTab gameState={createGameState(true)} onGameUpdate={onGameUpdate} />);

    fireEvent.click(screen.getByRole("button", { name: /Intense.label/i }));

    await waitFor(() => {
      expect(invokeMock).toHaveBeenCalledWith("set_training_schedule", {
        careerToken: 0,
        schedule: "Intense",
      });
      expect(onGameUpdate).toHaveBeenCalledWith(updatedState);
    });
  });

  it("renders the critical staff advice banner for an exhausted squad", async () => {
    const exhaustedState = createGameState(true);
    exhaustedState.players = [
      createPlayer({ id: "p1", condition: 18 }),
      createPlayer({ id: "p2", condition: 20 }),
      createPlayer({ id: "p3", condition: 24 }),
      createPlayer({ id: "p4", condition: 55 }),
    ];
    invokeMock.mockImplementation(async (command: string) => {
      if (command === "get_squad")
        return exhaustedState.players.filter((p) => p.team_id === "team-1");
      if (command === "get_squad_fitness") {
        return createSquadFitness({ average_condition: 29, exhausted_count: 3, critical_count: 3 });
      }
      return exhaustedState;
    });

    render(<TrainingTab gameState={exhaustedState} />);

    await waitFor(() => {
      expect(screen.getByText("Staff alert")).toBeInTheDocument();
    });
    expect(screen.getByText(/Critical advice/)).toBeInTheDocument();
  });

  it("ignores youth academy players in first-team training summaries", async () => {
    const state = createGameState(true);
    state.players = [
      createPlayer({ id: "senior-1", condition: 80 }),
      createPlayer({ id: "youth-1", condition: 10, squad_role: "Youth" }),
    ];
    invokeMock.mockImplementation(async (command: string) => {
      if (command === "get_squad") return state.players.filter((p) => p.team_id === "team-1");
      if (command === "get_squad_fitness") {
        return createSquadFitness({ players: 1, average_condition: 80 });
      }
      return state;
    });

    render(<TrainingTab gameState={state} />);

    await waitFor(() => {
      expect(invokeMock).toHaveBeenCalledWith("get_squad_fitness");
    });
    expect(screen.queryByText(/Critical advice/)).not.toBeInTheDocument();
  });
  // Given backend-selected youth, when Training opens, then the called-up row
  // and his fatigue contribute to first-team training; excluded youth stay hidden.
  it("shows called-up youth in Training using backend eligibility", async () => {
    const state = createGameState(true);
    state.teams[0].training_groups = [
      { id: "recovery", name: "Recovery", focus: "Recovery", player_ids: [] },
    ];
    state.players = [
      createPlayer({ id: "senior", full_name: "Senior Player", condition: 80 }),
      createPlayer({
        id: "called",
        full_name: "Called Youth",
        match_name: "Called Youth",
        condition: 10,
        squad_role: "Youth",
        match_day_eligible: true,
      }),
      createPlayer({
        id: "excluded",
        full_name: "Excluded Youth",
        match_name: "Excluded Youth",
        squad_role: "Youth",
        match_day_eligible: false,
      }),
    ];
    invokeMock.mockImplementation(async (command: string) => {
      if (command === "get_squad_fitness") {
        return createSquadFitness({ average_condition: 45, exhausted_count: 1, critical_count: 1 });
      }
      return command === "get_squad" ? state.players : state;
    });
    render(<TrainingTab gameState={state} />);
    expect(await screen.findByRole("row", { name: /Called Youth/ })).toBeInTheDocument();
    expect(screen.queryByRole("row", { name: /Excluded Youth/ })).not.toBeInTheDocument();
    expect(screen.getByText(/Warning advice 45/)).toBeInTheDocument();
  });

  /**
   * Given the backend counts three players below 40 of whom one is below 25
   * When Training shows the squad fitness
   * Then it shows one critical and three exhausted: the two counts are not swapped.
   */
  it("shows the exhausted and critical counts the backend gives, apart", async () => {
    const state = createGameState(true);
    state.players = [createPlayer({ id: "p1", condition: 80 })];
    invokeMock.mockImplementation(async (command: string) => {
      if (command === "get_squad_fitness") {
        return createSquadFitness({ average_condition: 60, exhausted_count: 3, critical_count: 1 });
      }
      return command === "get_squad" ? state.players : state;
    });

    render(<TrainingTab gameState={state} />);

    expect(await screen.findByText("Critical players 1")).toBeInTheDocument();
    expect(screen.getByText("Exhausted players 3")).toBeInTheDocument();
  });

  /**
   * Given the backend has not answered yet, and then answers that no healthy first-team player can
   *       be averaged
   * When Training shows the squad fitness
   * Then the average is a dash and there is no staff advice: an unanswered 0% is not "tired".
   */
  it("shows no average and no staff advice without an average from the backend", async () => {
    const state = createGameState(true);
    state.players = [createPlayer({ id: "p1", condition: 80 })];
    let answer: (value: unknown) => void = () => {};
    invokeMock.mockImplementation((command: string) => {
      if (command === "get_squad_fitness") {
        return new Promise((resolve) => {
          answer = resolve;
        });
      }
      return Promise.resolve(command === "get_squad" ? state.players : state);
    });

    render(<TrainingTab gameState={state} />);

    expect(await screen.findByText("—")).toBeInTheDocument();
    expect(screen.queryByText(/advice/i)).not.toBeInTheDocument();
    answer(createSquadFitness({ players: 0, average_condition: null }));
    await waitFor(() => expect(invokeMock).toHaveBeenCalledWith("get_squad_fitness"));
    expect(screen.getByText("—")).toBeInTheDocument();
    expect(screen.queryByText(/advice/i)).not.toBeInTheDocument();
  });

  /**
   * Given a player on 90 whom the backend marks critical (he is injured, on 90 in the list but the
   *       band is the backend's) and one on 10 whom it marks fresh
   * When Training lists the players
   * Then each row shows the backend's word for the band and paints it, and the bar, in the
   *      backend's tone, not in a colour picked from his condition.
   */
  it("shows each player's band in the backend's word and tone, not from his condition", async () => {
    const state = createGameState(true);
    state.players = [
      createPlayer({ id: "p-critical", match_name: "Flagged Critical", condition: 90 }),
      createPlayer({ id: "p-fresh", match_name: "Flagged Fresh", condition: 10 }),
    ];
    invokeMock.mockImplementation(async (command: string) => {
      if (command === "get_squad_fitness") {
        return createSquadFitness({
          statuses: {
            "p-critical": createConditionStatus("Critical"),
            "p-fresh": createConditionStatus("Fresh"),
          },
        });
      }
      return command === "get_squad" ? state.players : state;
    });

    render(<TrainingTab gameState={state} />);

    const critical = await screen.findByRole("listitem", { name: /Flagged Critical/ });
    expect(within(critical).getByText("be.condition.critical")).toHaveClass("text-tone-bad");
    const criticalBar = within(critical).getByRole("progressbar", { name: "common.condition" });
    expect(criticalBar.firstElementChild).toHaveClass("bg-tone-bad-solid");
    const fresh = screen.getByRole("listitem", { name: /Flagged Fresh/ });
    expect(within(fresh).getByText("be.condition.fresh")).toHaveClass("text-tone-good");
    const freshBar = within(fresh).getByRole("progressbar", { name: "common.condition" });
    expect(freshBar.firstElementChild).toHaveClass("bg-tone-good-solid");
  });

  /**
   * Given an average of 90 that the backend's band rule paints bad (the fixture contradicts the
   *       number on purpose)
   * When Training draws the squad's average condition
   * Then its bar is filled in the backend's tone, not the green a 70-up threshold picked.
   */
  it("paints the average condition bar in the backend's tone", async () => {
    const state = createGameState(true);
    invokeMock.mockImplementation(async (command: string) => {
      if (command === "get_squad_fitness") {
        return createSquadFitness({
          average_condition: 90,
          average_status: createConditionStatus("Critical"),
        });
      }
      return command === "get_squad" ? state.players : state;
    });

    render(<TrainingTab gameState={state} />);

    const average = await screen.findByRole("progressbar", { name: "training.avgCondition" });
    await waitFor(() => expect(average.firstElementChild).toHaveClass("bg-tone-bad-solid"));
    expect(average.firstElementChild).not.toHaveClass("bg-positive-solid");
  });

  /**
   * Given a squad whose only player is injured, so the backend has no healthy first-team player to
   *       average (its average is null) but still a band for him
   * When Training has the backend's answer (his band is on the list)
   * Then the average's bar is no progress bar: "Avg Condition 0%" would read out a number that
   * doesn't exist.
   */
  it("exposes no average progress bar while there is no average", async () => {
    const state = createGameState(true);
    state.players = [
      createPlayer({
        id: "p-injured",
        match_name: "Sidelined",
        condition: 30,
        injury: { name: "hamstring_strain", days_remaining: 9 },
      }),
    ];
    invokeMock.mockImplementation(async (command: string) => {
      if (command === "get_squad_fitness") {
        return createSquadFitness({
          players: 0,
          average_condition: null,
          statuses: { "p-injured": createConditionStatus("Exhausted") },
        });
      }
      return command === "get_squad" ? state.players : state;
    });

    render(<TrainingTab gameState={state} />);

    const injured = await screen.findByRole("listitem", { name: /Sidelined/ });
    expect(await within(injured).findByText("be.condition.exhausted")).toBeInTheDocument();
    expect(screen.queryByRole("progressbar", { name: "training.avgCondition" })).toBeNull();
  });
});
