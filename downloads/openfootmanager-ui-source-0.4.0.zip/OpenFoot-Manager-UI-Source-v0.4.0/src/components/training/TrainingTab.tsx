import { useSquadFitness } from "../../hooks/useSquadFitness";
import { useState, type ReactNode } from "react";
import {
  AlertTriangle,
  BedDouble,
  Brain,
  Crosshair,
  Feather,
  Flame,
  HeartPulse,
  Info,
  Scale,
  Shield,
  Zap,
} from "lucide-react";
import { useTranslation } from "react-i18next";

import type { GameStateData } from "../../store/gameStore";
import { useGameStore } from "../../store/gameStore";
import { isFirstTeamSquadPlayer } from "../../lib/playerSquad";
import { useFetchedSquad } from "../../hooks/useFetchedSquad";
import { useTrainingFocusAttributes } from "../../hooks/useTrainingFocusAttributes";
import { setTraining, setTrainingSchedule } from "../../services/trainingService";
import { Card, CardBody, CardHeader, ProgressBar, TONE_TEXT } from "../ui";
import TrainingGroupsCard from "./TrainingGroupsCard";
import TrainingSettingsPanel from "./TrainingSettingsPanel";
import { getTrainingStaffAdvice } from "./trainingAdvice";

interface TrainingTabProps {
  gameState: GameStateData | null;
  onGameUpdate?: (state: GameStateData) => void;
}

const TRAINING_FOCUS_IDS = [
  "Physical",
  "Technical",
  "Tactical",
  "Defending",
  "Attacking",
  "Recovery",
] as const;

const TRAINING_FOCUS_ICONS: Record<string, ReactNode> = {
  Physical: <HeartPulse className="w-6 h-6" />,
  Technical: <Crosshair className="w-6 h-6" />,
  Tactical: <Brain className="w-6 h-6" />,
  Defending: <Shield className="w-6 h-6" />,
  Attacking: <Zap className="w-6 h-6" />,
  Recovery: <BedDouble className="w-6 h-6" />,
};

const INTENSITY_IDS = ["Low", "Medium", "High"] as const;

const INTENSITY_COLORS: Record<string, string> = {
  Low: "text-info",
  Medium: "text-warning",
  High: "text-danger",
};

const SCHEDULE_IDS = ["Intense", "Balanced", "Light"] as const;

const SCHEDULE_ICONS: Record<string, ReactNode> = {
  Intense: <Flame className="w-5 h-5" />,
  Balanced: <Scale className="w-5 h-5" />,
  Light: <Feather className="w-5 h-5" />,
};

const SCHEDULE_COLORS: Record<string, string> = {
  Intense: "text-danger",
  Balanced: "text-selected",
  Light: "text-info",
};

const SCHEDULE_TRAINING_DAYS: Record<string, number[]> = {
  Intense: [0, 1, 2, 3, 4, 5],
  Balanced: [0, 1, 3, 4],
  Light: [1, 3],
};

const DAY_KEYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"] as const;

function getWeekdayFromDate(dateStr: string): number {
  const date = new Date(dateStr);
  return (date.getUTCDay() + 6) % 7;
}

export default function TrainingTab({ gameState, onGameUpdate }: TrainingTabProps) {
  const { t } = useTranslation();
  const { sessionState } = useGameStore();
  const [isSaving, setIsSaving] = useState(false);
  const teamId = sessionState?.manager?.team_id ?? gameState?.manager?.team_id ?? null;
  const clockDate = sessionState?.clock.current_date ?? gameState?.clock.current_date ?? "";
  const [fetchedSquad, setFetchedSquad] = useFetchedSquad(
    teamId,
    clockDate,
    sessionState ?? gameState,
  );
  const focusAttributes = useTrainingFocusAttributes();
  const fitness = useSquadFitness(sessionState ?? gameState);

  const team = sessionState?.team ?? gameState?.teams.find((t) => t.id === teamId) ?? null;

  if (!team) {
    return <p className="text-fg-muted">{t("common.noTeam")}</p>;
  }

  const currentFocus = team.training_focus || "Physical";
  const currentIntensity = team.training_intensity || "Medium";
  const currentSchedule = team.training_schedule || "Balanced";

  const allSquadPlayers =
    fetchedSquad ?? gameState?.players.filter((p) => p.team_id === teamId) ?? [];
  const roster = allSquadPlayers.filter(isFirstTeamSquadPlayer);
  // Fitness is the backend's: injured players are not in the squad that can play.
  const avgCondition =
    fitness?.average_condition != null ? Math.round(fitness.average_condition) : null;
  const averageTone = fitness?.average_status?.tone;
  const avgMorale =
    roster.length > 0
      ? Math.round(roster.reduce((sum, player) => sum + player.morale, 0) / roster.length)
      : 0;
  const exhaustedCount = fitness?.exhausted_count ?? 0;
  const criticalCount = fitness?.critical_count ?? 0;

  const todayWeekday = getWeekdayFromDate(clockDate);
  const trainingDays = SCHEDULE_TRAINING_DAYS[currentSchedule] || SCHEDULE_TRAINING_DAYS.Balanced;
  const isTodayTraining = trainingDays.includes(todayWeekday);

  const handleSetTraining = async (focus: string, intensity: string) => {
    setIsSaving(true);
    try {
      const updated = await setTraining(focus, intensity);
      onGameUpdate?.(updated);
    } catch (error) {
      console.error("Failed to set training:", error);
    } finally {
      setIsSaving(false);
    }
  };

  const handleSetSchedule = async (schedule: string) => {
    setIsSaving(true);
    try {
      const updated = await setTrainingSchedule(schedule);
      onGameUpdate?.(updated);
    } catch (error) {
      console.error("Failed to set schedule:", error);
    } finally {
      setIsSaving(false);
    }
  };

  // No advice until the backend has said how fit the squad is: an unanswered 0% is not "tired".
  const staffAdvice =
    avgCondition !== null
      ? getTrainingStaffAdvice(t, {
          criticalCount,
          avgCondition,
          exhaustedCount,
          currentSchedule,
          currentFocus,
        })
      : null;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
      <div className="lg:col-span-2 flex flex-col gap-5">
        {staffAdvice ? (
          <div
            className={`flex items-start gap-3 p-4 rounded-panel border-2 ${
              staffAdvice.level === "critical"
                ? "bg-danger-tint border-danger/40"
                : staffAdvice.level === "warn"
                  ? "bg-warning-tint border-warning/40"
                  : "bg-info-tint border-info/40"
            }`}
          >
            {staffAdvice.level === "critical" ? (
              <AlertTriangle className="w-5 h-5 text-danger flex-shrink-0 mt-0.5" />
            ) : staffAdvice.level === "warn" ? (
              <AlertTriangle className="w-5 h-5 text-warning flex-shrink-0 mt-0.5" />
            ) : (
              <Info className="w-5 h-5 text-info flex-shrink-0 mt-0.5" />
            )}
            <div>
              <p
                className={`text-caption font-heading font-bold uppercase tracking-label mb-0.5 ${
                  staffAdvice.level === "critical"
                    ? "text-danger"
                    : staffAdvice.level === "warn"
                      ? "text-warning"
                      : "text-info"
                }`}
              >
                {staffAdvice.level === "critical"
                  ? t("training.staffAlert")
                  : staffAdvice.level === "warn"
                    ? t("training.staffWarning")
                    : t("training.staffSuggestion")}
              </p>
              <p className="text-body text-fg">{staffAdvice.message}</p>
            </div>
          </div>
        ) : null}

        <TrainingSettingsPanel
          currentFocus={currentFocus}
          currentIntensity={currentIntensity}
          currentSchedule={currentSchedule}
          isSaving={isSaving}
          todayWeekday={todayWeekday}
          isTodayTraining={isTodayTraining}
          onSetTraining={handleSetTraining}
          onSetSchedule={handleSetSchedule}
          scheduleIds={SCHEDULE_IDS}
          scheduleIcons={SCHEDULE_ICONS}
          scheduleColors={SCHEDULE_COLORS}
          dayKeys={DAY_KEYS}
          trainingFocusIds={TRAINING_FOCUS_IDS}
          trainingFocusIcons={TRAINING_FOCUS_ICONS}
          focusAttributes={focusAttributes}
          intensityIds={INTENSITY_IDS}
          intensityColors={INTENSITY_COLORS}
        />

        <TrainingGroupsCard
          team={team}
          onGameUpdate={(game) => {
            onGameUpdate?.(game);
            // Patch the useFetchedSquad cache so per-player mutations
            // (individual training_focus) reflect in the roster without a
            // clock-advance or remount. Same pattern the youth-promote fix
            // uses (PR #308).
            if (teamId) {
              setFetchedSquad(game.players.filter((p) => p.team_id === teamId));
            }
          }}
          roster={roster}
          isSaving={isSaving}
          setIsSaving={setIsSaving}
          trainingFocusIds={TRAINING_FOCUS_IDS}
          trainingFocusIcons={TRAINING_FOCUS_ICONS}
        />
      </div>

      <div className="flex flex-col gap-5">
        <Card accent="accent">
          <CardHeader>{t("training.squadFitness")}</CardHeader>
          <CardBody>
            <div className="flex flex-col gap-3">
              <div>
                <div className="flex justify-between text-body mb-1">
                  <span className="text-fg-muted">{t("training.avgCondition")}</span>
                  <span className="font-heading font-bold text-fg">
                    {avgCondition !== null ? `${avgCondition}%` : "—"}
                  </span>
                </div>
                {/* The backend's band for the average; neutral until it answers. */}
                <ProgressBar
                  value={avgCondition ?? 0}
                  variant={averageTone ? undefined : "muted"}
                  tone={averageTone}
                  size="md"
                  // No average, no progress bar: "0%" would be read out for a number that doesn't exist.
                  label={avgCondition !== null ? t("training.avgCondition") : undefined}
                />
              </div>
              <div>
                <div className="flex justify-between text-body mb-1">
                  <span className="text-fg-muted">{t("training.avgMorale")}</span>
                  <span className="font-heading font-bold text-fg">{avgMorale}%</span>
                </div>
                <ProgressBar value={avgMorale} variant="auto" size="md" />
              </div>
              {exhaustedCount > 0 || criticalCount > 0 ? (
                <div className="mt-1 pt-2 border-t border-line">
                  {criticalCount > 0 ? (
                    <p className="text-caption text-danger flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3" />{" "}
                      {t("training.criticalCondition", { count: criticalCount })}
                    </p>
                  ) : null}
                  {exhaustedCount > 0 ? (
                    <p className="text-caption text-warning flex items-center gap-1 mt-0.5">
                      <AlertTriangle className="w-3 h-3" />{" "}
                      {t("training.exhaustedPlayers", { count: exhaustedCount })}
                    </p>
                  ) : null}
                </div>
              ) : null}
            </div>
          </CardBody>
        </Card>

        <Card>
          <CardHeader>{t("training.playerFitness")}</CardHeader>
          <CardBody className="p-0 max-h-64 overflow-y-auto">
            <ul className="divide-y divide-line">
              {[...roster]
                .sort((left, right) => left.condition - right.condition)
                .map((player) => {
                  // The band, its word and its tone are the backend's; until it answers the bar
                  // stays neutral rather than guessing from the number.
                  const status = fitness?.statuses[player.id];
                  const nameId = `fitness-name-${player.id}`;
                  return (
                    <li
                      key={player.id}
                      aria-labelledby={nameId}
                      className="flex items-center px-4 py-2 gap-3"
                    >
                      <span id={nameId} className="text-body font-medium flex-1 truncate text-fg">
                        {player.match_name}
                        {player.jersey_number != null ? ` (#${player.jersey_number})` : ""}
                      </span>
                      {status ? (
                        <span className={`text-caption font-semibold ${TONE_TEXT[status.tone]}`}>
                          {t(status.label_key)}
                        </span>
                      ) : null}
                      <ProgressBar
                        value={player.condition}
                        variant={status ? undefined : "muted"}
                        tone={status?.tone}
                        size="sm"
                        showLabel
                        label={t("common.condition")}
                        className="w-24"
                      />
                    </li>
                  );
                })}
            </ul>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
