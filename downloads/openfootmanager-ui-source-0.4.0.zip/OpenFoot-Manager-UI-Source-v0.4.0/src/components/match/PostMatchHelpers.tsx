import { useTranslation } from "react-i18next";
import type { MatchSnapshot, MatchEvent } from "./types";
import { getPlayerName } from "./helpers";
import { Badge } from "../ui";
import { Circle, Star } from "lucide-react";
import { translatePositionAbbreviation } from "../squad/SquadTab.helpers";

// ---------------------------------------------------------------------------
// QuickStat bar
// ---------------------------------------------------------------------------

export function QuickStat({
  label,
  home,
  away,
  homePct,
}: {
  label: string;
  home: number | string;
  away: number | string;
  homePct?: number;
}) {
  const hv = typeof home === "number" ? home : 0;
  const av = typeof away === "number" ? away : 0;
  const total = hv + av || 1;
  const pct = homePct ?? (hv / total) * 100;

  return (
    <div className="mb-2 last:mb-0">
      <div className="flex justify-between text-caption mb-0.5">
        <span className="font-heading font-bold text-selected tabular-nums">{home}</span>
        <span className="text-fg-muted font-heading uppercase tracking-label text-caption">
          {label}
        </span>
        <span className="font-heading font-bold text-info tabular-nums">{away}</span>
      </div>
      <div className="flex h-1 bg-line-strong rounded-full overflow-hidden transition-colors duration-300">
        <div className="h-full bg-selected-fill" style={{ width: `${pct}%` }} />
        <div className="h-full bg-info-solid" style={{ width: `${100 - pct}%` }} />
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Scorer list per side
// ---------------------------------------------------------------------------

export function renderScorers(
  snapshot: MatchSnapshot,
  events: MatchEvent[],
  side: "Home" | "Away",
) {
  const goals = events.filter(
    (e) => e.side === side && (e.event_type === "Goal" || e.event_type === "PenaltyGoal"),
  );
  if (goals.length === 0) return null;

  const team = side === "Home" ? snapshot.home_team : snapshot.away_team;
  return (
    <div className="mb-3 last:mb-0">
      <p
        className={`text-caption font-heading uppercase tracking-labelst mb-1 ${
          side === "Home" ? "text-selected" : "text-info"
        }`}
      >
        {team.name}
      </p>
      {goals.map((g, i) => (
        <div key={i} className="flex items-center gap-2 text-caption py-0.5">
          <span className="text-fg-muted tabular-nums w-6 text-right font-heading">
            {g.minute}'
          </span>
          <Circle className="w-3 h-3 fill-current text-warning" />
          <span className="text-fg font-medium">{getPlayerName(snapshot, g.player_id)}</span>
          {g.event_type === "PenaltyGoal" && (
            <Badge variant="accent" size="sm">
              PEN
            </Badge>
          )}
        </div>
      ))}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Player Ratings panel for one side
// ---------------------------------------------------------------------------

function ratingColour(rating: number | null): string {
  if (rating === null) return "text-fg-subtle";
  if (rating >= 8) return "text-warning";
  if (rating >= 7) return "text-positive";
  if (rating >= 6) return "text-fg-muted";
  if (rating >= 5) return "text-warning";
  return "text-danger";
}

export function PlayerRatingsPanel({
  snapshot,
  side,
  teamColor,
  userSide,
}: {
  snapshot: MatchSnapshot;
  side: "Home" | "Away";
  teamColor: string;
  userSide: "Home" | "Away" | null;
}) {
  const { t } = useTranslation();
  const team = side === "Home" ? snapshot.home_team : snapshot.away_team;
  const bench = side === "Home" ? snapshot.home_bench : snapshot.away_bench;
  const engineRatings = snapshot.player_ratings ?? {};
  const playedFromBench = (id: string) =>
    id in engineRatings ||
    snapshot.substitutions.some((sub) => sub.player_on_id === id || sub.player_off_id === id);
  const sorted = [...team.players, ...bench.filter((p) => playedFromBench(p.id))]
    .map((p) => ({ ...p, rating: engineRatings[p.id] ?? null }))
    .sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0));
  const motm = sorted[0]?.rating != null ? sorted[0] : null;

  return (
    <div className="bg-panel rounded-panel border border-line shadow-sm p-4 transition-colors duration-300">
      <div className="flex items-center gap-2 mb-3">
        <Star className="w-4 h-4 text-warning" />
        <h3 className="text-caption font-heading font-bold uppercase tracking-labelst text-fg-muted">
          {t("match.ratings", { team: team.name })}
        </h3>
        <div className="w-2 h-2 rounded-full ml-auto" style={{ backgroundColor: teamColor }} />
      </div>
      {motm && side === (userSide || "Home") && (
        <div className="flex items-center gap-3 mb-3 p-2 bg-warning-solid bg-warning-tint rounded-control border border-warning border-warning/20 transition-colors duration-300">
          <div className="w-8 h-8 rounded-control bg-warning-solid bg-warning-tint flex items-center justify-center transition-colors duration-300">
            <span className="text-body font-heading font-bold text-warning">
              {motm.rating?.toFixed(1)}
            </span>
          </div>
          <div>
            <p className="text-caption font-heading font-bold text-warning uppercase tracking-label">
              {t("match.motm")}
            </p>
            <p className="text-body text-fg font-medium">{motm.name}</p>
          </div>
        </div>
      )}
      <div className="flex flex-col gap-0.5 max-h-40 overflow-auto">
        {sorted.map((p) => (
          <div key={p.id} className="flex items-center gap-2 px-1 py-0.5 text-caption">
            <span className={`font-heading font-bold tabular-nums w-8 ${ratingColour(p.rating)}`}>
              {p.rating === null ? "–" : p.rating.toFixed(1)}
            </span>
            <span className="text-fg-muted truncate flex-1">{p.name}</span>
            <span className="text-fg-muted text-caption font-heading uppercase">
              {translatePositionAbbreviation(t, p.position)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
