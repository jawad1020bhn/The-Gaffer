import { useEffect, useRef, useState, type KeyboardEvent } from "react";
import { useTranslation } from "react-i18next";
import {
  type MatchSnapshot,
  type RoleChangeOutcome,
  type SubstitutionOutcome,
  type SubstitutionSwap,
  FORMATIONS,
  PLAY_STYLES,
} from "./types";
import { getPlayerName } from "./helpers";
import { resolveBackendError } from "../../utils/backendI18n";
import { FormationPitch } from "./FormationPitch";
import { PlayerRolesPanel } from "./PlayerRolesPanel";
import { condBgColor, condColor } from "../../lib/playerConditionDisplay";
import { Badge, Button, Dialog, DialogCloseButton, Select } from "../ui";
import {
  RefreshCw,
  AlertTriangle,
  UserMinus,
  UserPlus,
  Shield,
  Swords,
  Sparkles,
} from "lucide-react";
import ContextMenu from "../ContextMenu";
import { translatePositionAbbreviation } from "../squad/SquadTab.helpers";
import {
  buildRecommendedSubstitutions,
  getMatchScenario,
  sortByPositionGroup,
  type MatchScenarioId,
} from "./SubPanel.helpers";
import { usePositionTable } from "../../hooks/usePositionGroups";

const CompareBar = ({ label, valA, valB }: { label: string; valA: number; valB: number }) => {
  const diff = valB - valA;
  return (
    <div className="flex items-center gap-1.5 py-0.5 text-caption">
      <span className="w-7 text-right font-heading text-fg-muted">{label}</span>
      <span className="w-5 text-right tabular-nums text-danger">{valA}</span>
      <div className="flex h-1.5 flex-1 overflow-hidden rounded-full bg-hover">
        <div className="h-full bg-danger-solid/60" style={{ width: `${valA}%` }} />
      </div>
      <div className="flex h-1.5 flex-1 justify-end overflow-hidden rounded-full bg-hover">
        <div className="h-full bg-positive-solid/60" style={{ width: `${valB}%` }} />
      </div>
      <span className="w-5 tabular-nums text-positive">{valB}</span>
      <span
        className={`w-6 text-right tabular-nums font-heading font-bold ${diff > 0 ? "text-positive" : diff < 0 ? "text-danger" : "text-fg-muted"}`}
      >
        {diff > 0 ? "+" : ""}
        {diff}
      </span>
    </div>
  );
};

export function SubPanel({
  snapshot,
  side,
  onSubstitute,
  onFormationChange,
  onPlayStyleChange,
  onChangeRole,
  onClose,
}: {
  snapshot: MatchSnapshot;
  side: "Home" | "Away";
  /** Commits every swap, in order; the panel keeps showing whatever the snapshot has not applied. */
  onSubstitute: (swaps: SubstitutionSwap[]) => Promise<SubstitutionOutcome>;
  onFormationChange: (formation: string) => void;
  onPlayStyleChange: (playStyle: string) => void;
  onChangeRole: (playerId: string, role: string) => Promise<RoleChangeOutcome>;
  onClose: () => void;
}) {
  const { t } = useTranslation();
  const positions = usePositionTable();
  const [selectedOff, setSelectedOff] = useState<string | null>(null);
  const [selectedBench, setSelectedBench] = useState<string | null>(null);
  const [queuedSwaps, setQueuedSwaps] = useState<SubstitutionSwap[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [refusal, setRefusal] = useState<{
    swap: SubstitutionSwap;
    reason: string;
    appliedCount: number;
    total: number;
  } | null>(null);
  const [focusRequest, setFocusRequest] = useState<
    { kind: "chip"; swap: SubstitutionSwap } | { kind: "off" } | null
  >(null);
  const panelRef = useRef<HTMLDivElement | null>(null);
  const submittingRef = useRef(false);

  const team = side === "Home" ? snapshot.home_team : snapshot.away_team;
  const bench = side === "Home" ? snapshot.home_bench : snapshot.away_bench;
  const subsMade = side === "Home" ? snapshot.home_subs_made : snapshot.away_subs_made;

  const subbedOnIds = new Set(
    snapshot.substitutions.filter((s) => s.side === side).map((s) => s.player_on_id),
  );
  const subbedOffIds = new Set(
    snapshot.substitutions.filter((s) => s.side === side).map((s) => s.player_off_id),
  );
  // A queued swap the snapshot already shows as made is no longer waiting, so a batch the backend
  // only partly applied leaves exactly the swaps still to do.
  const pendingSwaps = queuedSwaps.filter(
    (swap) =>
      !snapshot.substitutions.some(
        (made) =>
          made.side === side &&
          made.player_off_id === swap.offId &&
          made.player_on_id === swap.onId,
      ),
  );
  const queuedOffIds = new Set(pendingSwaps.map((swap) => swap.offId));
  const queuedOnIds = new Set(pendingSwaps.map((swap) => swap.onId));
  const substitutionsLeft = snapshot.max_subs - subsMade - pendingSwaps.length;
  const availableBench = sortByPositionGroup(
    bench.filter(
      (p) => !subbedOffIds.has(p.id) && !subbedOnIds.has(p.id) && !queuedOnIds.has(p.id),
    ),
    positions,
  );
  const selectedPlayer = selectedOff ? team.players.find((p) => p.id === selectedOff) : null;
  const comparedPlayer = selectedBench ? availableBench.find((p) => p.id === selectedBench) : null;

  const scenario = getMatchScenario(snapshot, side);
  const recommendations = buildRecommendedSubstitutions(snapshot, side);
  const visibleRecommendations = recommendations.flatMap((rec) => {
    const offPlayer = team.players.find((p) => p.id === rec.offId);
    const onPlayer = availableBench.find((p) => p.id === rec.onId);
    if (!offPlayer || !onPlayer) return [];
    return [{ rec, offPlayer, onPlayer }];
  });

  const getScenarioIcon = (id: MatchScenarioId) => {
    switch (id) {
      case "protect-lead":
        return <Shield className="h-3.5 w-3.5 text-selected" />;
      case "chase-goal":
        return <Swords className="h-3.5 w-3.5 text-warning" />;
      case "find-winner":
        return <Sparkles className="h-3.5 w-3.5 text-warning" />;
      default:
        return <RefreshCw className="h-3.5 w-3.5 text-fg-subtle" />;
    }
  };

  const handleClearSelection = () => {
    setSelectedOff(null);
    setSelectedBench(null);
  };

  const handleSelectOffPlayer = (playerId: string) => {
    if (queuedOffIds.has(playerId)) return;
    setSelectedOff((cur) => {
      if (cur === playerId) {
        setSelectedBench(null);
        return null;
      }
      setSelectedBench(null);
      return playerId;
    });
  };

  const handleSelectBenchPlayer = (playerId: string) => {
    if (!selectedOff) return;
    setSelectedBench((cur) => (cur === playerId ? null : playerId));
  };

  const handleQueueSubstitution = () => {
    if (!selectedOff || !selectedBench || substitutionsLeft < 1 || isSubmitting) return;
    setQueuedSwaps([...pendingSwaps, { offId: selectedOff, onId: selectedBench }]);
    setRefusal(null);
    handleClearSelection();
    // The button that was pressed leaves with the selection, so focus goes on to the next swap.
    setFocusRequest({ kind: "off" });
  };

  const handleRemoveQueuedSwap = (swap: SubstitutionSwap) => {
    const index = pendingSwaps.indexOf(swap);
    const neighbour = pendingSwaps[index + 1] ?? pendingSwaps[index - 1];
    setQueuedSwaps(pendingSwaps.filter((queued) => queued !== swap));
    setRefusal(null);
    setFocusRequest(neighbour ? { kind: "chip", swap: neighbour } : { kind: "off" });
  };

  // The chosen pair joins whatever is queued when a substitution is left for it, so a single
  // substitution stays one click and a full queue can still be committed with a pair selected.
  const pairToCommit =
    selectedOff && selectedBench && substitutionsLeft >= 1
      ? { offId: selectedOff, onId: selectedBench }
      : null;
  const confirmCount = pendingSwaps.length + (pairToCommit ? 1 : 0);

  const handleConfirmSubstitutions = async () => {
    if (submittingRef.current || confirmCount === 0) return;
    submittingRef.current = true;
    setIsSubmitting(true);
    setRefusal(null);
    const swaps = pairToCommit ? [...pendingSwaps, pairToCommit] : pendingSwaps;
    try {
      const outcome = await onSubstitute(swaps);
      if (!outcome.applied) {
        setRefusal({
          swap: outcome.refused,
          reason: outcome.reason,
          appliedCount: outcome.appliedCount,
          total: swaps.length,
        });
      }
    } finally {
      submittingRef.current = false;
      setIsSubmitting(false);
    }
  };

  // Focus must not fall to the page when the control that held it unmounts, so it is moved once
  // the new markup is in: to a neighbouring queued swap, or to the first player who can still
  // come off.
  useEffect(() => {
    if (!focusRequest) return;
    const panel = panelRef.current;
    const target =
      focusRequest.kind === "chip"
        ? panel?.querySelector<HTMLElement>(
            `[data-testid="remove-queued-sub-${focusRequest.swap.offId}-${focusRequest.swap.onId}"]`,
          )
        : panel?.querySelector<HTMLElement>(
            '[data-testid^="sub-panel-off-"]:not([aria-disabled="true"])',
          );
    target?.focus();
    setFocusRequest(null);
  }, [focusRequest]);

  const handleApplyRecommendation = (offId: string, onId: string) => {
    setSelectedOff(offId);
    setSelectedBench(onId);
  };

  const handleInteractiveRowKeyDown = (event: KeyboardEvent<HTMLElement>, action: () => void) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      action();
      return;
    }
    if (event.key === "ContextMenu" || (event.shiftKey && event.key === "F10")) {
      event.preventDefault();
      event.currentTarget.dispatchEvent(
        new MouseEvent("contextmenu", { bubbles: true, cancelable: true }),
      );
    }
  };

  return (
    <Dialog
      labelledBy="sub-panel-title"
      panelRef={panelRef}
      onClose={onClose}
      dismissOnBackdrop
      overlayClassName="bg-overlay/70 backdrop-blur-sm p-4"
      className="flex max-h-[90vh] w-full max-w-5xl flex-col overflow-hidden rounded-panel transition-colors duration-300"
    >
      {/* Header */}
      <div className="flex shrink-0 items-center justify-between border-b border-line bg-linear-to-r to-panel px-5 py-3 from-panel">
        <div className="flex items-center gap-2.5">
          <RefreshCw className="h-4 w-4 text-warning" />
          <h3
            id="sub-panel-title"
            className="font-heading text-body font-bold uppercase tracking-labelst text-fg"
          >
            {t("match.substitutionsTitle")}
          </h3>
          <Badge variant={subsMade >= snapshot.max_subs ? "danger" : "primary"} size="sm">
            {t("match.subsUsed", { used: subsMade, max: snapshot.max_subs })}
          </Badge>
        </div>
        <DialogCloseButton onClose={onClose} />
      </div>

      {subsMade >= snapshot.max_subs ? (
        <div className="flex flex-1 items-center justify-center p-12">
          <div className="flex flex-col items-center gap-3">
            <AlertTriangle className="h-8 w-8 text-warning" />
            <p className="font-heading text-body font-bold uppercase tracking-label text-warning">
              {t("match.allSubsUsed")}
            </p>
          </div>
        </div>
      ) : (
        <>
          {/* Tactics strip — scenario, recommendation chips, quick selects */}
          <div className="flex shrink-0 flex-wrap items-center gap-x-3 gap-y-1.5 border-b border-line bg-sunken px-4 py-2">
            {/* Scenario + apply play style */}
            <div className="flex items-center gap-1.5">
              {getScenarioIcon(scenario.id)}
              <span className="font-heading text-caption font-bold uppercase tracking-labelst text-fg">
                {t(`match.subScenario.${scenario.id}.title`)}
              </span>
              <button
                type="button"
                data-testid="recommended-plan-cta"
                onClick={() => onPlayStyleChange(scenario.recommendedPlayStyle)}
                className="rounded-full border border-selected/25 bg-selected-tint px-2 py-0.5 font-heading text-caption font-bold uppercase tracking-labelst text-selected transition-colors hover:bg-selected-tint"
              >
                {t("match.recommendedPlan")}:{" "}
                {t(`common.playStyles.${scenario.recommendedPlayStyle}`)}
              </button>
            </div>

            {/* Recommendation chips */}
            {visibleRecommendations.length > 0 && (
              <div className="flex flex-wrap items-center gap-1">
                {visibleRecommendations.slice(0, 3).map(({ rec, offPlayer, onPlayer }) => (
                  <button
                    key={`${rec.offId}-${rec.onId}`}
                    type="button"
                    data-testid={`recommended-sub-${rec.offId}-${rec.onId}`}
                    onClick={() => handleApplyRecommendation(rec.offId, rec.onId)}
                    className="flex items-center gap-1 rounded-full border border-line bg-panel px-2 py-0.5 font-heading text-caption font-bold transition-colors hover:border-selected hover:bg-selected-tint"
                  >
                    <span className="text-danger">{offPlayer.name.split(" ").pop()}</span>
                    <span className="text-fg-subtle">→</span>
                    <span className="text-positive">{onPlayer.name.split(" ").pop()}</span>
                  </button>
                ))}
                {visibleRecommendations.length > 3 && (
                  <span className="font-heading text-caption text-fg-subtle">
                    +{visibleRecommendations.length - 3}
                  </span>
                )}
              </div>
            )}

            {/* Quick formation & play style selects */}
            <div className="ml-auto flex items-center gap-2">
              <Select
                value={FORMATIONS.includes(team.formation) ? team.formation : FORMATIONS[0]}
                onChange={(e) => onFormationChange(e.target.value)}
                aria-label={t("tactics.formation")}
                selectSize="xs"
              >
                {FORMATIONS.map((f) => (
                  <option key={f} value={f}>
                    {f}
                  </option>
                ))}
              </Select>
              <Select
                value={team.play_style}
                onChange={(e) => onPlayStyleChange(e.target.value)}
                aria-label={t("tactics.playStyle")}
                selectSize="xs"
              >
                {PLAY_STYLES.map((style) => (
                  <option key={style} value={style}>
                    {t(`common.playStyles.${style}`, style)}
                  </option>
                ))}
              </Select>
            </div>
          </div>

          <div className="shrink-0 border-b border-line px-4 py-2">
            <PlayerRolesPanel players={team.players} onChangeRole={onChangeRole} />
          </div>

          {/* Main body: two columns */}
          <div className="flex min-h-0 flex-1 overflow-hidden">
            {/* Left: formation pitch + on-field player list */}
            <div className="flex min-w-0 flex-1 flex-col border-r border-line">
              <div className="shrink-0 border-b border-line bg-sunken px-4 py-2">
                <p className="font-heading text-caption uppercase tracking-labelst text-danger">
                  {selectedOff
                    ? t("match.takingOff", { name: selectedPlayer?.name })
                    : t("match.selectPlayerOff")}
                </p>
              </div>

              {/* Formation pitch */}
              <FormationPitch
                formation={team.formation}
                players={team.players}
                sentOff={snapshot.sent_off}
                selectedId={selectedOff}
                subbedOnIds={subbedOnIds}
                queuedOffIds={queuedOffIds}
                onPlayerClick={handleSelectOffPlayer}
                className="mx-4 mt-3 h-[210px] shrink-0"
              />

              {/* On-field player table */}
              <div className="min-h-0 flex-1 overflow-auto px-4 py-2">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-line font-heading text-caption uppercase tracking-labelst text-fg-muted">
                      <th className="py-2 pr-2">{t("match.player")}</th>
                      <th className="w-12 py-2 text-center">{t("common.position")}</th>
                      <th className="w-12 py-2 text-center">{t("common.ovr")}</th>
                      <th className="w-24 py-2">{t("match.fitness")}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sortByPositionGroup(
                      team.players.filter((p) => !snapshot.sent_off.includes(p.id)),
                      positions,
                    ).map((p) => {
                      const isSelected = selectedOff === p.id;
                      const isSubOn = subbedOnIds.has(p.id);
                      const isQueuedOff = queuedOffIds.has(p.id);
                      const row = (
                        <tr
                          key={p.id}
                          data-testid={`sub-panel-off-${p.id}`}
                          onClick={() => handleSelectOffPlayer(p.id)}
                          onKeyDown={(e) =>
                            handleInteractiveRowKeyDown(e, () => handleSelectOffPlayer(p.id))
                          }
                          role="button"
                          tabIndex={0}
                          aria-pressed={isSelected}
                          aria-disabled={isQueuedOff}
                          className={`text-body transition-colors ${
                            isQueuedOff
                              ? "opacity-50"
                              : isSelected
                                ? "cursor-pointer bg-danger-tint"
                                : "cursor-pointer hover:bg-hover/50"
                          }`}
                        >
                          <td className="py-2 pr-2">
                            <div className="flex items-center gap-1.5">
                              {isSelected && (
                                <UserMinus className="h-3.5 w-3.5 shrink-0 text-danger" />
                              )}
                              {isSubOn && (
                                <span aria-hidden="true" className="text-caption text-positive">
                                  ▲
                                </span>
                              )}
                              {isQueuedOff && (
                                <span aria-hidden="true" className="text-caption text-danger">
                                  ▼
                                </span>
                              )}
                              <span
                                className={`truncate font-medium ${isSelected ? "text-danger" : "text-fg"}`}
                              >
                                {p.name}
                              </span>
                            </div>
                          </td>
                          <td className="w-12 py-2 text-center">
                            <span className="font-heading text-caption text-fg-muted">
                              {translatePositionAbbreviation(t, p.position)}
                            </span>
                          </td>
                          <td className="w-12 py-2 text-center font-heading font-bold text-fg-muted">
                            {p.ovr}
                          </td>
                          <td className="w-24 py-2">
                            <div className="flex items-center gap-1.5">
                              <div className="h-2 flex-1 overflow-hidden rounded-full bg-line-strong">
                                <div
                                  className={`h-full rounded-full ${condBgColor(p.condition)}`}
                                  style={{ width: `${p.condition}%` }}
                                />
                              </div>
                              <span
                                className={`w-7 text-right font-heading text-caption tabular-nums ${condColor(p.condition)}`}
                              >
                                {Math.round(p.condition)}
                              </span>
                            </div>
                          </td>
                        </tr>
                      );
                      return (
                        <ContextMenu
                          key={p.id}
                          items={[
                            isQueuedOff
                              ? {
                                  label: t("match.alreadyQueued"),
                                  icon: <UserMinus className="h-4 w-4" />,
                                  onClick: () => {},
                                  disabled: true,
                                }
                              : {
                                  label: isSelected
                                    ? t("common.cancel")
                                    : t("match.selectToTakeOff"),
                                  icon: <UserMinus className="h-4 w-4" />,
                                  onClick: () => handleSelectOffPlayer(p.id),
                                },
                          ]}
                        >
                          {row}
                        </ContextMenu>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Right: bench players (full column height) */}
            <div className="flex min-w-0 flex-1 flex-col">
              <div className="shrink-0 border-b border-line bg-sunken px-4 py-2">
                <p className="font-heading text-caption uppercase tracking-labelst text-positive">
                  {selectedOff ? t("match.selectReplacement") : t("match.benchPlayers")}
                </p>
              </div>

              {availableBench.length === 0 ? (
                <div className="flex flex-1 items-center justify-center">
                  <p className="text-caption text-fg-muted">{t("match.noBenchAvailable")}</p>
                </div>
              ) : (
                <div className="min-h-0 flex-1 overflow-auto px-4 py-2">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="border-b border-line font-heading text-caption uppercase tracking-labelst text-fg-muted">
                        <th className="py-2 pr-2">{t("match.player")}</th>
                        <th className="w-12 py-2 text-center">{t("common.position")}</th>
                        <th className="w-12 py-2 text-center">{t("common.ovr")}</th>
                        <th className="w-24 py-2">{t("match.fitness")}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {availableBench.map((p) => {
                        const posMatch = selectedPlayer
                          ? p.position === selectedPlayer.position
                          : true;
                        const benchRow = (
                          <tr
                            key={p.id}
                            data-testid={`sub-panel-bench-${p.id}`}
                            onClick={() => handleSelectBenchPlayer(p.id)}
                            onKeyDown={(e) =>
                              handleInteractiveRowKeyDown(e, () => handleSelectBenchPlayer(p.id))
                            }
                            role="button"
                            tabIndex={0}
                            aria-pressed={selectedBench === p.id}
                            aria-disabled={!selectedOff}
                            className={`text-body transition-colors ${
                              selectedOff
                                ? selectedBench === p.id
                                  ? "cursor-pointer bg-positive-tint ring-1 ring-positive/40"
                                  : "cursor-pointer hover:bg-positive-tint"
                                : "opacity-60"
                            }`}
                          >
                            <td className="py-2 pr-2">
                              <div className="flex items-center gap-1.5">
                                {selectedOff && (
                                  <UserPlus className="h-3.5 w-3.5 shrink-0 text-positive/50" />
                                )}
                                <span className="truncate font-medium text-fg">{p.name}</span>
                              </div>
                            </td>
                            <td className="w-12 py-2 text-center">
                              <span
                                className={`font-heading text-caption ${!posMatch && selectedOff ? "text-warning" : "text-fg-muted"}`}
                              >
                                {translatePositionAbbreviation(t, p.position)}
                                {!posMatch && selectedOff && " !"}
                              </span>
                            </td>
                            <td className="w-12 py-2 text-center font-heading font-bold text-fg-muted">
                              {p.ovr}
                            </td>
                            <td className="w-24 py-2">
                              <div className="flex items-center gap-1.5">
                                <div className="h-2 flex-1 overflow-hidden rounded-full bg-line-strong">
                                  <div
                                    className={`h-full rounded-full ${condBgColor(p.condition)}`}
                                    style={{ width: `${p.condition}%` }}
                                  />
                                </div>
                                <span
                                  className={`w-7 text-right font-heading text-caption tabular-nums ${condColor(p.condition)}`}
                                >
                                  {Math.round(p.condition)}
                                </span>
                              </div>
                            </td>
                          </tr>
                        );
                        return (
                          <ContextMenu
                            key={p.id}
                            items={
                              selectedOff
                                ? [
                                    {
                                      label:
                                        selectedBench === p.id
                                          ? t("match.clearReplacementSelection")
                                          : t("match.selectReplacementMenu"),
                                      icon: <UserPlus className="h-4 w-4" />,
                                      onClick: () => handleSelectBenchPlayer(p.id),
                                    },
                                  ]
                                : [
                                    {
                                      label: t("match.selectPlayerToTakeOffFirst"),
                                      icon: <UserPlus className="h-4 w-4" />,
                                      onClick: () => {},
                                      disabled: true,
                                    },
                                  ]
                            }
                          >
                            {benchRow}
                          </ContextMenu>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Sub history */}
              {snapshot.substitutions.filter((s) => s.side === side).length > 0 && (
                <div className="shrink-0 border-t border-line px-4 py-3">
                  <p className="mb-1.5 font-heading text-caption uppercase tracking-labelst text-fg-muted">
                    {t("match.history")}
                  </p>
                  {snapshot.substitutions
                    .filter((s) => s.side === side)
                    .map((sub, i) => (
                      <div key={i} className="flex items-center gap-1.5 py-0.5 text-caption">
                        <span className="w-5 text-right font-heading tabular-nums text-fg-muted">
                          {sub.minute}'
                        </span>
                        <span className="text-positive">▲</span>
                        <span className="truncate text-fg">
                          {getPlayerName(snapshot, sub.player_on_id)}
                        </span>
                        <span className="text-danger">▼</span>
                        <span className="truncate text-fg-muted">
                          {getPlayerName(snapshot, sub.player_off_id)}
                        </span>
                      </div>
                    ))}
                </div>
              )}
            </div>
          </div>

          {/* Sticky footer: the queue, comparison summary + queue / confirm / cancel */}
          <div className="shrink-0 border-t border-line bg-sunken px-4 py-3">
            {refusal && (
              <p
                role="alert"
                className="mb-3 rounded-control border border-danger/40 bg-danger-tint px-3 py-2 text-caption font-medium text-danger"
              >
                {t("match.substitutionRefused", {
                  off: getPlayerName(snapshot, refusal.swap.offId),
                  on: getPlayerName(snapshot, refusal.swap.onId),
                  reason: resolveBackendError(refusal.reason),
                })}
              </p>
            )}
            {refusal && refusal.appliedCount > 0 && (
              <p role="status" className="mb-3 text-caption text-fg-muted">
                {t("match.substitutionsPartlyMade", {
                  applied: refusal.appliedCount,
                  total: refusal.total,
                })}
              </p>
            )}
            {pendingSwaps.length > 0 && (
              <div className="mb-3 border-b border-line pb-3">
                <p className="mb-1.5 font-heading text-caption uppercase tracking-labelst text-fg-muted">
                  {t("match.queuedSubstitutions")}
                </p>
                <div className="flex flex-wrap items-center gap-2">
                  {pendingSwaps.map((swap) => (
                    <span
                      key={`${swap.offId}-${swap.onId}`}
                      data-testid={`queued-sub-${swap.offId}-${swap.onId}`}
                      className="flex items-center gap-1.5 rounded-full border border-line bg-panel px-2.5 py-1 font-heading text-caption font-bold"
                    >
                      <span className="text-danger">{getPlayerName(snapshot, swap.offId)}</span>
                      <span className="text-fg-subtle">→</span>
                      <span className="text-positive">{getPlayerName(snapshot, swap.onId)}</span>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        data-testid={`remove-queued-sub-${swap.offId}-${swap.onId}`}
                        onClick={() => handleRemoveQueuedSwap(swap)}
                        disabled={isSubmitting}
                        aria-label={t("match.removeQueuedSubstitution", {
                          off: getPlayerName(snapshot, swap.offId),
                          on: getPlayerName(snapshot, swap.onId),
                        })}
                        className="px-1.5! py-0.5! normal-case"
                      >
                        <span aria-hidden="true">✕</span>
                      </Button>
                    </span>
                  ))}
                  {!(selectedPlayer && comparedPlayer) && (
                    <Button
                      type="button"
                      size="sm"
                      onClick={handleConfirmSubstitutions}
                      disabled={isSubmitting}
                      className="ml-auto"
                    >
                      {t("match.confirmAllSubstitutions", { count: pendingSwaps.length })}
                    </Button>
                  )}
                </div>
              </div>
            )}
            {selectedPlayer && comparedPlayer ? (
              <div>
                {/* Player names + position match + action buttons */}
                <div className="mb-2 flex flex-wrap items-center gap-x-3 gap-y-1.5">
                  <div className="flex items-center gap-1.5">
                    <UserMinus className="h-3.5 w-3.5 shrink-0 text-danger" />
                    <span className="max-w-[110px] truncate font-heading text-body font-bold text-danger">
                      {selectedPlayer.name}
                    </span>
                    <span className="text-fg-subtle">→</span>
                    <span className="max-w-[110px] truncate font-heading text-body font-bold text-positive">
                      {comparedPlayer.name}
                    </span>
                    <UserPlus className="h-3.5 w-3.5 shrink-0 text-positive" />
                  </div>
                  <span
                    className={`font-heading text-caption font-bold uppercase tracking-label ${
                      comparedPlayer.position === selectedPlayer.position
                        ? "text-positive"
                        : "text-warning"
                    }`}
                  >
                    {comparedPlayer.position === selectedPlayer.position
                      ? t("match.fitExact")
                      : t("match.fitAdjusted")}
                  </span>
                  <div className="ml-auto flex items-center gap-2">
                    <Button type="button" variant="ghost" size="sm" onClick={handleClearSelection}>
                      {t("common.cancel")}
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={handleQueueSubstitution}
                      disabled={substitutionsLeft < 1 || isSubmitting}
                    >
                      {t("match.queueSubstitution")}
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      onClick={handleConfirmSubstitutions}
                      disabled={confirmCount === 0 || isSubmitting}
                    >
                      {pendingSwaps.length === 0
                        ? t("match.confirmSubstitution")
                        : pairToCommit
                          ? t("match.confirmSubstitutions", { count: confirmCount })
                          : t("match.confirmAllSubstitutions", { count: confirmCount })}
                    </Button>
                  </div>
                </div>
                {/* Attribute comparison bars */}
                <div className="grid grid-cols-2 gap-x-4">
                  <CompareBar label="OVR" valA={selectedPlayer.ovr} valB={comparedPlayer.ovr} />
                  <CompareBar label="PAC" valA={selectedPlayer.pace} valB={comparedPlayer.pace} />
                  <CompareBar
                    label="PAS"
                    valA={selectedPlayer.passing}
                    valB={comparedPlayer.passing}
                  />
                  <CompareBar
                    label="SHO"
                    valA={selectedPlayer.shooting}
                    valB={comparedPlayer.shooting}
                  />
                  <CompareBar
                    label="TAC"
                    valA={selectedPlayer.tackling}
                    valB={comparedPlayer.tackling}
                  />
                  <CompareBar
                    label="COND"
                    valA={Math.round(selectedPlayer.condition)}
                    valB={Math.round(comparedPlayer.condition)}
                  />
                </div>
              </div>
            ) : selectedPlayer ? (
              <div className="flex items-center gap-2">
                <UserMinus className="h-3.5 w-3.5 text-danger" />
                <span className="font-heading text-body font-bold text-danger">
                  {selectedPlayer.name}
                </span>
                <span className="text-fg-subtle">—</span>
                <span className="font-heading text-caption uppercase tracking-label text-fg-muted">
                  {t("match.selectBenchToCompare")}
                </span>
              </div>
            ) : (
              <p className="text-center font-heading text-caption uppercase tracking-labelst text-fg-muted">
                {t("match.selectPlayerOff")}
              </p>
            )}
          </div>
        </>
      )}
    </Dialog>
  );
}
