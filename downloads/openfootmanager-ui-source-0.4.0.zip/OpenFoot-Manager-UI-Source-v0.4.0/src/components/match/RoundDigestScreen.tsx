import { useState } from "react";
import { useTranslation } from "react-i18next";
import type { FixtureData, GameStateData } from "../../store/gameStore";
import type { CompactMatchEventData } from "../../store/types";
import type { CupRoundSummary, MatchSnapshot, MatchEvent, RoundSummary } from "./types";
import CupRoundSection from "./CupRoundSection";
import { getEventDisplay, makeTeamFallback } from "./helpers";
import { QuickStat } from "./PostMatchHelpers";
import { Badge, Dialog, TeamLogo } from "../ui";
import { Trophy, TrendingDown, Minus, ChevronRight, ArrowUp, ArrowDown, Flame } from "lucide-react";

interface RoundDigestScreenProps {
  snapshot: MatchSnapshot;
  gameState: GameStateData;
  currentFixture: FixtureData | null;
  userSide: "Home" | "Away" | null;
  roundSummary: RoundSummary | null;
  cupRoundSummaries?: CupRoundSummary[];
  onPressConference: () => void;
  onFinish: () => void;
}
interface OtherMatchEntry {
  fixture: FixtureData;
  homeTeamName: string;
  awayTeamName: string;
}

export default function RoundDigestScreen({
  snapshot,
  gameState,
  currentFixture,
  userSide,
  roundSummary,
  cupRoundSummaries = [],
  onPressConference,
  onFinish,
}: RoundDigestScreenProps) {
  const { t } = useTranslation();
  const [selectedOtherFixtureId, setSelectedOtherFixtureId] = useState<string | null>(null);

  const userTeamId = gameState.manager.team_id;

  const getTeamNameById = (teamId: string) =>
    gameState.teams.find((team) => team.id === teamId)?.name || teamId;

  const getTeamShortName = (teamId: string, fallbackName: string) =>
    gameState.teams.find((team) => team.id === teamId)?.short_name ||
    fallbackName.substring(0, 3).toUpperCase();

  const getPlayerDisplayName = (playerId: string | null | undefined) => {
    if (!playerId) return t("common.unknown");
    return gameState.players.find((player) => player.id === playerId)?.match_name || playerId;
  };

  const getFixtureReport = (fixture: FixtureData | null | undefined) =>
    fixture?.result?.report || null;

  const formatOtherMatchScorers = (fixture: FixtureData) => {
    if (!fixture.result) return null;
    const scorers = [...fixture.result.home_scorers, ...fixture.result.away_scorers]
      .sort((a, b) => a.minute - b.minute)
      .map((s) => `${getPlayerDisplayName(s.player_id)} ${s.minute}'`);
    if (scorers.length === 0) return null;
    return scorers.slice(0, 3).join(" • ");
  };

  const formatOtherMatchStats = (fixture: FixtureData) => {
    const report = getFixtureReport(fixture);
    if (!report) return null;
    const totalYellow = report.home_stats.yellow_cards + report.away_stats.yellow_cards;
    return [
      `${report.home_stats.possession_pct}-${report.away_stats.possession_pct} ${t("match.possession")}`,
      `${report.home_stats.shots + report.away_stats.shots} ${t("match.shots")}`,
      `${totalYellow} ${t("match.yellowCards")}`,
    ].join(" • ");
  };

  const formatOtherMatchEvent = (event: CompactMatchEventData) => {
    const primary = getPlayerDisplayName(event.player_id);
    switch (event.event_type) {
      case "Goal":
        return event.secondary_player_id
          ? `${primary} (${t("match.assist", { name: getPlayerDisplayName(event.secondary_player_id) })})`
          : primary;
      case "PenaltyGoal":
        return `${primary} (P)`;
      case "PenaltyMiss":
        return `${primary} (PM)`;
      case "Substitution":
        return `${primary} ${t("match.subFor", { name: getPlayerDisplayName(event.secondary_player_id) })}`;
      default:
        return primary;
    }
  };

  // Two facts, not one flag: whether the league played a round the backend summarised, and
  // whether the user's own match was in it (it is when the summary lists the fixture the user
  // played). A cup tie on a day the league also played is the second without the first.
  const userPlayedInLeagueRound =
    roundSummary?.completed_results.some((r) => r.fixture_id === currentFixture?.id) ?? false;

  const leagueRoundEntries: OtherMatchEntry[] = (roundSummary?.completed_results ?? [])
    .filter((r) => r.fixture_id !== currentFixture?.id)
    .flatMap((r) => {
      const fixture = gameState.league?.fixtures.find((f) => f.id === r.fixture_id);
      return fixture?.result
        ? [{ fixture, homeTeamName: r.home_team_name, awayTeamName: r.away_team_name }]
        : [];
    });

  const competitionEntries: OtherMatchEntry[] = userPlayedInLeagueRound
    ? []
    : (gameState.league?.fixtures || [])
        .filter(
          (f) =>
            f.id !== currentFixture?.id &&
            f.status === "Completed" &&
            f.result &&
            f.date === currentFixture?.date &&
            f.competition === currentFixture?.competition,
        )
        .map((f) => ({
          fixture: f,
          homeTeamName: getTeamNameById(f.home_team_id),
          awayTeamName: getTeamNameById(f.away_team_id),
        }));

  const selectedOtherFixture = selectedOtherFixtureId
    ? [...leagueRoundEntries, ...competitionEntries].find(
        (e) => e.fixture.id === selectedOtherFixtureId,
      )?.fixture || null
    : null;
  const selectedOtherFixtureReport = getFixtureReport(selectedOtherFixture);

  // User result
  const homeFullTeam = gameState.teams.find((t) => t.id === snapshot.home_team.id);
  const awayFullTeam = gameState.teams.find((t) => t.id === snapshot.away_team.id);
  const homeTeamColor = homeFullTeam?.colors?.primary || "#10b981";
  const awayTeamColor = awayFullTeam?.colors?.primary || "#6366f1";

  const resultType =
    userSide === "Home"
      ? snapshot.home_score > snapshot.away_score
        ? "win"
        : snapshot.home_score < snapshot.away_score
          ? "loss"
          : "draw"
      : userSide === "Away"
        ? snapshot.away_score > snapshot.home_score
          ? "win"
          : snapshot.away_score < snapshot.home_score
            ? "loss"
            : "draw"
        : "neutral";

  // Position context from standings delta
  const userStanding = roundSummary?.standings_delta.find((s) => s.team_id === userTeamId);
  const positionChange = userStanding
    ? userStanding.previous_position - userStanding.current_position
    : 0;

  const leagueName = gameState.league?.name;
  const matchdayLabel = roundSummary
    ? t("schedule.matchday", { number: roundSummary.matchday })
    : null;
  const headingParts = [matchdayLabel, leagueName].filter(Boolean).join(" — ");

  const renderMatchCards = (entries: OtherMatchEntry[], unavailableKey: string) => (
    <>
      {entries.length > 0 ? (
        <div className="grid grid-cols-2 gap-3">
          {entries.map((entry) => {
            const scorerSummary = formatOtherMatchScorers(entry.fixture);
            const statSummary = formatOtherMatchStats(entry.fixture);
            return (
              <div
                key={entry.fixture.id}
                className="bg-panel rounded-panel border border-line shadow-sm px-4 py-3 transition-colors duration-300"
              >
                <div className="flex items-center justify-between gap-2 mb-1">
                  <span className="font-heading font-bold text-body text-fg truncate">
                    {entry.homeTeamName} {entry.fixture.result?.home_goals} –{" "}
                    {entry.fixture.result?.away_goals} {entry.awayTeamName}
                  </span>
                  {entry.fixture.result?.report && (
                    <button
                      type="button"
                      onClick={() => setSelectedOtherFixtureId(entry.fixture.id)}
                      className="shrink-0 text-caption font-heading font-bold uppercase tracking-labelst text-warning hover:text-warning transition-colors"
                    >
                      {t("match.viewDetails")}
                    </button>
                  )}
                </div>
                {scorerSummary && <p className="text-caption text-fg-muted">{scorerSummary}</p>}
                {statSummary && (
                  <p className="mt-0.5 text-caption uppercase tracking-label text-fg-subtle">
                    {statSummary}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      ) : (
        <p className="text-body text-fg-muted">{t(unavailableKey)}</p>
      )}
    </>
  );

  const leagueSideColumn = roundSummary ? (
    <div className="flex flex-col gap-4">
      {/* Standings */}
      <div className="bg-panel rounded-panel border border-line shadow-sm p-4 transition-colors duration-300">
        <h3 className="text-caption font-heading font-bold uppercase tracking-labelst text-fg-muted mb-3">
          {t("tournaments.leagueTable")}
        </h3>
        <div className="flex flex-col gap-1.5">
          {roundSummary.standings_delta.slice(0, 6).map((entry) => {
            const change = entry.previous_position - entry.current_position;
            const isUserTeam = entry.team_id === userTeamId;
            return (
              <div
                key={entry.team_id}
                className={`flex items-center gap-2 text-caption rounded-md px-2 py-1 ${
                  isUserTeam ? "bg-selected-tint font-bold" : ""
                }`}
              >
                <span className="w-4 text-right tabular-nums text-fg-muted font-heading">
                  {entry.current_position}
                </span>
                {change > 0 ? (
                  <ArrowUp className="w-3 h-3 text-positive shrink-0" />
                ) : change < 0 ? (
                  <ArrowDown className="w-3 h-3 text-danger shrink-0" />
                ) : (
                  <span className="w-3 shrink-0" />
                )}
                <span className={`truncate flex-1 ${isUserTeam ? "text-selected" : "text-fg"}`}>
                  {entry.team_name}
                </span>
                <span className="font-heading font-bold tabular-nums text-fg-muted">
                  {entry.points}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Top Scorers */}
      {roundSummary.top_scorer_delta.length > 0 && (
        <div className="bg-panel rounded-panel border border-line shadow-sm p-4 transition-colors duration-300">
          <h3 className="text-caption font-heading font-bold uppercase tracking-labelst text-fg-muted mb-3">
            {t("tournaments.topScorers")}
          </h3>
          <div className="flex flex-col gap-1.5">
            {roundSummary.top_scorer_delta.slice(0, 5).map((entry) => {
              const isUserTeamScorer = entry.team_id === userTeamId;
              return (
                <div key={entry.player_id} className="flex items-center gap-2 text-caption">
                  <span className="w-4 text-right tabular-nums text-fg-muted font-heading">
                    {entry.current_rank}.
                  </span>
                  <span
                    className={`truncate flex-1 ${isUserTeamScorer ? "font-bold text-selected" : "text-fg"}`}
                  >
                    {entry.player_name}
                  </span>
                  <span className="font-heading font-bold tabular-nums text-warning">
                    {entry.current_goals}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  ) : null;

  return (
    <div className="min-h-screen bg-hover text-fg flex flex-col transition-colors duration-300">
      {/* Header */}
      <header className="bg-panel border-b border-line px-6 py-4 transition-colors duration-300">
        <div className="flex items-center justify-between">
          <div>
            {headingParts && (
              <p className="text-caption font-heading uppercase tracking-labelst text-fg-muted mb-0.5">
                {headingParts}
              </p>
            )}
            <h1 className="text-lead font-heading font-bold text-fg">
              {userPlayedInLeagueRound ? t("match.roundSummary") : t("match.otherMatches")}
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onFinish}
              className="px-4 py-2 bg-hover hover:bg-hover rounded-control font-heading font-bold uppercase tracking-label text-body text-fg transition-colors"
            >
              {t("match.skip")}
            </button>
            <button
              type="button"
              onClick={onPressConference}
              className="flex items-center gap-2 px-5 py-2 bg-linear-to-r from-selected-fill to-selected-fill rounded-control font-heading font-bold uppercase tracking-label text-body text-on-brand shadow-md shadow-card transition-all"
            >
              {t("match.pressConference")}
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="flex-1 overflow-auto">
        <div className="px-6 py-6 flex flex-col gap-6">
          {/* Your Result Hero Card */}
          <div
            className={`rounded-panel border p-6 transition-colors duration-300 ${
              resultType === "win"
                ? "bg-linear-to-r to-panel from-selected-tint/30 border-selected/50"
                : resultType === "loss"
                  ? "bg-linear-to-r to-panel from-danger-tint/20 border-danger/50"
                  : "bg-panel border-line"
            }`}
          >
            <div className="flex items-center justify-between mb-4">
              <p className="text-caption font-heading uppercase tracking-labelst text-fg-muted">
                {t("match.yourResult")}
              </p>
              <div className="flex items-center gap-1.5">
                {resultType === "win" && (
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-selected-tint rounded-full">
                    <Trophy className="w-3.5 h-3.5 text-warning" />
                    <span className="font-heading font-bold text-caption uppercase tracking-labelst text-selected">
                      {t("match.victory")}
                    </span>
                  </div>
                )}
                {resultType === "loss" && (
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-danger-tint rounded-full">
                    <TrendingDown className="w-3.5 h-3.5 text-danger" />
                    <span className="font-heading font-bold text-caption uppercase tracking-labelst text-danger">
                      {t("match.defeat")}
                    </span>
                  </div>
                )}
                {resultType === "draw" && (
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-hover rounded-full">
                    <Minus className="w-3.5 h-3.5 text-fg-muted" />
                    <span className="font-heading font-bold text-caption uppercase tracking-labelst text-fg-muted">
                      {t("match.draw")}
                    </span>
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center justify-center gap-8">
              <div className="flex items-center gap-3">
                <TeamLogo
                  team={homeFullTeam ?? makeTeamFallback(snapshot.home_team.name)}
                  className="w-12 h-12 rounded-panel flex items-center justify-center font-heading font-bold overflow-hidden"
                  imageClassName="h-9 w-9 object-contain drop-shadow"
                  style={{
                    backgroundColor: `${homeTeamColor}30`,
                    borderColor: homeTeamColor,
                    borderWidth: 2,
                  }}
                />
                <p className="font-heading font-bold text-fg">{snapshot.home_team.name}</p>
              </div>
              <div className="flex items-center gap-4">
                <span className="text-display font-heading font-bold text-fg tabular-nums">
                  {snapshot.home_score}
                </span>
                <span className="text-title font-heading text-fg-subtle">–</span>
                <span className="text-display font-heading font-bold text-fg tabular-nums">
                  {snapshot.away_score}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <p className="font-heading font-bold text-fg">{snapshot.away_team.name}</p>
                <TeamLogo
                  team={awayFullTeam ?? makeTeamFallback(snapshot.away_team.name)}
                  className="w-12 h-12 rounded-panel flex items-center justify-center font-heading font-bold overflow-hidden"
                  imageClassName="h-9 w-9 object-contain drop-shadow"
                  style={{
                    backgroundColor: `${awayTeamColor}30`,
                    borderColor: awayTeamColor,
                    borderWidth: 2,
                  }}
                />
              </div>
            </div>

            {/* Position context */}
            {userPlayedInLeagueRound && userStanding && (
              <div className="mt-4 flex items-center justify-center gap-2">
                {positionChange > 0 ? (
                  <ArrowUp className="w-4 h-4 text-positive" />
                ) : positionChange < 0 ? (
                  <ArrowDown className="w-4 h-4 text-danger" />
                ) : null}
                <p className="text-body font-heading font-bold text-fg-muted">
                  #{userStanding.current_position} ·{" "}
                  <span className="text-warning">
                    {userStanding.points} {t("match.pts")}
                  </span>
                </p>
              </div>
            )}
          </div>

          {/* Main content grid */}
          <div className="grid grid-cols-3 gap-6">
            {userPlayedInLeagueRound ? (
              <>
                {/* The league round the user played in: its other results, with the table beside them */}
                <div className="flex flex-col gap-3 col-span-2">
                  <h2 className="text-caption font-heading font-bold uppercase tracking-labelst text-fg-muted">
                    {t("match.otherMatchesToday")}
                  </h2>
                  {renderMatchCards(leagueRoundEntries, "match.roundSummaryUnavailable")}
                </div>
                {leagueSideColumn}
              </>
            ) : (
              <div className="flex flex-col gap-3 col-span-3">
                <h2 className="text-caption font-heading font-bold uppercase tracking-labelst text-fg-muted">
                  {t("match.otherMatches")}
                </h2>
                {renderMatchCards(competitionEntries, "match.otherMatchesUnavailable")}
              </div>
            )}
          </div>

          {cupRoundSummaries.map((summary) => (
            <CupRoundSection key={summary.competition_id} summary={summary} />
          ))}

          {/* The user's match was not in the league round (a cup tie, say) but the league played
              too: the round and the table, beneath the match the user played */}
          {roundSummary && !userPlayedInLeagueRound && (
            <div className="grid grid-cols-3 gap-6">
              <div className="flex flex-col gap-3 col-span-2">
                <h2 className="text-caption font-heading font-bold uppercase tracking-labelst text-fg-muted">
                  {t("match.elsewhereInYourLeague")}
                </h2>
                {renderMatchCards(leagueRoundEntries, "match.roundSummaryUnavailable")}
              </div>
              {leagueSideColumn}
            </div>
          )}

          {/* Notable Upset */}
          {roundSummary?.notable_upset && (
            <div className="bg-panel rounded-panel border border-line shadow-sm p-4 flex items-center gap-4 transition-colors duration-300">
              <div className="w-8 h-8 rounded-control bg-warning-tint/20 flex items-center justify-center shrink-0">
                <Flame className="w-4 h-4 text-warning" />
              </div>
              <div>
                <p className="text-caption font-heading font-bold uppercase tracking-labelst text-warning mb-0.5">
                  {t("match.notableUpset")}
                </p>
                <p className="text-body font-heading font-bold text-fg">
                  {roundSummary.notable_upset.underdog_team_name}{" "}
                  {roundSummary.notable_upset.home_goals} – {roundSummary.notable_upset.away_goals}{" "}
                  {roundSummary.notable_upset.favorite_team_name}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Other Match Detail Modal */}
      {selectedOtherFixture && selectedOtherFixtureReport && (
        <Dialog
          label={t("match.matchDetails")}
          onClose={() => setSelectedOtherFixtureId(null)}
          dismissOnBackdrop
          overlayClassName="bg-overlay/70 px-4"
          surfaceClassName="bg-panel"
          className="w-full max-w-3xl rounded-panel transition-colors duration-300"
        >
          <div className="flex items-center justify-between border-b border-line px-5 py-4">
            <div>
              <p className="text-caption font-heading uppercase tracking-labelst text-fg-muted">
                {t("match.matchDetails")}
              </p>
              <p className="text-lead font-heading font-bold text-fg">
                {getTeamNameById(selectedOtherFixture.home_team_id)}{" "}
                {selectedOtherFixture.result?.home_goals} –{" "}
                {selectedOtherFixture.result?.away_goals}{" "}
                {getTeamNameById(selectedOtherFixture.away_team_id)}
              </p>
            </div>
            <button
              type="button"
              onClick={() => setSelectedOtherFixtureId(null)}
              className="rounded-control px-3 py-2 text-body font-heading font-bold uppercase tracking-label text-fg-muted hover:bg-hover hover:text-fg transition-colors"
            >
              {t("common.close")}
            </button>
          </div>

          <div className="grid gap-5 p-5 md:grid-cols-[1.15fr_0.85fr]">
            <div className="rounded-panel border border-line bg-sunken p-4 transition-colors duration-300">
              <h4 className="mb-3 text-caption font-heading font-bold uppercase tracking-labelst text-fg-muted">
                {t("match.matchEvents")}
              </h4>
              {selectedOtherFixtureReport.events.length > 0 ? (
                <div className="flex max-h-96 flex-col gap-2 overflow-auto">
                  {selectedOtherFixtureReport.events.map((event, index) => {
                    const display = getEventDisplay({
                      ...event,
                      zone: "Midfield",
                    } as MatchEvent);
                    const sideTeamId =
                      event.side === "Home"
                        ? selectedOtherFixture.home_team_id
                        : selectedOtherFixture.away_team_id;
                    const sideFallbackName =
                      event.side === "Home"
                        ? getTeamNameById(selectedOtherFixture.home_team_id)
                        : getTeamNameById(selectedOtherFixture.away_team_id);
                    return (
                      <div
                        key={`${event.minute}-${event.event_type}-${index}`}
                        className="flex items-center gap-2 text-caption"
                      >
                        <span className="w-8 text-right font-heading tabular-nums text-fg-muted">
                          {event.minute}'
                        </span>
                        <span>{display.icon}</span>
                        <span className={`${display.color} flex-1 truncate font-medium`}>
                          {formatOtherMatchEvent(event)}
                        </span>
                        <Badge variant={event.side === "Home" ? "primary" : "accent"} size="sm">
                          {getTeamShortName(sideTeamId, sideFallbackName)}
                        </Badge>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <p className="text-caption text-fg-muted">{t("match.quietMatch")}</p>
              )}
            </div>

            <div className="flex flex-col gap-4">
              <div className="rounded-panel border border-line bg-sunken p-4 transition-colors duration-300">
                <h4 className="mb-3 text-caption font-heading font-bold uppercase tracking-labelst text-fg-muted">
                  {t("match.quickStats")}
                </h4>
                <QuickStat
                  label={t("match.possession")}
                  home={`${selectedOtherFixtureReport.home_stats.possession_pct}%`}
                  away={`${selectedOtherFixtureReport.away_stats.possession_pct}%`}
                  homePct={selectedOtherFixtureReport.home_stats.possession_pct}
                />
                <QuickStat
                  label={t("match.shots")}
                  home={selectedOtherFixtureReport.home_stats.shots}
                  away={selectedOtherFixtureReport.away_stats.shots}
                />
                <QuickStat
                  label={t("match.shotsOnTarget")}
                  home={selectedOtherFixtureReport.home_stats.shots_on_target}
                  away={selectedOtherFixtureReport.away_stats.shots_on_target}
                />
                <QuickStat
                  label={t("match.fouls")}
                  home={selectedOtherFixtureReport.home_stats.fouls}
                  away={selectedOtherFixtureReport.away_stats.fouls}
                />
                <QuickStat
                  label={t("match.corners")}
                  home={selectedOtherFixtureReport.home_stats.corners}
                  away={selectedOtherFixtureReport.away_stats.corners}
                />
                <QuickStat
                  label={t("match.yellowCards")}
                  home={selectedOtherFixtureReport.home_stats.yellow_cards}
                  away={selectedOtherFixtureReport.away_stats.yellow_cards}
                />
              </div>
              <div className="rounded-panel border border-line bg-sunken p-4 transition-colors duration-300">
                <h4 className="mb-3 text-caption font-heading font-bold uppercase tracking-labelst text-fg-muted">
                  {t("match.scorers")}
                </h4>
                {formatOtherMatchScorers(selectedOtherFixture) ? (
                  <p className="text-caption text-fg">
                    {formatOtherMatchScorers(selectedOtherFixture)}
                  </p>
                ) : (
                  <p className="text-caption text-fg-muted">{t("match.noGoals")}</p>
                )}
              </div>
            </div>
          </div>
        </Dialog>
      )}
    </div>
  );
}
