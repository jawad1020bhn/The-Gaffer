import { useState } from "react";
import { useTranslation } from "react-i18next";
import type { TFunction } from "i18next";
import type { GameStateData } from "../../store/gameStore";
import type { MatchSnapshot } from "./types";
import { Badge } from "../ui";
import { ChevronRight, Mic, MessageSquare } from "lucide-react";
import { invokeForCareer } from "../../services/careerInvoke";

interface PressConferenceProps {
  snapshot: MatchSnapshot;
  gameState: GameStateData;
  userSide: "Home" | "Away";
  onFinish: () => void;
  onGameUpdate?: (game: GameStateData) => void;
}

interface PressQuestion {
  id: string;
  journalist: string;
  outlet: string;
  question: string;
  responses: PressResponse[];
}

interface PressResponse {
  id: string;
  tone: string;
  text: string;
  textKey: string;
  textParams?: Record<string, string>;
}

interface AnswerPayload {
  question_id: string;
  response_id: string;
  response_tone: string;
  response_text: string;
  response_text_key: string;
  response_text_params?: Record<string, string>;
  question_text: string;
  player_id?: string;
}

interface PlayerFocusQuestion extends PressQuestion {
  playerId?: string;
}

function response(
  t: TFunction,
  id: string,
  key: string,
  params?: Record<string, string | number>,
): PressResponse {
  const textKey = `${key}.text`;
  const textParams = params
    ? Object.fromEntries(
        Object.entries(params).map(([paramKey, value]) => [paramKey, String(value)]),
      )
    : undefined;

  return {
    id,
    tone: t(`${key}.tone`, params),
    text: t(textKey, params),
    textKey,
    textParams,
  };
}

function generateQuestions(
  snapshot: MatchSnapshot,
  userSide: "Home" | "Away",
  _gameState: GameStateData,
  t: TFunction,
): PlayerFocusQuestion[] {
  const userScore = userSide === "Home" ? snapshot.home_score : snapshot.away_score;
  const oppScore = userSide === "Home" ? snapshot.away_score : snapshot.home_score;
  const oppName = userSide === "Home" ? snapshot.away_team.name : snapshot.home_team.name;
  const userTeam = userSide === "Home" ? snapshot.home_team : snapshot.away_team;
  const isWin = userScore > oppScore;
  const isLoss = userScore < oppScore;

  const questions: PlayerFocusQuestion[] = [];

  // 1. Result question
  questions.push({
    id: "result",
    journalist: "David Thomson",
    outlet: "Sports Daily",
    question: isWin
      ? t("match.press.result.questions.win", { userScore, oppScore, oppName })
      : isLoss
        ? t("match.press.result.questions.loss", {
            userScore,
            oppScore,
            oppName,
          })
        : t("match.press.result.questions.draw", {
            userScore,
            oppScore,
            oppName,
          }),
    responses: isWin
      ? [
          response(t, "humble", "match.press.result.responses.win.humble"),
          response(t, "confident", "match.press.result.responses.win.confident"),
          response(t, "deflect", "match.press.result.responses.win.deflect"),
        ]
      : isLoss
        ? [
            response(t, "accept", "match.press.result.responses.loss.accept"),
            response(t, "defiant", "match.press.result.responses.loss.defiant"),
            response(t, "deflect", "match.press.result.responses.loss.deflect"),
          ]
        : [
            response(t, "fair", "match.press.result.responses.draw.fair"),
            response(t, "frustrated", "match.press.result.responses.draw.frustrated"),
            response(t, "positive", "match.press.result.responses.draw.positive"),
          ],
  });

  // 2. Player-focused question — pick a notable player
  const goalEvents = snapshot.events.filter(
    (e) =>
      e.side === userSide &&
      (e.event_type === "Goal" || e.event_type === "PenaltyGoal") &&
      e.player_id,
  );
  const focusPlayer =
    goalEvents.length > 0
      ? userTeam.players.find((p) => p.id === goalEvents[0].player_id)
      : userTeam.players[Math.floor(Math.random() * Math.min(userTeam.players.length, 5))];
  if (focusPlayer) {
    const scored = goalEvents.some((e) => e.player_id === focusPlayer!.id);
    const playerName = focusPlayer.name;
    questions.push({
      id: "player_focus",
      journalist: "Rachel Cooper",
      outlet: "Match Day Live",
      playerId: focusPlayer.id,
      question: scored
        ? t("match.press.playerFocus.questions.scored", { playerName })
        : t("match.press.playerFocus.questions.default", { playerName }),
      responses: [
        response(t, "praise", "match.press.playerFocus.responses.praise", {
          playerName,
        }),
        response(t, "demanding", "match.press.playerFocus.responses.demanding", { playerName }),
        response(t, "deflect", "match.press.playerFocus.responses.deflect", {
          playerName,
        }),
      ],
    });
  }

  // 3. Tactical question
  questions.push({
    id: "tactics",
    journalist: "Sarah Mitchell",
    outlet: "Football Weekly",
    question: t("match.press.tactics.question"),
    responses: [
      response(t, "detailed", "match.press.tactics.responses.detailed"),
      response(t, "brief", "match.press.tactics.responses.brief"),
      response(t, "evasive", "match.press.tactics.responses.evasive"),
    ],
  });

  // 4. Fan/atmosphere question (contextual)
  const fanQuestions: PlayerFocusQuestion[] = [
    {
      id: "fans",
      journalist: "James O'Brien",
      outlet: "Supporters' Voice",
      question: isWin
        ? t("match.press.fans.questions.win")
        : isLoss
          ? t("match.press.fans.questions.loss")
          : t("match.press.fans.questions.draw"),
      responses: isWin
        ? [
            response(t, "grateful", "match.press.fans.responses.win.grateful"),
            response(t, "shared", "match.press.fans.responses.win.shared"),
            response(t, "deflect", "match.press.fans.responses.win.deflect"),
          ]
        : isLoss
          ? [
              response(t, "apologize", "match.press.fans.responses.loss.apologize"),
              response(t, "patience", "match.press.fans.responses.loss.patience"),
              response(t, "curt", "match.press.fans.responses.loss.curt"),
            ]
          : [
              response(t, "appreciate", "match.press.fans.responses.draw.appreciate"),
              response(t, "understand", "match.press.fans.responses.draw.understand"),
              response(t, "curt", "match.press.fans.responses.draw.curt"),
            ],
    },
  ];
  questions.push(fanQuestions[0]);

  // 5. Looking ahead
  questions.push({
    id: "ahead",
    journalist: "Mark Williams",
    outlet: "The Athletic",
    question: t("match.press.ahead.question"),
    responses: [
      response(t, "focused", "match.press.ahead.responses.focused"),
      response(t, "ambitious", "match.press.ahead.responses.ambitious"),
      response(t, "curt", "match.press.ahead.responses.curt"),
    ],
  });

  return questions;
}

export default function PressConference({
  snapshot,
  gameState,
  userSide,
  onFinish,
  onGameUpdate,
}: PressConferenceProps) {
  const { t } = useTranslation();
  const [questions] = useState(() => generateQuestions(snapshot, userSide, gameState, t));
  const [currentIdx, setCurrentIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  const currentQ = questions[currentIdx];
  const isLastQuestion = currentIdx === questions.length - 1;
  const hasAnswered = currentQ ? !!answers[currentQ.id] : false;

  const handleAnswer = (responseId: string) => {
    if (!currentQ) return;
    setAnswers((prev) => ({ ...prev, [currentQ.id]: responseId }));
  };

  const submitToBackend = async () => {
    setSubmitting(true);
    try {
      const payloads: AnswerPayload[] = questions
        .map((q) => {
          const rid = answers[q.id];
          const resp = q.responses.find((r) => r.id === rid);
          return {
            question_id: q.id,
            response_id: rid || "",
            response_tone: resp?.tone || "",
            response_text: resp?.text || "",
            response_text_key: resp?.textKey || "",
            response_text_params: resp?.textParams,
            question_text: q.question,
            player_id: (q as PlayerFocusQuestion).playerId || "",
          };
        })
        .filter((p) => p.response_id);

      const result = await invokeForCareer<{
        game: GameStateData;
        morale_delta: number;
      }>("submit_press_conference", {
        answers: payloads,
      });
      if (result.game && onGameUpdate) {
        onGameUpdate(result.game);
      }
    } catch (err) {
      console.error("Failed to submit press conference:", err);
    } finally {
      setSubmitting(false);
      onFinish();
    }
  };

  const handleNext = () => {
    if (isLastQuestion) {
      submitToBackend();
    } else {
      setCurrentIdx((prev) => prev + 1);
    }
  };

  const userTeamName = userSide === "Home" ? snapshot.home_team.name : snapshot.away_team.name;

  return (
    <div className="min-h-screen bg-hover text-fg flex flex-col transition-colors duration-300">
      {/* Header */}
      <header className="bg-linear-to-r from-hover via-panel to-hover to-panel border-b border-line px-4 py-6 transition-colors duration-300">
        <div className="max-w-3xl mx-auto text-center relative">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-hover rounded-full mb-3 transition-colors duration-300">
            <Mic className="w-4 h-4 text-warning" />
            <span className="font-heading font-bold text-caption uppercase tracking-labelst text-fg">
              {t("match.pressConference")}
            </span>
          </div>
          <p className="text-body text-fg-muted">
            {t("match.pressSubtitle", { team: userTeamName })}
          </p>
          <div className="flex items-center justify-center gap-1 mt-3">
            {questions.map((_, i) => (
              <div
                key={i}
                className={`w-8 h-1 rounded-full transition-colors ${
                  i < currentIdx
                    ? "bg-selected-fill"
                    : i === currentIdx
                      ? "bg-selected-fill"
                      : "bg-line-strong"
                }`}
              />
            ))}
          </div>
        </div>
      </header>

      {/* Main content */}
      <div className="flex-1 flex items-center justify-center p-6">
        {currentQ && (
          <div className="max-w-2xl w-full">
            {/* Journalist */}
            <div className="flex items-start gap-4 mb-8">
              <div className="w-12 h-12 rounded-full bg-hover flex items-center justify-center flex-shrink-0 transition-colors duration-300">
                <MessageSquare className="w-5 h-5 text-fg-muted" />
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-heading font-bold text-body text-fg">
                    {currentQ.journalist}
                  </span>
                  <Badge variant="neutral" size="sm">
                    {currentQ.outlet}
                  </Badge>
                </div>
                <p className="text-lead text-fg leading-relaxed italic">"{currentQ.question}"</p>
              </div>
            </div>

            {/* Responses */}
            <div className="flex flex-col gap-3 ml-16">
              {currentQ.responses.map((r) => {
                const isSelected = answers[currentQ.id] === r.id;
                return (
                  <button
                    type="button"
                    key={r.id}
                    onClick={() => handleAnswer(r.id)}
                    disabled={hasAnswered}
                    className={`p-4 rounded-panel text-left transition-all ${
                      isSelected
                        ? "bg-selected-tint ring-2 ring-selected/50"
                        : hasAnswered
                          ? "bg-hover opacity-40"
                          : "bg-panel hover:bg-hover border border-line"
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant={isSelected ? "primary" : "neutral"} size="sm">
                        {" "}
                        {r.tone}{" "}
                      </Badge>{" "}
                    </div>{" "}
                    <p className={`text-body ${isSelected ? "text-fg" : "text-fg-muted"}`}>
                      "{r.text}"
                    </p>
                  </button>
                );
              })}
            </div>

            {/* Next button */}
            {hasAnswered && (
              <div className="flex justify-end mt-6 ml-16">
                <button
                  type="button"
                  onClick={handleNext}
                  className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-selected-fill to-selected-fill rounded-panel font-heading font-bold uppercase tracking-label text-body text-on-brand shadow-lg shadow-card transition-all"
                >
                  {submitting
                    ? t("match.submitting")
                    : isLastQuestion
                      ? t("match.leaveConference")
                      : t("match.nextQuestion")}
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Skip button */}
      <footer className="bg-panel border-t border-line px-6 py-3 transition-colors duration-300">
        <div className="max-w-3xl mx-auto flex justify-end">
          <button
            type="button"
            onClick={onFinish}
            className="text-caption font-heading uppercase tracking-label text-fg-muted hover:text-fg transition-colors"
          >
            {t("match.skipConference")}
          </button>
        </div>
      </footer>
    </div>
  );
}
