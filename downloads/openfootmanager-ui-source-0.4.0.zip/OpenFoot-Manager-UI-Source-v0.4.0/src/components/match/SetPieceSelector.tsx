import { useState } from "react";
import { useTranslation } from "react-i18next";
import type { PlayerData } from "../../store/gameStore";
import { getAttributeValueClassName } from "../../lib/playerAttributeDisplay";
import { Badge } from "../ui";
import { ArrowUpDown, Check } from "lucide-react";
import { usePositionTable } from "../../hooks/usePositionGroups";

function getStatAttributeKey(label: string): string | null {
  switch (label) {
    case "SHO":
      return "shooting";
    case "COM":
      return "composure";
    case "PAS":
      return "passing";
    case "VIS":
      return "vision";
    case "LDR":
      return "leadership";
    case "TMW":
      return "teamwork";
    default:
      return null;
  }
}

export function getSetPieceStats(
  role: string,
  p: PlayerData,
): { score: number; stats: { label: string; value: number }[] } {
  const a = p.attributes;
  switch (role) {
    case "penalty":
      return {
        score: Math.round((a.shooting + a.composure) / 2),
        stats: [
          { label: "SHO", value: a.shooting },
          { label: "COM", value: a.composure },
        ],
      };
    case "freekick":
      return {
        score: Math.round((a.passing + a.vision + a.shooting / 2) / 2.5),
        stats: [
          { label: "PAS", value: a.passing },
          { label: "VIS", value: a.vision },
          { label: "SHO", value: a.shooting },
        ],
      };
    case "corner":
      return {
        score: Math.round((a.passing + a.vision) / 2),
        stats: [
          { label: "PAS", value: a.passing },
          { label: "VIS", value: a.vision },
        ],
      };
    case "captain":
    case "vicecaptain":
      return {
        score: Math.round((a.leadership + a.teamwork) / 2),
        stats: [
          { label: "LDR", value: a.leadership },
          { label: "TMW", value: a.teamwork },
        ],
      };
    default:
      return { score: 0, stats: [] };
  }
}

function roleAllowsGoalkeeper(role: string): boolean {
  return role === "captain" || role === "vicecaptain";
}

export default function SetPieceSelector({
  label,
  icon,
  // Named `assignment`, not `role`: this is the football job (captain, penalty taker), and a
  // prop called `role` on a React component shadows the ARIA attribute of the same name. It was
  // never forwarded to the DOM, but every reader and every linter had to work that out.
  assignment,
  currentId,
  players,
  allSquad,
  onSelect,
}: {
  label: string;
  icon: React.ReactNode;
  assignment: string;
  currentId: string | null;
  players: { id: string; name: string; position: string }[];
  allSquad: PlayerData[];
  onSelect: (id: string) => void;
}) {
  const { t } = useTranslation();
  const positions = usePositionTable();
  const [expanded, setExpanded] = useState(false);
  const currentPlayer = players.find((p) => p.id === currentId);
  const currentSquad = allSquad.find((sp) => sp.id === currentId);
  const currentStats = currentSquad ? getSetPieceStats(assignment, currentSquad) : null;

  const sortedPlayers = [...players]
    .filter((p) => roleAllowsGoalkeeper(assignment) || p.position !== "Goalkeeper")
    .map((p) => {
      const squad = allSquad.find((sp) => sp.id === p.id);
      const spStats = squad ? getSetPieceStats(assignment, squad) : { score: 0, stats: [] };
      return { ...p, squad, spStats };
    })
    .sort((a, b) => b.spStats.score - a.spStats.score || a.name.localeCompare(b.name));

  function getTranslatedStatLabel(label: string): string {
    const attributeKey = getStatAttributeKey(label);

    if (!attributeKey) {
      return label;
    }

    return t(`common.attributes.${attributeKey}`, { defaultValue: label });
  }

  function getTranslatedPositionAbbreviation(position: string): string {
    const normalizedPosition = positions.groupOf(position);

    return t(`common.posAbbr.${normalizedPosition}`, {
      defaultValue: normalizedPosition.substring(0, 3).toUpperCase(),
    });
  }

  return (
    <div className="mb-4 last:mb-0">
      <button
        type="button"
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center gap-3 p-3 rounded-control bg-hover hover:bg-hover/50 transition-colors"
      >
        {icon}
        <div className="flex-1 text-left">
          <p className="text-caption font-heading font-bold uppercase tracking-labelst text-fg-muted">
            {label}
          </p>
          <p className="text-body text-fg font-medium">
            {currentPlayer ? currentPlayer.name : t("match.notAssigned")}
          </p>
        </div>
        {currentStats && (
          <div className="hidden flex-wrap items-center justify-end gap-2 md:flex">
            {currentStats.stats.map((s) => (
              <span
                key={s.label}
                title={getTranslatedStatLabel(s.label)}
                className="inline-flex items-center gap-1 rounded-md border border-line bg-panel px-2 py-1 text-caption font-heading font-bold text-fg"
              >
                <span className="text-fg-muted">{getTranslatedStatLabel(s.label)}</span>
                <span className={getAttributeValueClassName(s.value)}>{s.value}</span>
              </span>
            ))}
          </div>
        )}
        <ArrowUpDown className="w-4 h-4 text-fg-muted" />
      </button>

      {expanded && (
        <div className="mt-1 bg-panel rounded-control border border-line p-2 flex flex-col gap-0.5 max-h-56 overflow-auto">
          {sortedPlayers.map((p) => {
            const isCurrent = p.id === currentId;
            return (
              <button
                type="button"
                key={p.id}
                onClick={() => {
                  onSelect(p.id);
                  setExpanded(false);
                }}
                className={`flex items-center gap-2 px-2 py-1.5 rounded text-left transition-colors ${
                  isCurrent ? "bg-selected-tint text-selected" : "hover:bg-hover text-fg"
                }`}
              >
                <span className="w-3 shrink-0">
                  {isCurrent && <Check className="w-3 h-3 text-selected" />}
                </span>
                <span className="min-w-0 flex-1 truncate text-body font-medium">{p.name}</span>
                <Badge variant="neutral" size="sm">
                  {getTranslatedPositionAbbreviation(p.position)}
                </Badge>
                <span
                  className={`w-7 shrink-0 text-right text-caption font-heading font-bold tabular-nums ${getAttributeValueClassName(p.spStats.score)}`}
                >
                  {p.spStats.score}
                </span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
