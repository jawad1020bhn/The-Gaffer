import { useTranslation } from "react-i18next";
import { usePositionTable } from "../../hooks/usePositionGroups";
import type { MatchSnapshot, MatchEvent, EnginePlayerData } from "./types";
import { getEventDisplay, getEventTypeLabel, getPlayerName } from "./helpers";
import { getCommentary } from "./commentary";
import { Badge } from "../ui";
import { translatePositionAbbreviation } from "../squad/SquadTab.helpers";

export function EventFeed({
  events,
  snapshot,
  feedRef,
  playerJerseyMap,
}: {
  events: MatchEvent[];
  snapshot: MatchSnapshot;
  feedRef: React.RefObject<HTMLDivElement | null>;
  playerJerseyMap?: Map<string, number>;
}) {
  function displayName(playerId: string | null): string {
    const name = getPlayerName(snapshot, playerId);
    if (!name || !playerId || !playerJerseyMap) return name;
    const jersey = playerJerseyMap.get(playerId);
    return jersey != null ? `${name} (#${jersey})` : name;
  }
  const { t } = useTranslation();
  return (
    <div ref={feedRef} className="flex flex-col gap-1">
      {events.length === 0 ? (
        <div className="flex items-center justify-center h-40 text-fg-muted">
          <p className="font-heading text-body uppercase tracking-label">
            {t("match.waitingKickoff")}
          </p>
        </div>
      ) : (
        events.map((evt, i) => {
          const display = getEventDisplay(evt);
          const isHome = evt.side === "Home";
          const commentary = getCommentary(evt, snapshot, t);
          return (
            <div
              key={i}
              className={`flex items-start gap-3 px-3 py-2 rounded-control transition-colors ${display.important ? "bg-panel/80 border border-line shadow-sm" : "opacity-60"}`}
            >
              <span className="text-fg-muted tabular-nums font-heading text-body w-8 text-right flex-shrink-0 pt-0.5">
                {evt.minute}'
              </span>
              <span className="text-lead flex-shrink-0">{display.icon}</span>
              <div className="flex-1 min-w-0">
                {commentary ? (
                  <>
                    <div className="flex items-center gap-2">
                      <span
                        className={`font-heading font-bold text-caption uppercase tracking-label ${isHome ? "text-selected" : "text-info"}`}
                      >
                        {commentary.headline}
                      </span>
                      <span className="text-caption text-fg-muted">
                        {isHome ? snapshot.home_team.name : snapshot.away_team.name}
                      </span>
                    </div>
                    <p className="text-body text-fg">{commentary.line}</p>
                    {evt.event_type === "Goal" && evt.secondary_player_id && (
                      <p className="text-caption text-fg-muted">
                        {t("match.assist", {
                          name: displayName(evt.secondary_player_id),
                        })}
                      </p>
                    )}
                  </>
                ) : (
                  <>
                    <div className="flex items-center gap-2">
                      <span
                        className={`font-heading font-bold text-caption uppercase tracking-label ${isHome ? "text-selected" : "text-info"}`}
                      >
                        {isHome ? snapshot.home_team.name : snapshot.away_team.name}
                      </span>
                      <span className="text-caption text-fg-muted">
                        {getEventTypeLabel(evt.event_type, t)}
                      </span>
                    </div>
                    {evt.player_id && (
                      <p className="text-body text-fg font-medium">
                        {displayName(evt.player_id)}
                        {evt.secondary_player_id && (
                          <span className="text-fg-muted font-normal">
                            {evt.event_type === "Goal"
                              ? ` (${t("match.assist", { name: displayName(evt.secondary_player_id) })})`
                              : evt.event_type === "Substitution"
                                ? ` ${t("match.subFor", { name: displayName(evt.secondary_player_id) })}`
                                : ""}
                          </span>
                        )}
                      </p>
                    )}
                  </>
                )}
              </div>
            </div>
          );
        })
      )}
    </div>
  );
}

export function MatchStats({ snapshot }: { snapshot: MatchSnapshot }) {
  const { t } = useTranslation();
  const homeEvents = snapshot.events.filter((e) => e.side === "Home");
  const awayEvents = snapshot.events.filter((e) => e.side === "Away");
  const ct = (events: MatchEvent[], type: string) =>
    events.filter((e) => e.event_type === type).length;

  const stats = [
    {
      label: t("match.possession"),
      home: `${snapshot.home_possession_pct.toFixed(0)}%`,
      away: `${snapshot.away_possession_pct.toFixed(0)}%`,
      homePct: snapshot.home_possession_pct,
    },
    {
      label: t("match.shots"),
      home:
        ct(homeEvents, "Goal") +
        ct(homeEvents, "PenaltyGoal") +
        ct(homeEvents, "ShotSaved") +
        ct(homeEvents, "ShotOffTarget") +
        ct(homeEvents, "ShotBlocked"),
      away:
        ct(awayEvents, "Goal") +
        ct(awayEvents, "PenaltyGoal") +
        ct(awayEvents, "ShotSaved") +
        ct(awayEvents, "ShotOffTarget") +
        ct(awayEvents, "ShotBlocked"),
    },
    {
      label: t("match.shotsOnTarget"),
      home: ct(homeEvents, "Goal") + ct(homeEvents, "PenaltyGoal") + ct(homeEvents, "ShotSaved"),
      away: ct(awayEvents, "Goal") + ct(awayEvents, "PenaltyGoal") + ct(awayEvents, "ShotSaved"),
    },
    {
      label: t("match.fouls"),
      home: ct(homeEvents, "Foul"),
      away: ct(awayEvents, "Foul"),
    },
    {
      label: t("match.corners"),
      home: ct(homeEvents, "Corner"),
      away: ct(awayEvents, "Corner"),
    },
    {
      label: t("match.yellowCards"),
      home: Object.keys(snapshot.home_yellows).length,
      away: Object.keys(snapshot.away_yellows).length,
    },
  ];

  return (
    <div className="max-w-lg mx-auto flex flex-col gap-3">
      {stats.map((stat, i) => {
        const hv = typeof stat.home === "number" ? stat.home : 0;
        const av = typeof stat.away === "number" ? stat.away : 0;
        const total = hv + av || 1;
        const pct = stat.homePct ?? (hv / total) * 100;
        return (
          <div key={i}>
            <div className="flex justify-between text-caption mb-1">
              <span className="font-heading font-bold text-selected tabular-nums">{stat.home}</span>
              <span className="text-fg-muted font-heading uppercase tracking-label text-caption">
                {stat.label}
              </span>
              <span className="font-heading font-bold text-info tabular-nums">{stat.away}</span>
            </div>
            <div className="flex h-1.5 bg-line-strong rounded-full overflow-hidden transition-colors duration-300">
              <div
                className="h-full bg-selected-fill transition-all duration-500"
                style={{ width: `${pct}%` }}
              />
              <div
                className="h-full bg-info-solid transition-all duration-500"
                style={{ width: `${100 - pct}%` }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}

export function Lineups({ snapshot }: { snapshot: MatchSnapshot }) {
  const { t } = useTranslation();
  const positionTable = usePositionTable();
  const renderTeam = (
    team: MatchSnapshot["home_team"],
    bench: EnginePlayerData[],
    side: "Home" | "Away",
    yellows: Record<string, number>,
    sentOff: string[],
  ) => {
    // The starters are grouped by the backend's lines; until its table arrives there are none, and
    // they show in the XI's own order instead, so the lineup is never empty.
    const groups = positionTable.loaded
      ? positionTable.lines().map((pos) => ({
          key: pos,
          label: t(`common.positionGroups.${pos}`, { defaultValue: pos }),
          players: team.players.filter((p) => p.position === pos),
        }))
      : [{ key: "all", label: null, players: team.players }];
    const subbedOnIds = new Set(
      snapshot.substitutions.filter((s) => s.side === side).map((s) => s.player_on_id),
    );
    const subbedOffIds = new Set(
      snapshot.substitutions.filter((s) => s.side === side).map((s) => s.player_off_id),
    );
    return (
      <div className="flex-1">
        <h4
          className={`font-heading font-bold text-body uppercase tracking-label mb-3 ${side === "Home" ? "text-selected" : "text-info"}`}
        >
          {team.name}{" "}
          <span className="text-fg-muted font-normal text-caption">({team.formation})</span>
        </h4>
        {groups.map(({ key, label, players }) => {
          if (players.length === 0) return null;
          return (
            <div key={key} className="mb-3">
              {label ? (
                <p className="text-caption font-heading uppercase tracking-labelst text-fg-muted mb-1">
                  {label}
                </p>
              ) : null}
              {players.map((p) => {
                const isOff = sentOff.includes(p.id);
                const yc = yellows[p.id] || 0;
                const isSubOn = subbedOnIds.has(p.id);
                const condColor =
                  p.condition >= 70
                    ? "bg-selected-fill"
                    : p.condition >= 40
                      ? "bg-warning-solid"
                      : "bg-danger-solid";
                return (
                  <div
                    key={p.id}
                    className={`flex items-center gap-2 py-1 px-2 rounded text-caption ${isOff ? "opacity-40" : ""}`}
                  >
                    {isSubOn && <span className="text-positive text-caption">▲</span>}
                    <span
                      className={`font-medium flex-1 truncate ${isOff ? "line-through text-fg-muted" : "text-fg"}`}
                    >
                      {p.name}
                    </span>
                    {yc > 0 && (
                      <span className="w-3 h-4 rounded-sm bg-warning-solid text-fg text-caption flex items-center justify-center font-bold">
                        {yc > 1 ? yc : ""}
                      </span>
                    )}
                    {isOff && <span className="w-3 h-4 rounded-sm bg-danger-solid" />}
                    <div className="w-14 flex items-center gap-1">
                      <div className="flex-1 h-1.5 bg-line-strong rounded-full overflow-hidden transition-colors duration-300">
                        <div
                          className={`h-full ${condColor} rounded-full transition-all`}
                          style={{ width: `${p.condition}%` }}
                        />
                      </div>
                      <span className="text-fg-muted tabular-nums text-caption w-6 text-right">
                        {Math.round(p.condition)}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          );
        })}

        {/* Bench */}
        {bench.length > 0 && (
          <div className="mt-3 pt-3 border-t border-line">
            <p className="text-caption font-heading uppercase tracking-labelst text-fg-muted mb-1">
              {t("match.bench")}
            </p>
            {bench.map((p) => {
              const wasSubbedOff = subbedOffIds.has(p.id);
              return (
                <div
                  key={p.id}
                  className={`flex items-center gap-2 py-1 px-2 rounded text-caption ${wasSubbedOff ? "opacity-50" : ""}`}
                >
                  {wasSubbedOff && <span className="text-danger text-caption">▼</span>}
                  <span className="text-fg-muted font-medium flex-1 truncate">{p.name}</span>
                  <Badge variant="neutral" size="sm">
                    {translatePositionAbbreviation(t, p.position)}
                  </Badge>
                  <span className="text-fg-muted tabular-nums text-caption w-6 text-right">
                    {Math.round(p.condition)}
                  </span>
                </div>
              );
            })}
          </div>
        )}

        {/* Sub History */}
        {snapshot.substitutions.filter((s) => s.side === side).length > 0 && (
          <div className="mt-3 pt-3 border-t border-line">
            <p className="text-caption font-heading uppercase tracking-labelst text-fg-muted mb-1">
              {t("match.substitutions")}
            </p>
            {snapshot.substitutions
              .filter((s) => s.side === side)
              .map((sub, i) => (
                <div key={i} className="flex items-center gap-1.5 py-0.5 text-caption">
                  <span className="text-fg-muted tabular-nums w-5 text-right font-heading">
                    {sub.minute}'
                  </span>
                  <span className="text-positive">▲</span>
                  <span className="text-fg truncate">
                    {getPlayerName(snapshot, sub.player_on_id)}
                  </span>
                  <span className="text-danger">▼</span>
                  <span className="text-fg-muted truncate">
                    {getPlayerName(snapshot, sub.player_off_id)}
                  </span>
                </div>
              ))}
          </div>
        )}
      </div>
    );
  };
  return (
    <div className="flex gap-6">
      {renderTeam(
        snapshot.home_team,
        snapshot.home_bench,
        "Home",
        snapshot.home_yellows,
        snapshot.sent_off,
      )}
      <div className="w-px bg-hover transition-colors duration-300" />
      {renderTeam(
        snapshot.away_team,
        snapshot.away_bench,
        "Away",
        snapshot.away_yellows,
        snapshot.sent_off,
      )}
    </div>
  );
}
