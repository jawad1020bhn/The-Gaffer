import { useRatingTiers } from "../../hooks/useRatingTiers";
import { ratingTierClass } from "../../lib/ratingTier";
import type { ReactNode } from "react";
import { useTranslation } from "react-i18next";
import type { MatchSnapshot, EnginePlayerData } from "./types";
import { Badge } from "../ui";
import { ArrowUpDown, AlertTriangle, Wand2 } from "lucide-react";
import ContextMenu from "../ContextMenu";
import { translatePositionAbbreviation } from "../squad/SquadTab.helpers";
import { condColor } from "../../lib/playerConditionDisplay";
import { sortByPositionGroup } from "./SubPanel.helpers";
import { usePositionTable } from "../../hooks/usePositionGroups";
import { parseColor } from "../../lib/colorContrast";

export const POSITION_KEY_STATS: Record<string, { label: string; key: string }[]> = {
  Goalkeeper: [
    { label: "HAN", key: "handling" },
    { label: "REF", key: "reflexes" },
    { label: "AER", key: "aerial" },
  ],
  Defender: [
    { label: "DEF", key: "defending" },
    { label: "TAC", key: "tackling" },
    { label: "STR", key: "strength" },
  ],
  Midfielder: [
    { label: "PAS", key: "passing" },
    { label: "VIS", key: "vision" },
    { label: "STA", key: "stamina" },
  ],
  Forward: [
    { label: "SHO", key: "shooting" },
    { label: "PAC", key: "pace" },
    { label: "DRI", key: "dribbling" },
  ],
};

function normalizeHexColor(color: string): string | null {
  const normalized = color.trim();
  const hex = normalized.startsWith("#") ? normalized.slice(1) : normalized;

  if (!/^[0-9a-fA-F]{3}$|^[0-9a-fA-F]{6}$/.test(hex)) {
    return null;
  }

  const expanded =
    hex.length === 3
      ? hex
          .split("")
          .map((char) => char + char)
          .join("")
      : hex;

  return `#${expanded.toLowerCase()}`;
}

function isLightColor(color: string): boolean {
  const rgb = parseColor(color);

  if (!rgb) {
    return false;
  }

  const brightness = (rgb.r * 299 + rgb.g * 587 + rgb.b * 114) / 1000;
  return brightness >= 205;
}

export function starterBadgeStyle(userColor: string): Record<string, string | number> {
  const normalizedHex = normalizeHexColor(userColor);

  if (!normalizedHex || isLightColor(normalizedHex)) {
    return {
      backgroundColor: "#f8fafc",
      color: "#334155",
      borderColor: "#cbd5e1",
      borderWidth: 1,
      borderStyle: "solid",
    };
  }

  return {
    backgroundColor: `${normalizedHex}30`,
    color: normalizedHex,
    borderColor: `${normalizedHex}55`,
    borderWidth: 1,
    borderStyle: "solid",
  };
}

export function getStatVal(p: EnginePlayerData, key: string): number {
  return (p as unknown as Record<string, number>)[key] ?? 0;
}

export function parseFormationNeeds(formation: string): Record<string, number> {
  const parts = formation
    .split("-")
    .map(Number)
    .filter((n) => !Number.isNaN(n));
  if (parts.length === 3)
    return {
      Goalkeeper: 1,
      Defender: parts[0],
      Midfielder: parts[1],
      Forward: parts[2],
    };
  if (parts.length === 4)
    return {
      Goalkeeper: 1,
      Defender: parts[0],
      Midfielder: parts[1] + parts[2],
      Forward: parts[3],
    };
  return { Goalkeeper: 1, Defender: 4, Midfielder: 4, Forward: 2 };
}

interface PreMatchLineupProps {
  userTeam: MatchSnapshot["home_team"];
  userBench: EnginePlayerData[];
  oppTeam?: MatchSnapshot["home_team"];
  userColor: string;
  homeTeamColor?: string;
  awayTeamColor?: string;
  userSide?: "Home" | "Away";
  formationNeeds: Record<string, number>;
  selectedStarterId: string | null;
  isAutoSelecting: boolean;
  onSelectStarter: (id: string | null) => void;
  onSwap: (benchPlayerId: string) => void;
  onAutoSelect: () => void;
  /**
   * Jersey number per player id, looked up from the game store — the match
   * snapshot's lightweight player doesn't carry it. Rows show a number chip
   * only when this is provided.
   */
  jerseyNumberById?: Map<string, number | null | undefined>;
  /** Formation/play-style selects, rendered inside the formation-fit card. */
  formationControls?: ReactNode;
  /**
   * When false, the textual Starting XI list is hidden — used by the pre-match
   * "command" layout where the pitch is the primary XI visualisation. The
   * formation-fit bar and bench (for swapping) still render. Defaults to true.
   */
  showStartingList?: boolean;
}

export default function PreMatchLineup({
  userTeam,
  userBench,
  userColor,
  formationNeeds,
  selectedStarterId,
  isAutoSelecting,
  onSelectStarter,
  onSwap,
  onAutoSelect,
  jerseyNumberById,
  formationControls,
  showStartingList = true,
}: PreMatchLineupProps) {
  const tierOf = useRatingTiers();
  const { t } = useTranslation();
  const positionTable = usePositionTable();
  const positions = positionTable.lines();

  const jerseyChip = (playerId: string) =>
    jerseyNumberById ? (
      <span className="w-6 shrink-0 rounded-md bg-hover py-0.5 text-center text-caption font-heading font-bold tabular-nums text-fg-muted">
        {jerseyNumberById.get(playerId) ?? "–"}
      </span>
    ) : null;

  return (
    <div className="flex flex-col gap-4">
      {/* Formation setup: formation/play-style controls, slot-fit counts, and
          auto-select — stacked so nothing clips in the narrow sidebar. */}
      <div className="bg-panel rounded-panel border border-line shadow-sm p-3 flex flex-col gap-2.5 transition-colors duration-300">
        <span className="text-caption font-heading uppercase tracking-labelst text-fg">
          {t("match.formationFit")}
        </span>
        {formationControls}
        <div className="grid grid-cols-4 gap-1.5">
          {positions.map((pos) => {
            const needed = formationNeeds[pos] || 0;
            const actual = userTeam.players.filter((p) => p.position === pos).length;
            const ok = actual === needed;
            return (
              <div
                key={pos}
                className="flex flex-col items-center gap-0.5 rounded-control bg-sunken py-1.5"
              >
                <span className="text-caption font-heading uppercase tracking-labelst text-fg-muted">
                  {translatePositionAbbreviation(t, pos)}
                </span>
                <span
                  className={`flex items-center gap-1 text-body font-heading font-bold tabular-nums ${ok ? "text-selected" : "text-warning"}`}
                >
                  {actual}/{needed}
                  {!ok && <AlertTriangle className="w-3 h-3 text-warning" />}
                </span>
              </div>
            );
          })}
        </div>
        <button
          type="button"
          onClick={onAutoSelect}
          // Until the table arrives there are no lines to pick from, and the pick would ignore position.
          disabled={isAutoSelecting || !positionTable.loaded}
          className={`flex w-full items-center justify-center gap-2 px-4 py-2 rounded-control text-caption font-heading font-bold uppercase tracking-label transition-all ${
            isAutoSelecting || !positionTable.loaded
              ? "bg-hover text-fg-muted cursor-wait"
              : "bg-warning-solid text-warning hover:bg-warning-solid bg-warning-tint hover:bg-warning-tint"
          }`}
        >
          <Wand2 className="w-3.5 h-3.5" />
          {isAutoSelecting ? t("match.selecting") : t("match.autoSelectXI")}
        </button>
      </div>

      {/* Starting XI */}
      {showStartingList && (
        <div className="bg-panel rounded-panel border border-line shadow-sm p-4 transition-colors duration-300">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-caption font-heading font-bold uppercase tracking-labelst text-fg-muted">
              {t("match.startingXI")}
            </h3>
            <div className="flex items-center gap-2">
              {selectedStarterId && (
                <button
                  type="button"
                  onClick={() => onSelectStarter(null)}
                  className="text-caption text-fg-muted hover:text-fg font-heading uppercase tracking-label"
                >
                  {t("match.cancel")}
                </button>
              )}
              <Badge variant="primary" size="sm">
                {t("match.nPlayers", { count: userTeam.players.length })}
              </Badge>
            </div>
          </div>
          {selectedStarterId && (
            <p className="text-caption text-warning font-heading uppercase tracking-label mb-2">
              {t("match.swapPrompt")}
            </p>
          )}
          {positions.map((pos) => {
            const players = userTeam.players.filter((p) => p.position === pos);
            if (players.length === 0) return null;
            const needed = formationNeeds[pos] || 0;
            const balanced = players.length === needed;
            const keyStats = POSITION_KEY_STATS[pos] || [];
            return (
              <div key={pos} className="mb-3">
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-1.5">
                    <p className="text-caption font-heading uppercase tracking-labelst text-fg-muted">
                      {t(`common.positionGroups.${pos}`)}
                    </p>
                    {!balanced && (
                      <span className="flex items-center gap-0.5">
                        <AlertTriangle className="w-2.5 h-2.5 text-warning" />
                        <span className="text-caption font-heading text-warning">
                          {players.length}/{needed}
                        </span>
                      </span>
                    )}
                  </div>
                  {/* Stat column headers */}
                  <div className="flex items-center gap-0">
                    <span className="text-caption font-heading uppercase tracking-labelst text-fg-muted w-7 text-center">
                      OVR
                    </span>
                    {keyStats.map((s) => (
                      <span
                        key={s.label}
                        className="text-caption font-heading uppercase tracking-labelst text-fg-muted w-7 text-center"
                      >
                        {s.label}
                      </span>
                    ))}
                    <span className="text-caption font-heading uppercase tracking-labelst text-fg-muted w-8 text-right">
                      COND
                    </span>
                  </div>
                </div>
                {players.map((p) => {
                  const posOvr = p.ovr;
                  const isSelected = selectedStarterId === p.id;
                  const starterButton = (
                    <button
                      type="button"
                      key={p.id}
                      data-testid={`pre-match-starter-${p.id}`}
                      onClick={() => onSelectStarter(isSelected ? null : p.id)}
                      className={`flex items-center gap-2 py-1.5 px-2 rounded w-full text-left transition-all ${
                        isSelected
                          ? "bg-selected-tint ring-1 ring-selected/50"
                          : "hover:bg-hover/50"
                      }`}
                    >
                      <div
                        className="w-7 h-7 rounded-full flex items-center justify-center text-caption font-heading font-bold flex-shrink-0"
                        style={starterBadgeStyle(userColor)}
                      >
                        {posOvr}
                      </div>
                      {jerseyChip(p.id)}
                      <span className="text-body text-fg font-medium flex-1 truncate">
                        {p.name}
                      </span>
                      {isSelected && (
                        <ArrowUpDown className="w-3.5 h-3.5 text-selected flex-shrink-0" />
                      )}
                      <div className="flex items-center gap-0">
                        <span
                          className={`text-caption font-heading font-bold tabular-nums w-7 text-center ${ratingTierClass(tierOf(posOvr), "text")}`}
                        >
                          {posOvr}
                        </span>
                        {keyStats.map((s) => (
                          <span
                            key={s.label}
                            className={`text-caption font-heading tabular-nums w-7 text-center ${ratingTierClass(tierOf(getStatVal(p, s.key)), "text")}`}
                          >
                            {getStatVal(p, s.key)}
                          </span>
                        ))}
                      </div>
                      <span
                        className={`text-caption tabular-nums w-8 text-right ${condColor(p.condition)}`}
                      >
                        {Math.round(p.condition)}%
                      </span>
                    </button>
                  );

                  return (
                    <ContextMenu
                      items={[
                        {
                          label: isSelected ? t("match.cancel") : t("match.selectForSwap"),
                          onClick: () => onSelectStarter(isSelected ? null : p.id),
                        },
                      ]}
                      key={p.id}
                    >
                      {starterButton}
                    </ContextMenu>
                  );
                })}
              </div>
            );
          })}
        </div>
      )}

      {/* Bench */}
      <div className="bg-panel rounded-panel border border-line shadow-sm p-4 transition-colors duration-300">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-caption font-heading font-bold uppercase tracking-labelst text-fg-muted">
            {t("match.substitutes")}
          </h3>
          <Badge variant="neutral" size="sm">
            {t("match.nAvailable", { count: userBench.length })}
          </Badge>
        </div>
        {userBench.length === 0 ? (
          <p className="text-caption text-fg-muted">{t("match.noBenchAvailable2")}</p>
        ) : (
          <div className="flex flex-col gap-1">
            {/* Bench column header */}
            <div className="flex items-center gap-2 px-2 pb-1">
              <span className="flex-1" />
              {/* Key stats hide at xl, where this panel is a narrow sidebar —
                    with them the player name gets truncated to nothing. */}
              <span className="text-caption font-heading uppercase tracking-labelst text-fg-muted w-[84px] text-center xl:hidden">
                {t("match.keyStats")}
              </span>
              <span className="text-caption font-heading uppercase tracking-labelst text-fg-muted w-8 text-right">
                COND
              </span>
            </div>
            {sortByPositionGroup(userBench, positionTable).map((bp) => {
              const posOvr = bp.ovr;
              const keyStats = POSITION_KEY_STATS[bp.position] || [];
              const canSwap = Boolean(selectedStarterId);
              const benchButton = (
                <button
                  type="button"
                  key={bp.id}
                  data-testid={`pre-match-bench-${bp.id}`}
                  disabled={!canSwap}
                  aria-disabled={!canSwap}
                  onClick={() => {
                    if (canSwap) {
                      onSwap(bp.id);
                    }
                  }}
                  className={`flex items-center gap-2 py-1.5 px-2 rounded w-full text-left transition-all ${
                    canSwap
                      ? "hover:bg-selected-tint hover:ring-1 hover:ring-selected/50 cursor-pointer"
                      : "opacity-60 cursor-not-allowed"
                  }`}
                >
                  <Badge variant="neutral" size="sm">
                    {translatePositionAbbreviation(t, bp.position)}
                  </Badge>
                  {jerseyChip(bp.id)}
                  <span className="min-w-0 text-body text-fg font-medium flex-1 truncate">
                    {bp.name}
                  </span>
                  <div className="flex items-center gap-0 xl:hidden">
                    {keyStats.map((s) => (
                      <span
                        key={s.label}
                        className={`text-caption font-heading tabular-nums w-7 text-center ${ratingTierClass(tierOf(getStatVal(bp, s.key)), "text")}`}
                      >
                        {getStatVal(bp, s.key)}
                      </span>
                    ))}
                  </div>
                  <span
                    className={`shrink-0 rounded-full px-1.5 py-0.5 text-caption font-heading font-bold ${ratingTierClass(tierOf(posOvr), "badge")}`}
                  >
                    {posOvr}
                  </span>
                  <span
                    className={`shrink-0 text-caption tabular-nums w-8 text-right ${condColor(bp.condition)}`}
                  >
                    {Math.round(bp.condition)}%
                  </span>
                </button>
              );

              if (!selectedStarterId) {
                return benchButton;
              }

              return (
                <ContextMenu
                  items={[
                    {
                      label: t("match.swapWithSelectedStarter"),
                      onClick: () => onSwap(bp.id),
                    },
                  ]}
                  key={bp.id}
                >
                  {benchButton}
                </ContextMenu>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
