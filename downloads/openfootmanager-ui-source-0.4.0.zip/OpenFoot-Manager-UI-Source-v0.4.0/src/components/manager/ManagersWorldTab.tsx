import { Briefcase, Building2, TrendingUp, UserRound, UsersRound } from "lucide-react";
import { useTranslation } from "react-i18next";
import { type ReactNode, useMemo } from "react";

import type { GameStateData, ManagerData, TeamData } from "../../store/gameStore";
import { countryName } from "../../lib/countries";
import { useListView } from "../../hooks/useListView";
import { Badge, Card, CardBody, CardHeader, CountryFlag, ViewSwitch } from "../ui";
import { managersDirectory } from "./managerRows";
import ManagersTables from "./ManagersTables";

interface ManagersWorldTabProps {
  gameState: GameStateData;
  onSelectTeam?: (id: string) => void;
}

interface VacancyEntry {
  kind: "vacancy";
  team: TeamData;
}

interface ManagerEntry {
  kind: "manager";
  manager: ManagerData;
  team: TeamData | null;
}

type DirectoryEntry = VacancyEntry | ManagerEntry;

function winRateLabel(manager: ManagerData): string {
  const matches = manager.career_stats.matches_managed;
  if (matches === 0) {
    return "0%";
  }

  return `${Math.round((manager.career_stats.wins / matches) * 100)}%`;
}

function managerEntries(gameState: GameStateData): ManagerEntry[] {
  const managers = gameState.managers ?? [gameState.manager];

  return managers.map((manager) => ({
    kind: "manager",
    manager,
    team: gameState.teams.find((team) => team.id === manager.team_id) ?? null,
  }));
}

function vacancyEntries(gameState: GameStateData): VacancyEntry[] {
  return gameState.teams
    .filter((team) => team.manager_id == null)
    .map((team) => ({ kind: "vacancy", team }));
}

function latestRecordedMatches(team: TeamData): string {
  const latestSeason = team.history.reduce<TeamData["history"][number] | null>((latest, record) => {
    if (!latest || record.season > latest.season) {
      return record;
    }

    return latest;
  }, null);

  return latestSeason ? latestSeason.played.toString() : "-";
}

function sortDirectory(entries: DirectoryEntry[]): DirectoryEntry[] {
  return [...entries].sort((left, right) => {
    if (left.kind !== right.kind) {
      return left.kind === "vacancy" ? 1 : -1;
    }

    if (left.kind === "vacancy" && right.kind === "vacancy") {
      return left.team.name.localeCompare(right.team.name);
    }

    const leftManager = (left as ManagerEntry).manager;
    const rightManager = (right as ManagerEntry).manager;

    return (
      rightManager.reputation - leftManager.reputation ||
      leftManager.last_name.localeCompare(rightManager.last_name) ||
      leftManager.first_name.localeCompare(rightManager.first_name)
    );
  });
}

export default function ManagersWorldTab({ gameState, onSelectTeam }: ManagersWorldTabProps) {
  const { t, i18n } = useTranslation();
  const [view, setView] = useListView();
  // Built once per game state, so the table's sort isn't redone on every render.
  const directory = useMemo(() => managersDirectory(gameState), [gameState]);
  const entries = sortDirectory([...managerEntries(gameState), ...vacancyEntries(gameState)]);

  return (
    <div className="space-y-5">
      <Card accent="primary">
        <CardBody className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-caption font-heading font-bold uppercase tracking-[0.25em] text-selected">
              {t("managersWorld.title")}
            </p>
            <h2 className="text-title font-heading font-bold uppercase tracking-label text-fg">
              {t("managersWorld.subtitle")}
            </h2>
          </div>
          <div className="flex flex-wrap gap-2 text-caption">
            <Badge variant="primary" size="md">
              {t("managersWorld.employed")}
            </Badge>
            <Badge variant="neutral" size="md">
              {t("managersWorld.unemployed")}
            </Badge>
            <Badge variant="accent" size="md">
              {t("managersWorld.vacancy")}
            </Badge>
            <ViewSwitch value={view} onChange={setView} />
          </div>
        </CardBody>
      </Card>

      {entries.length > 0 && view === "table" ? (
        <ManagersTables directory={directory} onSelectTeam={onSelectTeam} />
      ) : entries.length === 0 ? (
        <Card>
          <CardBody className="py-12 text-center text-body text-fg-muted">
            {t("managersWorld.noManagers")}
          </CardBody>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
          {entries.map((entry) => {
            if (entry.kind === "vacancy") {
              return (
                <Card key={`vacancy-${entry.team.id}`} accent="accent">
                  <CardHeader
                    action={<Badge variant="accent">{t("managersWorld.vacancyBadge")}</Badge>}
                  >
                    {t("managersWorld.vacancy")}
                  </CardHeader>
                  <CardBody className="space-y-4">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <p className="text-caption font-heading font-bold uppercase tracking-[0.22em] text-fg-subtle">
                          {t("managersWorld.currentClub")}
                        </p>
                        <button
                          type="button"
                          onClick={() => onSelectTeam?.(entry.team.id)}
                          className="mt-1 text-left text-title font-heading font-bold uppercase tracking-label text-warning transition-colors hover:text-warning"
                        >
                          {t("managersWorld.openRole", { team: entry.team.name })}
                        </button>
                      </div>
                      <div className="rounded-panel bg-warning-solid p-3 text-warning bg-warning-tint">
                        <Briefcase className="h-6 w-6" />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-body">
                      <StatTile
                        icon={<Building2 className="h-4 w-4" />}
                        label={t("managersWorld.reputation")}
                        value={entry.team.reputation.toString()}
                      />
                      <StatTile
                        icon={<UsersRound className="h-4 w-4" />}
                        label={t("managersWorld.matches")}
                        value={latestRecordedMatches(entry.team)}
                      />
                    </div>
                  </CardBody>
                </Card>
              );
            }

            const { manager, team } = entry;
            const isEmployed = team != null;

            return (
              <Card key={manager.id} accent={isEmployed ? "primary" : "none"}>
                <CardHeader
                  action={
                    <Badge variant={isEmployed ? "primary" : "neutral"}>
                      {t(isEmployed ? "managersWorld.employed" : "managersWorld.unemployed")}
                    </Badge>
                  }
                >
                  {manager.display_name}
                </CardHeader>
                <CardBody className="space-y-4">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2 text-body text-fg-muted">
                        <CountryFlag
                          code={manager.nationality}
                          locale={i18n.language}
                          className="text-body leading-none"
                        />
                        <span>{countryName(manager.nationality, i18n.language)}</span>
                      </div>
                      {team ? (
                        <button
                          type="button"
                          onClick={() => onSelectTeam?.(team.id)}
                          className="mt-2 text-left text-title font-heading font-bold uppercase tracking-label text-selected transition-colors hover:text-selected"
                        >
                          {team.name}
                        </button>
                      ) : (
                        <p className="mt-2 text-title font-heading font-bold uppercase tracking-label text-fg">
                          {t("managersWorld.unemployed")}
                        </p>
                      )}
                    </div>
                    <div className="rounded-panel p-3 text-selected bg-selected-tint/40">
                      <UserRound className="h-6 w-6" />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3 text-body">
                    <StatTile
                      icon={<TrendingUp className="h-4 w-4" />}
                      label={t("managersWorld.reputation")}
                      value={manager.reputation.toString()}
                    />
                    <StatTile
                      icon={<UsersRound className="h-4 w-4" />}
                      label={t("managersWorld.matches")}
                      value={manager.career_stats.matches_managed.toString()}
                    />
                    <StatTile
                      icon={<Briefcase className="h-4 w-4" />}
                      label={t("managersWorld.winRate")}
                      value={winRateLabel(manager)}
                    />
                  </div>
                </CardBody>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

interface StatTileProps {
  icon: ReactNode;
  label: string;
  value: string;
}

function StatTile({ icon, label, value }: StatTileProps) {
  return (
    <div className="rounded-control bg-sunken p-3">
      <div className="mb-2 flex items-center gap-2 text-fg-subtle">
        {icon}
        <span className="text-caption font-heading font-bold uppercase tracking-[0.18em]">
          {label}
        </span>
      </div>
      <p className="text-lead font-heading font-bold text-fg">{value}</p>
    </div>
  );
}
