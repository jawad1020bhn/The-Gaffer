import { useTranslation } from "react-i18next";
import { useAssetDataUrl } from "../../../hooks/useAssetDataUrl";
import { EntityListShell, EntityRow } from "./shared";
import type { CompetitionDef } from "./types";
import { entityRowKey } from "./helpers";

interface CompetitionsTabProps {
  competitions: CompetitionDef[];
  projectDir?: string;
  onAdd: () => void;
  onEdit: (index: number) => void;
  onDelete: (index: number) => void;
  onDuplicate?: (index: number) => void;
  selectedIndex?: number | null;
  onSelect?: (index: number) => void;
}

function CompetitionBadge({ comp, projectDir }: { comp: CompetitionDef; projectDir?: string }) {
  const logoUrl = useAssetDataUrl(comp.logo, projectDir);

  if (logoUrl) {
    return (
      <img
        src={logoUrl}
        alt=""
        className="w-8 h-8 rounded-control object-contain border border-line bg-panel flex-shrink-0"
      />
    );
  }
  return (
    <div className="w-8 h-8 rounded-control flex-shrink-0 border border-line bg-hover flex items-center justify-center">
      <span className="text-caption font-heading font-bold text-fg-muted text-center leading-tight px-0.5">
        {comp.type.slice(0, 3).toUpperCase()}
      </span>
    </div>
  );
}

export function CompetitionsTab({
  competitions,
  projectDir,
  onAdd,
  onEdit,
  onDelete,
  onDuplicate,
  selectedIndex,
  onSelect,
}: CompetitionsTabProps) {
  const { t } = useTranslation();
  return (
    <EntityListShell
      addLabel={t("worldEditor.addCompetition")}
      onAdd={onAdd}
      emptyLabel={t("worldEditor.noCompetitions")}
      isEmpty={competitions.length === 0}
    >
      {competitions.map((comp, i) => (
        <EntityRow
          key={entityRowKey(comp.id, i)}
          title={comp.name || comp.id}
          subtitle={[t(`teamSelect.kinds.${comp.type}`), t(`teamSelect.scopes.${comp.scope}`)].join(
            " · ",
          )}
          badge={<CompetitionBadge comp={comp} projectDir={projectDir} />}
          onEdit={() => onEdit(i)}
          onDelete={() => onDelete(i)}
          onDuplicate={onDuplicate ? () => onDuplicate(i) : undefined}
          duplicateLabel={t("worldEditor.duplicateEntity")}
          editLabel={t("worldEditor.editCompetition")}
          deleteLabel={t("worldEditor.deleteCompetition")}
          isSelected={selectedIndex === i}
          onClick={onSelect ? () => onSelect(i) : undefined}
        />
      ))}
    </EntityListShell>
  );
}
