import { useRatingTiers } from "../../../hooks/useRatingTiers";
import { ratingTierClass } from "../../../lib/ratingTier";
import { calcAgeOnDate, localDateIso } from "../../../lib/valueFormatting";
import { User } from "lucide-react";
import { useTranslation } from "react-i18next";
import { GeneratedAvatar } from "../../ui/GeneratedAvatar";
import { GeneratedCrest } from "../../ui/GeneratedCrest";
import { POSITION_COLOR, PLAYER_ATTR_GROUPS } from "./helpers";
import type { PlayerAttributesDef, PlayerDef, Position, TeamDef } from "./types";
import { useAssetDataUrl } from "../../../hooks/useAssetDataUrl";

function estimateAttributesFromOvr(overall: number, position: Position): PlayerAttributesDef {
  const b = Math.max(30, Math.min(97, overall));
  const isGK = position === "Goalkeeper";
  const isDef = [
    "Defender",
    "CenterBack",
    "RightBack",
    "LeftBack",
    "RightWingBack",
    "LeftWingBack",
  ].includes(position);
  const isFwd = ["Forward", "Striker", "RightWinger", "LeftWinger"].includes(position);
  return {
    pace: b,
    stamina: b,
    strength: b,
    agility: b,
    passing: b,
    shooting: isGK ? 30 : b,
    tackling: isGK || isFwd ? Math.max(20, b - 15) : b,
    dribbling: isGK ? 30 : b,
    defending: isGK ? 35 : isDef ? Math.min(97, b + 3) : b,
    positioning: b,
    vision: b,
    decisions: b,
    composure: b,
    aggression: Math.max(30, b - 10),
    teamwork: b,
    leadership: Math.max(25, b - 10),
    handling: isGK ? b : 20,
    reflexes: isGK ? b : 30,
    aerial: isGK ? b : isDef ? b : Math.max(30, b - 10),
  };
}

/** The editor has no game clock, so the age is as of the real date: "age today". */
function ageToday(dob: string | null): number | null {
  if (!dob || Number.isNaN(new Date(dob).getTime())) return null;
  const age = calcAgeOnDate(dob, localDateIso());
  return age < 0 ? null : age;
}

interface PlayerPreviewCardProps {
  editing: PlayerDef;
  photoDataUrl: string | null;
  teams?: TeamDef[];
  projectDir?: string;
}

export function PlayerPreviewCard({
  editing,
  photoDataUrl,
  teams,
  projectDir,
}: PlayerPreviewCardProps) {
  const tierOf = useRatingTiers();
  const { t } = useTranslation();

  const displayName =
    editing.name || [editing.firstName, editing.lastName].filter(Boolean).join(" ") || null;

  const abbr = t(`common.posAbbr.${editing.position}`, {
    defaultValue: editing.position.slice(0, 2).toUpperCase(),
  });
  const posColor = POSITION_COLOR[editing.position] ?? "bg-fg-subtle";

  const age = ageToday(editing.dateOfBirth);
  const initials = displayName ? displayName.slice(0, 2).toUpperCase() : "?";

  const club = teams?.find((t) => t.id === editing.club);
  const clubName = club?.name ?? editing.club;
  const clubLogoUrl = useAssetDataUrl(club?.logo, projectDir);

  const displayAttrs =
    editing.attributes ??
    (editing.overall !== null
      ? estimateAttributesFromOvr(editing.overall, editing.position)
      : null);
  const isEstimated = !editing.attributes && editing.overall !== null;

  return (
    <div className="rounded-panel border border-line overflow-hidden bg-panel shadow-sm select-none">
      {/* Header */}
      <div className="bg-panel px-4 pt-4 pb-3 flex flex-col items-center gap-2">
        {/* Photo or avatar */}
        {photoDataUrl ? (
          <img
            src={photoDataUrl}
            alt=""
            className="w-16 h-16 rounded-full object-cover border-2 border-line"
          />
        ) : displayName ? (
          <GeneratedAvatar name={displayName} initials={initials} className="w-16 h-16" />
        ) : (
          <div className="w-16 h-16 rounded-full bg-hover flex items-center justify-center">
            <User className="w-8 h-8 text-fg-muted" />
          </div>
        )}

        <div className="text-center">
          <p className="font-heading font-bold text-fg text-body leading-tight">
            {displayName ?? <span className="italic text-fg-subtle">New Player</span>}
          </p>
          <span
            className={`inline-block mt-1 px-2 py-0.5 rounded text-caption font-bold uppercase text-fg ${posColor}`}
          >
            {abbr}
          </span>
        </div>
      </div>

      <div className="p-3 flex flex-col gap-2.5">
        {/* Overall rating badge */}
        {editing.overall !== null && (
          <div className="flex items-baseline gap-1.5">
            <span className="text-caption uppercase tracking-label text-fg-subtle">OVR</span>
            <span
              className={`text-title font-heading font-black leading-none ${ratingTierClass(tierOf(editing.overall), "text")}`}
            >
              {editing.overall}
            </span>
            {isEstimated && <span className="text-caption text-fg-subtle italic">est.</span>}
          </div>
        )}

        {/* Full attribute breakdown */}
        {displayAttrs && (
          <div className="flex flex-col gap-2">
            {PLAYER_ATTR_GROUPS.map(({ groupKey, keys }) => {
              const anySet = keys.some((k) => displayAttrs[k as keyof typeof displayAttrs] != null);
              if (!anySet) return null;
              return (
                <div key={groupKey}>
                  <p className="text-caption font-heading font-bold uppercase tracking-label text-fg-subtle mb-1">
                    {t(`common.attrGroups.${groupKey}`)}
                  </p>
                  <div className="grid grid-cols-2 gap-x-3 gap-y-0.5">
                    {keys.map((key) => {
                      const val = displayAttrs[key as keyof typeof displayAttrs] as
                        | number
                        | undefined;
                      if (val == null) return null;
                      const label = t(`common.attributes.${key}`).slice(0, 3).toUpperCase();
                      return (
                        <div key={key} className="flex items-center gap-1">
                          <span className="w-7 text-caption font-bold uppercase tracking-label text-fg-subtle flex-shrink-0">
                            {label}
                          </span>
                          <div className="flex-1 h-1 bg-hover rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full ${ratingTierClass(tierOf(val), "bar")}`}
                              style={{ width: `${(val / 99) * 100}%` }}
                            />
                          </div>
                          <span className="w-5 text-right text-caption font-bold tabular-nums text-fg flex-shrink-0">
                            {val}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Bio info */}
        <div className="flex flex-col gap-1 text-caption text-fg-muted pt-1 border-t border-line">
          {editing.nationality && (
            <p>
              {t("worldEditor.playerNationality")}:{" "}
              <span className="text-fg">{editing.nationality}</span>
            </p>
          )}
          {editing.club && (
            <div className="flex items-center gap-1.5">
              <span className="shrink-0">{t("worldEditor.playerClub")}:</span>
              {club ? (
                <div className="flex items-center gap-1 min-w-0">
                  {clubLogoUrl ? (
                    <img
                      src={clubLogoUrl}
                      alt=""
                      className="h-4 w-4 shrink-0 rounded object-contain border border-line"
                    />
                  ) : (
                    <GeneratedCrest
                      name={club.name || club.id}
                      label={club.shortName || club.name?.slice(0, 3) || "?"}
                      colors={club.colors}
                      className="w-4 h-4 flex-shrink-0"
                    />
                  )}
                  <span className="text-fg truncate">{clubName}</span>
                </div>
              ) : (
                <span className="text-fg">{editing.club}</span>
              )}
            </div>
          )}
          {editing.dateOfBirth && (
            <p>
              {t("worldEditor.playerDateOfBirth")}:{" "}
              <span className="text-fg">{editing.dateOfBirth}</span>
              {age !== null && (
                <span className="text-fg-subtle">
                  {" "}
                  ({t("worldEditor.playerAgeToday", { age })})
                </span>
              )}
            </p>
          )}
          {editing.footedness && editing.footedness !== "Right" && (
            <p>
              {t("worldEditor.playerFoot")}:{" "}
              <span className="text-fg">{t(`common.footedness.${editing.footedness}`)}</span>
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
