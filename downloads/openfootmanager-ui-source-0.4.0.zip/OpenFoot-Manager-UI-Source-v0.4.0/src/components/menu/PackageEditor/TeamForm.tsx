import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { ArrowLeft, CheckCircle, ImagePlus, Loader2, X } from "lucide-react";
import { LabeledInput, LabeledSelect, labelClass } from "./primitives";
import { useAssetPicker } from "./useAssetPicker";
import { CountryCombobox } from "../../ui/CountryCombobox";
import JerseyIcon from "../../ui/JerseyIcon";
import { PLAY_STYLES, makeRange, normalizePlayStyle, parseRangeBound, toSlug } from "./helpers";
import {
  REPUTATION_MAX,
  deriveTransferBudget,
  formatCompactAmount,
  reputationBandKey,
} from "./teamRanges.helpers";
import type { KitPattern, TeamDef } from "./types";
import { TeamPreviewCard } from "./TeamPreviewCard";

const KIT_PATTERNS: KitPattern[] = ["Solid", "Stripes", "Hoops", "HalfAndHalf", "Diagonal"];

interface TeamFormProps {
  editingTeam: TeamDef;
  editingTeamIndex: number | null;
  isBusy: boolean;
  projectDir?: string;
  onBack: () => void;
  onSave: () => void;
  updateField: <K extends keyof TeamDef>(key: K, value: TeamDef[K]) => void;
  /**
   * Writes through to the saved record instead of only the form buffer. The
   * logo pick already copied the image into the package, so the path must not
   * depend on the user remembering to press Save.
   */
  commitField?: <K extends keyof TeamDef>(key: K, value: TeamDef[K]) => void;
  onAssetError: (err: unknown) => void;
}

export function TeamForm({
  editingTeam,
  editingTeamIndex,
  isBusy,
  projectDir,
  onBack,
  onSave,
  updateField,
  commitField,
  onAssetError,
}: TeamFormProps) {
  const { t, i18n } = useTranslation();
  const [idAutoMode, setIdAutoMode] = useState(editingTeamIndex === null && !editingTeam.id);
  const {
    dataUrl: logoDataUrl,
    pick: pickLogo,
    clear: clearLogo,
  } = useAssetPicker({
    relPath: editingTeam.logo,
    projectDir,
    entityId: () => editingTeam.id || `unnamed-team-${Date.now()}`,
    commit: (relPath) => (commitField ?? updateField)("logo", relPath),
    onError: onAssetError,
  });

  // Both range fields are bare numbers with no natural units. Reputation runs
  // 0–1000 rather than the 0–100 an author reasonably assumes, and finance
  // silently sets the club's transfer budget — so say what the values mean.
  const reputationRange = editingTeam.reputationRange;
  const reputationReadout = (() => {
    if (!reputationRange) return null;
    const [min, max] = reputationRange;
    const minBand = t(`worldEditor.repBands.${reputationBandKey(min)}`);
    const maxBand = t(`worldEditor.repBands.${reputationBandKey(max)}`);
    return minBand === maxBand
      ? t("worldEditor.repReadoutSingle", { min, max, scaleMax: REPUTATION_MAX, band: minBand })
      : t("worldEditor.repReadoutSpan", { min, max, scaleMax: REPUTATION_MAX, minBand, maxBand });
  })();

  const financeRange = editingTeam.financeRange;
  const budgetReadout = financeRange
    ? t("worldEditor.budgetReadout", {
        min: formatCompactAmount(financeRange[0], i18n.language),
        max: formatCompactAmount(financeRange[1], i18n.language),
        transferMin: formatCompactAmount(deriveTransferBudget(financeRange[0]), i18n.language),
        transferMax: formatCompactAmount(deriveTransferBudget(financeRange[1]), i18n.language),
      })
    : null;

  const [repMin, setRepMin] = useState<string>(editingTeam.reputationRange?.[0]?.toString() ?? "");
  const [repMax, setRepMax] = useState<string>(editingTeam.reputationRange?.[1]?.toString() ?? "");
  const [finMin, setFinMin] = useState<string>(editingTeam.financeRange?.[0]?.toString() ?? "");
  const [finMax, setFinMax] = useState<string>(editingTeam.financeRange?.[1]?.toString() ?? "");

  useEffect(() => {
    setRepMin(editingTeam.reputationRange?.[0]?.toString() ?? "");
    setRepMax(editingTeam.reputationRange?.[1]?.toString() ?? "");
    setFinMin(editingTeam.financeRange?.[0]?.toString() ?? "");
    setFinMax(editingTeam.financeRange?.[1]?.toString() ?? "");
    // Sync only when the selected entity changes, not on every field edit
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editingTeamIndex]);

  function handleNameChange(v: string) {
    updateField("name", v);
    if (idAutoMode) updateField("id", toSlug(v));
  }

  return (
    <div className="flex gap-6 items-start">
      <div className="flex-1 min-w-0 flex flex-col gap-4">
        <div className="flex items-center gap-2 mb-2">
          <button
            type="button"
            onClick={onBack}
            className="text-fg-subtle hover:text-fg transition-colors p-1 rounded-control hover:bg-hover"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="text-heading font-heading font-bold uppercase tracking-label text-fg">
            {editingTeamIndex === null ? t("worldEditor.addTeam") : t("worldEditor.editTeam")}
          </h2>
        </div>

        <div className="flex flex-col gap-3">
          <LabeledInput
            label={t("worldEditor.teamId")}
            value={editingTeam.id}
            onChange={(v) => {
              setIdAutoMode(false);
              updateField("id", v);
            }}
            placeholder="man-utd"
            help={t("worldEditor.help.teamId")}
          />
          <LabeledInput
            label={t("worldEditor.teamName")}
            value={editingTeam.name}
            onChange={handleNameChange}
          />
          <LabeledInput
            label={t("worldEditor.teamShortName")}
            value={editingTeam.shortName}
            onChange={(v) => updateField("shortName", v)}
          />

          {projectDir && (
            <div className="flex flex-col gap-1">
              <label className={labelClass}>{t("worldEditor.teamLogo")}</label>
              <div className="flex items-center gap-3">
                {logoDataUrl ? (
                  <img
                    src={logoDataUrl}
                    alt=""
                    className="w-12 h-12 rounded-control object-contain border border-line bg-panel flex-shrink-0"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-control border border-dashed border-line-strong bg-sunken flex items-center justify-center flex-shrink-0">
                    <ImagePlus className="w-5 h-5 text-fg-subtle" />
                  </div>
                )}
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      void pickLogo();
                    }}
                    className="px-3 py-1.5 text-caption font-heading font-bold uppercase tracking-label rounded-control border border-line bg-panel text-fg hover:bg-sunken transition"
                  >
                    {t("worldEditor.chooseLogo")}
                  </button>
                  {editingTeam.logo && (
                    <button
                      type="button"
                      onClick={() => {
                        clearLogo();
                      }}
                      className="px-2 py-1.5 text-caption rounded-control border border-line text-fg-subtle hover:text-danger transition"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          <LabeledInput
            label={t("worldEditor.teamFoundedYear")}
            type="number"
            value={editingTeam.foundedYear?.toString() ?? ""}
            onChange={(v) => {
              if (!v) return updateField("foundedYear", null);
              const year = Number(v);
              if (Number.isInteger(year) && year >= 0 && year <= 0xffffffff) {
                updateField("foundedYear", year);
              }
            }}
            placeholder="e.g. 1892"
          />
          <LabeledInput
            label={t("worldEditor.teamCity")}
            value={editingTeam.city}
            onChange={(v) => updateField("city", v)}
          />
          <CountryCombobox
            label={t("worldEditor.teamCountry")}
            value={editingTeam.country}
            onChange={(v) => updateField("country", v)}
          />
          <LabeledSelect
            label={t("worldEditor.teamPlayStyle")}
            value={normalizePlayStyle(editingTeam.playStyle)}
            options={PLAY_STYLES}
            optionLabels={Object.fromEntries(
              PLAY_STYLES.map((style) => [style, t(`common.playStyles.${style}`)]),
            )}
            onChange={(v) => updateField("playStyle", v)}
          />
          <LabeledInput
            label={t("worldEditor.teamStadium")}
            value={editingTeam.stadiumName}
            onChange={(v) => updateField("stadiumName", v)}
          />
          <LabeledInput
            label={t("tactics.formation")}
            value={editingTeam.formation ?? ""}
            placeholder="e.g. 4-2-3-1"
            onChange={(v) => updateField("formation", v.trim() || null)}
          />

          <div className="flex gap-3">
            <div className="flex flex-col gap-1 flex-1">
              <label className="text-caption font-heading font-bold uppercase tracking-[0.18em] text-fg-muted">
                {t("worldEditor.teamPrimaryColor")}
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={
                    /^#[0-9a-fA-F]{6}$/.test(editingTeam.colors.primary)
                      ? editingTeam.colors.primary
                      : "#000000"
                  }
                  onChange={(e) =>
                    updateField("colors", { ...editingTeam.colors, primary: e.target.value })
                  }
                  className="w-9 h-9 rounded-control border border-line cursor-pointer p-0.5 bg-panel flex-shrink-0"
                />
                <input
                  type="text"
                  value={editingTeam.colors.primary}
                  onChange={(e) =>
                    updateField("colors", { ...editingTeam.colors, primary: e.target.value })
                  }
                  className="flex-1 rounded-control border border-line bg-panel px-3 py-2 text-body text-fg focus:outline-none focus:ring-2 focus-visible:ring-focus transition font-mono"
                  placeholder="#cc0000"
                />
              </div>
            </div>
            <div className="flex flex-col gap-1 flex-1">
              <label className="text-caption font-heading font-bold uppercase tracking-[0.18em] text-fg-muted">
                {t("worldEditor.teamSecondaryColor")}
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={
                    /^#[0-9a-fA-F]{6}$/.test(editingTeam.colors.secondary)
                      ? editingTeam.colors.secondary
                      : "#ffffff"
                  }
                  onChange={(e) =>
                    updateField("colors", { ...editingTeam.colors, secondary: e.target.value })
                  }
                  className="w-9 h-9 rounded-control border border-line cursor-pointer p-0.5 bg-panel flex-shrink-0"
                />
                <input
                  type="text"
                  value={editingTeam.colors.secondary}
                  onChange={(e) =>
                    updateField("colors", { ...editingTeam.colors, secondary: e.target.value })
                  }
                  className="flex-1 rounded-control border border-line bg-panel px-3 py-2 text-body text-fg focus:outline-none focus:ring-2 focus-visible:ring-focus transition font-mono"
                  placeholder="#ffffff"
                />
              </div>
            </div>
          </div>

          {/* Kit pattern selector */}
          <div className="flex flex-col gap-1.5">
            <label className={labelClass}>{t("worldEditor.teamKitPattern")}</label>
            <div className="flex gap-2 flex-wrap">
              {KIT_PATTERNS.map((pattern) => {
                const isSelected = (editingTeam.kitPattern ?? "Solid") === pattern;
                return (
                  <button
                    key={pattern}
                    type="button"
                    onClick={() => updateField("kitPattern", pattern)}
                    title={pattern}
                    className={`flex flex-col items-center gap-1 p-2 rounded-panel border transition-all ${
                      isSelected
                        ? "border-selected bg-selected-tint"
                        : "border-line hover:border-line-strong"
                    }`}
                  >
                    <JerseyIcon
                      primaryColor={editingTeam.colors.primary || "#cc0000"}
                      secondaryColor={editingTeam.colors.secondary || "#ffffff"}
                      pattern={pattern}
                      size="sm"
                    />
                    <span className="text-caption font-heading font-bold uppercase tracking-label text-fg-muted">
                      {pattern === "HalfAndHalf" ? "½+½" : pattern}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <div className="grid grid-cols-2 gap-3">
              <LabeledInput
                label={t("worldEditor.teamRepMin")}
                value={repMin}
                type="number"
                help={t("worldEditor.help.teamReputationRange")}
                onChange={(v) => {
                  setRepMin(v);
                  updateField(
                    "reputationRange",
                    makeRange(parseRangeBound(v), parseRangeBound(repMax)),
                  );
                }}
              />
              <LabeledInput
                label={t("worldEditor.teamRepMax")}
                value={repMax}
                type="number"
                onChange={(v) => {
                  setRepMax(v);
                  updateField(
                    "reputationRange",
                    makeRange(parseRangeBound(repMin), parseRangeBound(v)),
                  );
                }}
              />
            </div>
            {reputationReadout && (
              <p className="text-caption text-fg-muted" aria-live="polite">
                {reputationReadout}
              </p>
            )}
            <div className="grid grid-cols-2 gap-3">
              <LabeledInput
                label={t("worldEditor.teamFinMin")}
                value={finMin}
                type="number"
                help={t("worldEditor.help.teamFinanceRange")}
                onChange={(v) => {
                  setFinMin(v);
                  updateField(
                    "financeRange",
                    makeRange(parseRangeBound(v), parseRangeBound(finMax)),
                  );
                }}
              />
              <LabeledInput
                label={t("worldEditor.teamFinMax")}
                value={finMax}
                type="number"
                onChange={(v) => {
                  setFinMax(v);
                  updateField(
                    "financeRange",
                    makeRange(parseRangeBound(finMin), parseRangeBound(v)),
                  );
                }}
              />
            </div>
            {budgetReadout && (
              <p className="text-caption text-fg-muted" aria-live="polite">
                {budgetReadout}
              </p>
            )}
          </div>
        </div>

        <button
          type="button"
          onClick={onSave}
          disabled={
            isBusy ||
            !editingTeam.id ||
            !editingTeam.name ||
            !editingTeam.city ||
            !editingTeam.country
          }
          className="w-full py-3 bg-gradient-to-r from-selected-fill to-selected-fill text-on-brand rounded-panel font-heading font-bold uppercase tracking-label transition-all disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {isBusy ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <CheckCircle className="w-4 h-4" />
          )}
          {t("worldEditor.saveTeam")}
        </button>
      </div>
      <div className="w-52 flex-shrink-0 sticky top-0">
        <TeamPreviewCard team={editingTeam} logoDataUrl={logoDataUrl} />
      </div>
    </div>
  );
}
