import { useId, useState } from "react";
import { useTranslation } from "react-i18next";
import { ImagePlus, X } from "lucide-react";
import { useAssetPicker } from "./useAssetPicker";
import { LabeledInput, LabeledSelect, labelClass } from "./primitives";
import { EntityFormShell } from "./shared";
import { DatePicker } from "../../ui/DatePicker";
import { Checkbox } from "../../ui/Checkbox";
import { CountryCombobox } from "../../ui/CountryCombobox";
import { TeamCombobox } from "../../ui/TeamCombobox";
import {
  POSITIONS,
  PLAYER_ATTR_GROUPS,
  emptyAttributes,
  parseOptionalWhole,
  parseRating,
  toSlug,
  WIRE_MAX,
  type PlayerAttrKey,
} from "./helpers";
import type { Footedness, PlayerDef, TeamDef } from "./types";

const FOOT_OPTIONS: Footedness[] = ["Right", "Left", "Both"];
import { PlayerPreviewCard } from "./PlayerPreviewCard";
import { PlayerCareerFields } from "./PlayerCareerFields";
import { PlayerContractFields } from "./PlayerContractFields";
import { PlayerStatusFields } from "./PlayerStatusFields";

interface PlayerFormProps {
  editing: PlayerDef;
  editingIndex: number | null;
  isBusy: boolean;
  teams?: TeamDef[];
  projectDir?: string;
  onBack: () => void;
  onSave: () => void;
  updateField: <K extends keyof PlayerDef>(key: K, value: PlayerDef[K]) => void;
  /**
   * Writes through to the saved record instead of only the form buffer. The
   * photo pick already copied the image into the package, so the path must not
   * depend on the user remembering to press Save.
   */
  commitField?: <K extends keyof PlayerDef>(key: K, value: PlayerDef[K]) => void;
  onAssetError: (err: unknown) => void;
}

export function PlayerForm({
  editing,
  editingIndex,
  isBusy,
  teams,
  projectDir,
  onBack,
  onSave,
  updateField,
  commitField,
  onAssetError,
}: PlayerFormProps) {
  const { t } = useTranslation();
  const dobLabelId = useId();
  const [useAttributes, setUseAttributes] = useState(editing.attributes !== null);
  const [idAutoMode, setIdAutoMode] = useState(editingIndex === null && !editing.id);
  const {
    dataUrl: photoDataUrl,
    pick: pickPhoto,
    clear: clearPhoto,
  } = useAssetPicker({
    relPath: editing.photo,
    projectDir,
    entityId: () => editing.id || `unnamed-player-${Date.now()}`,
    commit: (relPath) => (commitField ?? updateField)("photo", relPath),
    onError: onAssetError,
  });

  const inputClass =
    "w-full rounded-control border border-line bg-panel px-3 py-2 text-body text-fg focus:outline-none focus:ring-2 focus-visible:ring-focus transition";

  function toggleAttributes(checked: boolean) {
    setUseAttributes(checked);
    if (checked) {
      updateField("overall", null);
      if (!editing.attributes) {
        updateField("attributes", emptyAttributes());
      }
    } else {
      updateField("attributes", null);
    }
  }

  function updateAttr(key: PlayerAttrKey, value: number) {
    updateField("attributes", { ...(editing.attributes ?? emptyAttributes()), [key]: value });
  }

  function handleNameChange(v: string) {
    updateField("name", v);
    if (idAutoMode) updateField("id", toSlug(v));
  }

  const attrs = editing.attributes ?? emptyAttributes();
  const teamsWithIds = teams?.filter((t) => t.id) ?? [];
  const teamOptions = teamsWithIds.map((team) => ({
    id: team.id,
    label: team.name || team.id,
    logo: team.logo,
    shortName: team.shortName,
    colors: team.colors,
  }));
  const positionLabels = Object.fromEntries(
    POSITIONS.map((p) => [p, t(`common.positions.${p}`)]),
  ) as Record<string, string>;

  return (
    <div className="flex gap-6 items-start">
      <div className="flex-1 min-w-0">
        <EntityFormShell
          title={editingIndex === null ? t("worldEditor.addPlayer") : t("worldEditor.editPlayer")}
          onBack={onBack}
          onSave={onSave}
          isBusy={isBusy}
          saveDisabled={!editing.id}
          saveLabel={t("worldEditor.savePlayer")}
        >
          <LabeledInput
            label={t("worldEditor.playerId")}
            value={editing.id}
            onChange={(v) => {
              setIdAutoMode(false);
              updateField("id", v);
            }}
            placeholder="player-001"
          />
          <LabeledInput
            label={t("worldEditor.playerFirstName")}
            value={editing.firstName}
            onChange={(v) => updateField("firstName", v)}
          />
          <LabeledInput
            label={t("worldEditor.playerLastName")}
            value={editing.lastName}
            onChange={(v) => updateField("lastName", v)}
          />
          <LabeledInput
            label={t("worldEditor.playerName")}
            value={editing.name}
            onChange={handleNameChange}
            placeholder={t("worldEditor.playerDisplayNamePlaceholder")}
          />

          {/* Photo */}
          {projectDir && (
            <div className="flex flex-col gap-1">
              <label className={labelClass}>{t("worldEditor.playerPhoto")}</label>
              <div className="flex items-center gap-3">
                {photoDataUrl ? (
                  <img
                    src={photoDataUrl}
                    alt=""
                    className="w-12 h-12 rounded-full object-cover border border-line bg-panel flex-shrink-0"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-full border border-dashed border-line-strong bg-sunken flex items-center justify-center flex-shrink-0">
                    <ImagePlus className="w-5 h-5 text-fg-subtle" />
                  </div>
                )}
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      void pickPhoto();
                    }}
                    className="px-3 py-1.5 text-caption font-heading font-bold uppercase tracking-label rounded-control border border-line bg-panel text-fg hover:bg-sunken transition"
                  >
                    {t("worldEditor.chooseLogo")}
                  </button>
                  {editing.photo && (
                    <button
                      type="button"
                      onClick={() => {
                        clearPhoto();
                      }}
                      className="px-2 py-1.5 text-caption rounded-control border border-line text-fg-subtle hover:text-danger transition"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Club picker */}
          {teamOptions.length > 0 ? (
            <TeamCombobox
              label={t("worldEditor.playerClub")}
              value={editing.club}
              options={teamOptions}
              onChange={(v) => updateField("club", v)}
              projectDir={projectDir}
              placeholder={t("worldEditor.noClubSelected")}
            />
          ) : (
            <div className="flex flex-col gap-1">
              <label className={labelClass}>{t("worldEditor.playerClub")}</label>
              <input
                type="text"
                value={editing.club}
                onChange={(e) => updateField("club", e.target.value)}
                placeholder="team-id"
                className={inputClass}
              />
            </div>
          )}

          <CountryCombobox
            label={t("worldEditor.playerNationality")}
            value={editing.nationality}
            onChange={(v) => updateField("nationality", v)}
          />

          <div className="grid grid-cols-2 gap-3">
            <LabeledSelect
              label={t("worldEditor.playerPosition")}
              value={editing.position}
              options={POSITIONS}
              optionLabels={positionLabels}
              onChange={(v) => updateField("position", v as PlayerDef["position"])}
            />
            <LabeledSelect
              label={t("worldEditor.playerFoot")}
              value={editing.footedness ?? "Right"}
              options={FOOT_OPTIONS}
              optionLabels={{
                Right: t("common.footedness.Right"),
                Left: t("common.footedness.Left"),
                Both: t("common.footedness.Both"),
              }}
              onChange={(v) => updateField("footedness", v as Footedness)}
            />
          </div>
          <div className="flex flex-col gap-1">
            <label id={dobLabelId} className={labelClass}>
              {t("worldEditor.playerDateOfBirth")}
            </label>
            <DatePicker
              labelledBy={dobLabelId}
              value={editing.dateOfBirth ?? ""}
              onChange={(v) => updateField("dateOfBirth", v || null)}
            />
          </div>
          <LabeledInput
            label={t("worldEditor.playerAge")}
            help={t("worldEditor.playerAgeHelp")}
            value={editing.age?.toString() ?? ""}
            type="number"
            onChange={(v) => updateField("age", parseOptionalWhole(v, WIRE_MAX.u32))}
          />

          <div className="flex items-center gap-2 py-1">
            <Checkbox
              id="use-attributes"
              checked={useAttributes}
              onChange={(e) => toggleAttributes(e.target.checked)}
              aria-label={t("worldEditor.playerUseAttributes")}
            />
            <label htmlFor="use-attributes" className={labelClass}>
              {t("worldEditor.playerUseAttributes")}
            </label>
          </div>

          {!useAttributes && (
            <LabeledInput
              label={t("worldEditor.playerOverall")}
              value={editing.overall?.toString() ?? ""}
              type="number"
              onChange={(v) => updateField("overall", parseRating(v))}
            />
          )}

          {/*
        Outside both branches on purpose: a ceiling is independent of whether
        ability was given as an overall or a full attribute block, and gating it
        on the toggle would hide it from exactly the authors exercising the most
        precise control. Clamped to 1-99 only — never up to the player's ability,
        which would silently repair a mistake the package validator reports.
      */}
          <LabeledInput
            label={t("worldEditor.playerPotential")}
            help={t("worldEditor.playerPotentialHelp")}
            value={editing.potential?.toString() ?? ""}
            type="number"
            onChange={(v) => updateField("potential", parseRating(v))}
          />

          {useAttributes && (
            <div className="flex flex-col gap-3">
              {PLAYER_ATTR_GROUPS.map(({ groupKey, keys }) => (
                <div key={groupKey}>
                  <p className={`${labelClass} mb-1`}>{t(`common.attrGroups.${groupKey}`)}</p>
                  <div className="grid grid-cols-2 gap-2">
                    {keys.map((key) => (
                      <div key={key} className="flex flex-col gap-0.5">
                        <label className="text-caption font-heading uppercase tracking-label text-fg-subtle">
                          {t(`common.attributes.${key}`)}
                        </label>
                        <div className="flex items-center gap-1.5">
                          <input
                            type="range"
                            min={1}
                            max={99}
                            value={attrs[key as keyof typeof attrs]}
                            onChange={(e) =>
                              updateAttr(key as PlayerAttrKey, parseInt(e.target.value, 10))
                            }
                            className="flex-1 accent-selected-fill"
                          />
                          <span className="text-caption font-mono text-fg-muted w-5 text-right">
                            {attrs[key as keyof typeof attrs]}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          <PlayerContractFields editing={editing} updateField={updateField} />
          <PlayerStatusFields editing={editing} updateField={updateField} />
          <PlayerCareerFields
            entries={editing.careerHistory ?? []}
            teamOptions={teamOptions}
            projectDir={projectDir}
            onChange={(entries) => updateField("careerHistory", entries)}
          />
        </EntityFormShell>
      </div>
      <div className="w-64 flex-shrink-0 sticky top-0">
        <PlayerPreviewCard
          editing={editing}
          photoDataUrl={photoDataUrl}
          teams={teams}
          projectDir={projectDir}
        />
      </div>
    </div>
  );
}
