import {
  Check,
  Copy,
  Trash2,
  Crosshair,
  Flag,
  Plus,
  RefreshCw,
  RotateCcw,
  Save,
  Search,
  Shield,
  Target,
  Zap,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState, type JSX } from "react";
import type { TFunction } from "i18next";
import { useTranslation } from "react-i18next";

import { Badge, Button, Card, Select } from "../ui";
import TacticsDeleteDialog from "./TacticsDeleteDialog";
import { FORMATIONS } from "./TacticsTab.helpers";

export interface TacticsLibraryEntry {
  description: string;
  formation: string;
  id: string;
  name: string;
  playStyle: string;
  sourcePresetName?: string | null;
  type: "preset" | "custom";
}

interface TacticsCommandBarProps {
  activeTactic: TacticsLibraryEntry;
  activePlayStyle: string;
  formation: string;
  isDirty: boolean;
  /** Whether pressing Reset would change anything; the library decides, the bar renders. */
  canReset: boolean;
  onReset: () => void;
  /** Whether the active tactic is a saved custom one, the only kind that can be deleted. */
  canDelete: boolean;
  onCreateNew: () => void;
  onDelete: () => void;
  onDuplicate: () => void;
  onFormationChange: (formation: string) => void;
  onPlayStyleChange: (playStyle: string) => void;
  onSave: () => void;
  onSelectTactic: (id: string) => void;
  tacticLibrary: TacticsLibraryEntry[];
}

const SAVE_CUE_DURATION_MS = 2000;

const PLAY_STYLES = [
  { id: "Balanced", icon: <Target className="h-3.5 w-3.5" /> },
  { id: "Attacking", icon: <Zap className="h-3.5 w-3.5" /> },
  { id: "Defensive", icon: <Shield className="h-3.5 w-3.5" /> },
  { id: "Possession", icon: <RefreshCw className="h-3.5 w-3.5" /> },
  { id: "Counter", icon: <Crosshair className="h-3.5 w-3.5" /> },
  { id: "HighPress", icon: <Flag className="h-3.5 w-3.5" /> },
] as const;

function summarizeTactic(entry: TacticsLibraryEntry, t: TFunction): string {
  return `${entry.formation} - ${t(`common.playStyles.${entry.playStyle}`, entry.playStyle)}`;
}

export default function TacticsCommandBar({
  activeTactic,
  activePlayStyle,
  formation,
  isDirty,
  canReset,
  onReset,
  canDelete,
  onCreateNew,
  onDelete,
  onDuplicate,
  onFormationChange,
  onPlayStyleChange,
  onSave,
  onSelectTactic,
  tacticLibrary,
}: TacticsCommandBarProps): JSX.Element {
  const { t } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [showSavedCue, setShowSavedCue] = useState(false);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const wrapperRef = useRef<HTMLDivElement | null>(null);
  const savedCueTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const filteredLibrary = useMemo(() => {
    const query = search.trim().toLowerCase();

    if (!query) {
      return tacticLibrary;
    }

    return tacticLibrary.filter((entry) =>
      [
        entry.name,
        entry.description,
        entry.formation,
        entry.playStyle,
        entry.sourcePresetName,
        entry.type,
      ]
        .join(" ")
        .toLowerCase()
        .includes(query),
    );
  }, [search, tacticLibrary]);

  const presetEntries = filteredLibrary.filter((entry) => entry.type === "preset");
  const customEntries = filteredLibrary.filter((entry) => entry.type === "custom");

  const saveLabel =
    activeTactic.type === "custom" ? t("tactics.updateTactic") : t("tactics.saveAsTactic");
  // Saving a synced custom tactic is a silent no-op — nothing has changed to
  // persist. Presets stay enabled even when isDirty is false because saving
  // there always creates a new custom tactic, which is an observable action.
  const isSaveDisabled = activeTactic.type === "custom" && !isDirty;

  useEffect(() => {
    const handlePointerDown = (event: MouseEvent) => {
      if (!wrapperRef.current?.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener("mousedown", handlePointerDown);
    return () => document.removeEventListener("mousedown", handlePointerDown);
  }, []);

  useEffect(() => {
    return () => {
      if (savedCueTimeoutRef.current) {
        clearTimeout(savedCueTimeoutRef.current);
      }
    };
  }, []);

  function handleSaveClick(): void {
    onSave();
    setShowSavedCue(true);

    if (savedCueTimeoutRef.current) {
      clearTimeout(savedCueTimeoutRef.current);
    }

    savedCueTimeoutRef.current = setTimeout(() => {
      setShowSavedCue(false);
    }, SAVE_CUE_DURATION_MS);
  }

  return (
    <Card className="overflow-visible">
      <div ref={wrapperRef} className="p-4 sm:p-5">
        <div className="flex flex-col gap-4">
          <div className="flex flex-col gap-3 xl:flex-row xl:items-start xl:justify-between">
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-caption font-heading font-bold uppercase tracking-[0.24em] text-fg-muted">
                  {t("tactics.presetTactics")}
                </span>
                <Badge variant={activeTactic.type === "custom" ? "accent" : "success"} size="sm">
                  {activeTactic.type === "custom"
                    ? t("tactics.customTactic")
                    : t("tactics.activePreset")}
                </Badge>
                <Badge variant={isDirty ? "accent" : "neutral"} size="sm">
                  {isDirty ? t("tactics.unsavedChanges") : t("tactics.synced")}
                </Badge>
              </div>
              <p className="mt-2 max-w-3xl text-body text-fg-muted">{activeTactic.description}</p>
            </div>

            <div className="flex flex-wrap gap-2 xl:justify-end">
              <Button type="button" variant="ghost" size="sm" icon={<Plus />} onClick={onCreateNew}>
                {t("tactics.newTactic")}
              </Button>
              <Button type="button" variant="ghost" size="sm" icon={<Copy />} onClick={onDuplicate}>
                {t("tactics.duplicateTactic")}
              </Button>
              {canDelete ? (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  icon={<Trash2 />}
                  onClick={() => setConfirmingDelete(true)}
                >
                  {t("tactics.deleteTactic")}
                </Button>
              ) : null}
              <Button
                type="button"
                variant="ghost"
                size="sm"
                icon={<RotateCcw />}
                onClick={onReset}
                disabled={!canReset}
              >
                {t("tactics.resetTactic")}
              </Button>
              <Button
                type="button"
                variant="accent"
                size="sm"
                icon={showSavedCue && !isDirty ? <Check /> : <Save />}
                onClick={handleSaveClick}
                disabled={isSaveDisabled}
                className="min-w-[9.5rem]"
              >
                {showSavedCue && !isDirty ? t("tactics.tacticSaved") : saveLabel}
              </Button>
            </div>
          </div>

          <div className="grid gap-3 xl:grid-cols-[minmax(0,1.15fr)_minmax(18rem,0.85fr)_minmax(0,1.2fr)]">
            <div className="relative rounded-panel border bg-sunken p-3 border-line/8">
              <div className="mb-2 flex items-center justify-between gap-3">
                <div className="text-caption font-heading font-bold uppercase tracking-[0.24em] text-fg-muted">
                  {t("tactics.chooseTactic")}
                </div>
                <div className="text-caption font-heading font-bold uppercase tracking-[0.18em] text-selected">
                  {activeTactic.type === "custom" ? t("tactics.myTactics") : t("tactics.presets")}
                </div>
              </div>

              <button
                type="button"
                aria-label={t("tactics.chooseTactic")}
                aria-expanded={isOpen}
                aria-haspopup="listbox"
                onClick={() => setIsOpen((open) => !open)}
                className="flex w-full items-center justify-between rounded-panel border bg-panel px-3 py-3 text-left transition-colors hover:border-selected/40 border-line/10"
              >
                <div className="min-w-0">
                  <div className="truncate text-body font-heading font-bold text-fg">
                    {activeTactic.name}
                  </div>
                  <div className="mt-1 truncate text-caption uppercase tracking-[0.18em] text-fg-muted">
                    {summarizeTactic(activeTactic, t)}
                  </div>
                </div>
                <div className="shrink-0 rounded-full bg-selected-tint px-2 py-1 text-caption font-heading font-bold uppercase tracking-[0.18em] text-selected">
                  {activeTactic.type === "custom" ? t("tactics.myTactics") : t("tactics.presets")}
                </div>
              </button>

              {isOpen ? (
                <div className="absolute left-0 right-0 top-full z-50 mt-2 rounded-panel border border-line bg-panel p-2 shadow-2xl">
                  <div className="mb-2 flex items-center gap-2 rounded-panel border border-line bg-sunken px-3 py-2">
                    <Search className="h-4 w-4 text-fg-subtle" />
                    <input
                      type="text"
                      value={search}
                      onChange={(event) => setSearch(event.target.value)}
                      aria-label={t("tactics.searchTactics")}
                      placeholder={t("tactics.searchTactics")}
                      className="w-full bg-transparent text-body text-fg outline-none placeholder:text-fg-subtle"
                    />
                  </div>

                  <div
                    role="listbox"
                    aria-label={t("tactics.chooseTactic")}
                    className="max-h-80 space-y-3 overflow-y-auto p-1"
                  >
                    {customEntries.length > 0 ? (
                      <div>
                        <div className="mb-2 px-2 text-caption font-heading font-bold uppercase tracking-[0.22em] text-fg-muted">
                          {t("tactics.myTactics")}
                        </div>
                        <div className="space-y-1">
                          {customEntries.map((entry) => (
                            <button
                              key={entry.id}
                              type="button"
                              role="option"
                              aria-selected={entry.id === activeTactic.id}
                              onClick={() => {
                                onSelectTactic(entry.id);
                                setIsOpen(false);
                                setSearch("");
                              }}
                              className={`w-full rounded-panel border px-3 py-3 text-left transition-colors ${
                                entry.id === activeTactic.id
                                  ? "border-selected/40 bg-selected-tint"
                                  : "border-transparent bg-sunken hover:bg-panel/70 hover:border-line-strong"
                              }`}
                            >
                              <div className="flex items-start justify-between gap-3">
                                <div className="min-w-0">
                                  <div className="truncate text-body font-heading font-bold text-fg">
                                    {entry.name}
                                  </div>
                                  <div className="mt-1 text-caption text-fg-muted">
                                    {entry.description}
                                  </div>
                                </div>
                                <span className="shrink-0 text-caption font-heading font-bold uppercase tracking-[0.18em] text-selected">
                                  {summarizeTactic(entry, t)}
                                </span>
                              </div>
                            </button>
                          ))}
                        </div>
                      </div>
                    ) : null}

                    <div>
                      <div className="mb-2 px-2 text-caption font-heading font-bold uppercase tracking-[0.22em] text-fg-muted">
                        {t("tactics.presets")}
                      </div>
                      <div className="space-y-1">
                        {presetEntries.map((entry) => (
                          <button
                            key={entry.id}
                            type="button"
                            role="option"
                            aria-selected={entry.id === activeTactic.id}
                            onClick={() => {
                              onSelectTactic(entry.id);
                              setIsOpen(false);
                              setSearch("");
                            }}
                            className={`w-full rounded-panel border px-3 py-3 text-left transition-colors ${
                              entry.id === activeTactic.id
                                ? "border-selected/40 bg-selected-tint"
                                : "border-transparent bg-sunken hover:bg-panel/70 hover:border-line-strong"
                            }`}
                          >
                            <div className="flex items-start justify-between gap-3">
                              <div className="min-w-0">
                                <div className="truncate text-body font-heading font-bold text-fg">
                                  {entry.name}
                                </div>
                                <div className="mt-1 text-caption text-fg-muted">
                                  {entry.description}
                                </div>
                              </div>
                              <span className="shrink-0 text-caption font-heading font-bold uppercase tracking-[0.18em] text-selected">
                                {summarizeTactic(entry, t)}
                              </span>
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ) : null}
            </div>

            <div className="rounded-panel border bg-sunken p-3 border-line/8">
              <div className="mb-2 text-caption font-heading font-bold uppercase tracking-[0.24em] text-fg-muted">
                {t("tactics.formation")}
              </div>
              <Select
                value={FORMATIONS.includes(formation) ? formation : FORMATIONS[0]}
                onChange={(e) => onFormationChange(e.target.value)}
                fullWidth
                aria-label={t("tactics.formation")}
              >
                {FORMATIONS.map((f) => (
                  <option key={f} value={f}>
                    {f}
                  </option>
                ))}
              </Select>
            </div>

            <div className="rounded-panel border bg-sunken p-3 border-line/8">
              <div className="mb-2 text-caption font-heading font-bold uppercase tracking-[0.24em] text-fg-muted">
                {t("tactics.playStyle")}
              </div>
              <Select
                value={activePlayStyle}
                onChange={(e) => onPlayStyleChange(e.target.value)}
                fullWidth
                aria-label={t("tactics.playStyle")}
              >
                {PLAY_STYLES.map((style) => (
                  // Native <option> renders text only — an icon/span child is
                  // stripped by the browser and warns in React, so use plain text.
                  <option key={style.id} value={style.id}>
                    {t(`common.playStyles.${style.id}`, style.id)}
                  </option>
                ))}
              </Select>
            </div>
          </div>
        </div>
      </div>
      {confirmingDelete ? (
        <TacticsDeleteDialog
          name={activeTactic.name}
          onCancel={() => setConfirmingDelete(false)}
          onConfirm={() => {
            setConfirmingDelete(false);
            onDelete();
          }}
        />
      ) : null}
    </Card>
  );
}
