import { fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { invoke } from "@tauri-apps/api/core";

import type { GameStateData, PlayerData, StaffData, TeamData } from "../../store/gameStore";
import { calcAge } from "../../lib/helpers";
import type { PlayerSummary, PlayersPage, PlayersPageQuery } from "../../services/playersService";
import { resetPackageAssetRoot } from "../../hooks/usePackageAssetSrc";
import PlayersListTab from "./PlayersListTab";
import { ratingTierClass } from "../../lib/ratingTier";
import { createSeasonContext } from "../../test-utils/factories";
import { useSettingsStore } from "../../store/settingsStore";

vi.mock("../../hooks/usePositionGroups", async () => {
  const { cannedPositionsModule } = await import("../../test-utils/positionTable");
  return cannedPositionsModule();
});

vi.mock("../../hooks/useRatingTiers", async () => {
  const { cannedRatingTiersModule } = await import("../../test-utils/ratingTiers");
  return cannedRatingTiersModule();
});

vi.mock("@tauri-apps/api/core", () => ({
  convertFileSrc: vi.fn((path: string) => `asset://localhost/${path}`),
  invoke: vi.fn(),
  isTauri: vi.fn(() => false),
}));

// Package artwork resolves through the asset protocol, which needs the app data
// directory. Without this the hook's catch treats every packaged photo as
// missing and the rows fall back to generated avatars.
vi.mock("@tauri-apps/api/path", () => ({
  appDataDir: vi.fn(async () => "/home/u/.local/share/ofm"),
}));

vi.mock("../../utils/backendI18n", () => ({
  resolveBackendError: (error: unknown) => (error instanceof Error ? error.message : String(error)),
}));

vi.mock("react-i18next", () => ({
  useTranslation: () => ({
    t: (key: string, params?: Record<string, string | number>) => {
      if (key === "players.searchPlaceholder") return "Search players";
      if (key === "players.allPos") return "All positions";
      if (key.startsWith("common.positionGroups.")) return key.split(".").pop() as string;
      if (key === "players.allTeams") return "All teams";
      if (key === "players.nPlayersFound") return `${params?.count} players`;
      if (key === "players.noMatch") return "No matches";
      if (key === "common.all") return "All";
      if (key === "common.position") return "Position";
      if (key === "common.name") return "Name";
      if (key === "common.age") return "Age";
      if (key === "common.nationality") return "Nationality";
      if (key === "common.team") return "Team";
      if (key === "common.viewTeam") return "View team";
      if (key === "common.freeAgent") return "Free Agent";
      if (key === "common.value") return "Value";
      if (key === "common.ovr") return "OVR";
      if (key === "common.status") return "Status";
      if (key === "squad.viewProfile") return "View profile";
      if (key === "squad.addToTransferList") return "Add to transfer list";
      if (key === "squad.removeFromTransferList") return "Remove from transfer list";
      if (key === "squad.addToLoanList") return "Add to loan list";
      if (key === "squad.removeFromLoanList") return "Remove from loan list";
      if (key === "scouting.scoutBtn") return "Scout";
      if (key === "scouting.scoutingInProgress") return "Scouting in progress";
      if (key === "scouting.noScoutsFree") return "No scouts free";
      if (key === "transfers.makeBid") return "Make Transfer Bid";
      if (key === "transfers.offerContract") return "Offer Contract";
      if (key === "transfers.bidAmount") return "Bid Amount";
      if (key === "transfers.submitBid") return "Submit Bid";
      if (key === "transfers.close") return "Close";
      if (key === "transfers.playerValue") return `Value: ${params?.value}`;
      if (key === "transfers.bidImpactTitle") return "Projected impact";
      if (key === "transfers.bidImpactTransferBudget") {
        return `Transfer budget ${params?.before} -> ${params?.after}`;
      }
      if (key === "transfers.bidImpactBalance") {
        return `Club balance ${params?.before} -> ${params?.after}`;
      }
      if (key === "transfers.bidImpactWagePressure") {
        return `Projected wage budget usage ${params?.percent}%`;
      }
      if (key === "transfers.bidImpactOverTransferBudget") {
        return "This bid exceeds your transfer budget";
      }
      if (key === "transfers.bidImpactOverBalance") {
        return "This bid would push the club into debt";
      }
      if (key === "transfers.negotiationPulse") return "Negotiation pulse";
      if (key === "transfers.negotiationRound") return `Round ${params?.count}`;
      if (key === "transfers.negotiationPatience") return "Patience";
      if (key === "transfers.negotiationTension") return "Tension";
      if (key === "transfers.bidCountered") return "Bid countered";
      if (key === "transfers.transfer") return "Transfer";
      if (key === "transfers.loan") return "Loan";
      if (key === "common.injured") return "Injured";
      if (key.startsWith("common.posAbbr.")) {
        return key.replace("common.posAbbr.", "");
      }
      return key;
    },
    i18n: { language: "en" },
  }),
}));

function createTeam(overrides: Partial<TeamData> = {}): TeamData {
  return {
    id: "team-1",
    name: "Alpha FC",
    short_name: "ALP",
    country: "GB",
    city: "London",
    stadium_name: "Alpha Ground",
    stadium_capacity: 30000,
    finance: 500000,
    manager_id: "manager-1",
    reputation: 50,
    wage_budget: 50000,
    transfer_budget: 250000,
    season_income: 0,
    season_expenses: 0,
    formation: "4-4-2",
    play_style: "Balanced",
    training_focus: "General",
    training_intensity: "Balanced",
    training_schedule: "Balanced",
    founded_year: 1900,
    colors: { primary: "#000000", secondary: "#ffffff" },
    starting_xi_ids: [],
    form: [],
    history: [],
    ...overrides,
  };
}

function createPlayer(overrides: Partial<PlayerData> = {}): PlayerData {
  return {
    id: "player-1",
    match_name: "J. Smith",
    full_name: "John Smith",
    date_of_birth: "2000-01-01",
    nationality: "GB",
    position: "Forward",
    natural_position: "Forward",
    alternate_positions: [],
    training_focus: null,
    attributes: {
      pace: 60,
      stamina: 60,
      strength: 60,
      agility: 60,
      passing: 60,
      shooting: 60,
      tackling: 60,
      dribbling: 60,
      defending: 60,
      positioning: 60,
      vision: 60,
      decisions: 60,
      composure: 60,
      aggression: 60,
      teamwork: 60,
      leadership: 60,
      handling: 20,
      reflexes: 20,
      aerial: 60,
    },
    condition: 80,
    morale: 75,
    injury: null,
    team_id: "team-1",
    retired: false,
    contract_end: "2027-06-30",
    wage: 12000,
    market_value: 350000,
    stats: {
      appearances: 0,
      goals: 0,
      assists: 0,
      clean_sheets: 0,
      yellow_cards: 0,
      red_cards: 0,
      avg_rating: 0,
      minutes_played: 0,
    },
    career: [],
    transfer_listed: false,
    loan_listed: false,
    transfer_offers: [],
    traits: [],
    ...overrides,
  };
}

function createScout(overrides: Partial<StaffData> = {}): StaffData {
  return {
    id: "staff-1",
    first_name: "Sam",
    last_name: "Scout",
    display_name: "Sam Scout",
    date_of_birth: "1985-01-01",
    nationality: "GB",
    role: "Scout",
    attributes: {
      coaching: 20,
      judgingAbility: 65,
      judgingPotential: 70,
      physiotherapy: 10,
    },
    team_id: "team-1",
    specialization: null,
    wage: 1000,
    contract_end: "2027-06-30",
    ...overrides,
  };
}

function createGameState(): GameStateData {
  return {
    season_context: createSeasonContext(),
    clock: {
      current_date: "2026-08-01T00:00:00Z",
      start_date: "2026-07-01T00:00:00Z",
    },
    manager: {
      display_name: "Jane Doe",
      id: "manager-1",
      first_name: "Jane",
      last_name: "Doe",
      date_of_birth: "1980-01-01",
      nationality: "GB",
      reputation: 50,
      satisfaction: 50,
      fan_approval: 50,
      team_id: "team-1",
      career_stats: {
        matches_managed: 0,
        wins: 0,
        draws: 0,
        losses: 0,
        trophies: 0,
        best_finish: null,
      },
      career_history: [],
    },
    teams: [createTeam(), createTeam({ id: "team-2", name: "Beta FC", short_name: "BET" })],
    players: [
      createPlayer(),
      createPlayer({
        id: "player-2",
        match_name: "A. Keeper",
        full_name: "Alex Keeper",
        position: "Goalkeeper",
        natural_position: "Goalkeeper",
        team_id: "team-2",
      }),
      createPlayer({
        id: "player-3",
        match_name: "D. Loan",
        full_name: "David Loan",
        position: "Defender",
        natural_position: "Defender",
        team_id: "team-2",
        loan_listed: true,
      }),
    ],
    staff: [],
    messages: [],
    news: [],
    league: null,
    scouting_assignments: [],
    board_objectives: [],
  };
}

const mockedInvoke = vi.mocked(invoke);

function groupPosition(pos: string): string {
  if (pos === "Goalkeeper") return "Goalkeeper";
  if (pos === "Defender" || pos.endsWith("Back")) return "Defender";
  if (pos === "Midfielder" || pos.endsWith("Midfielder")) return "Midfielder";
  return "Forward";
}

function summaryFrom(player: PlayerData, teams: TeamData[]): PlayerSummary {
  const team_name = player.team_id
    ? (teams.find((t) => t.id === player.team_id)?.name ?? null)
    : null;
  return {
    id: player.id,
    full_name: player.full_name,
    match_name: player.match_name,
    date_of_birth: player.date_of_birth,
    age: calcAge(player.date_of_birth),
    wage: { kind: "exact", weekly: player.wage },
    nationality: player.nationality,
    position: player.position,
    natural_position: player.natural_position ?? player.position,
    team_id: player.team_id ?? null,
    team_name,
    market_value: player.market_value,
    ovr: (player as { ovr?: number }).ovr ?? 0,
    transfer_listed: player.transfer_listed,
    loan_listed: player.loan_listed,
    injured: player.injury != null,
    retired: player.retired ?? false,
    media: { face: player.media?.face ?? null },
  };
}

function applyQuery(items: PlayerSummary[], query: PlayersPageQuery): PlayersPage {
  let filtered = items;
  if (query.search) {
    const needle = query.search.toLowerCase();
    filtered = filtered.filter(
      (s) =>
        s.full_name.toLowerCase().includes(needle) ||
        s.match_name.toLowerCase().includes(needle) ||
        s.nationality.toLowerCase().includes(needle),
    );
  }
  if (query.position) {
    filtered = filtered.filter((s) => groupPosition(s.natural_position) === query.position);
  }
  if (query.positions.length > 0) {
    filtered = filtered.filter((s) =>
      query.positions.some((test) =>
        "exact" in test
          ? s.natural_position === test.exact
          : groupPosition(s.natural_position) === test.group,
      ),
    );
  }
  if (query.team_id) {
    filtered = filtered.filter((s) => s.team_id === query.team_id);
  }
  if (query.status === "transfer") {
    filtered = filtered.filter((s) => s.transfer_listed);
  } else if (query.status === "loan") {
    filtered = filtered.filter((s) => s.loan_listed);
  }
  return {
    items: filtered,
    status_counts: { all: 0, transfer: 0, loan: 0, free_agent: 0, available: 0 },
    total: filtered.length,
    page: query.page,
    page_size: query.page_size,
  };
}

type InvokeOverrides = Record<string, (args: unknown) => unknown>;

function setupSliceMock(gameState: GameStateData, overrides: InvokeOverrides = {}) {
  mockedInvoke.mockImplementation(async (cmd: string, args?: unknown) => {
    if (cmd in overrides) {
      const result = overrides[cmd]!(args);
      if (result instanceof Error) throw result;
      return result;
    }
    if (cmd === "get_players_page") {
      const summaries = gameState.players.map((p) => summaryFrom(p, gameState.teams));
      const query = (args as { query: PlayersPageQuery }).query;
      return applyQuery(summaries, query);
    }
    return undefined;
  });
}

describe("PlayersListTab", () => {
  beforeEach(() => {
    mockedInvoke.mockReset();
    // The resolved app data dir is cached for the module's lifetime, so it
    // would otherwise leak across tests.
    resetPackageAssetRoot();
  });

  it("filters by search and position before selecting a player", async () => {
    const onSelectPlayer = vi.fn();
    const gameState = createGameState();
    setupSliceMock(gameState);

    render(
      <PlayersListTab
        gameState={gameState}
        onSelectPlayer={onSelectPlayer}
        onSelectTeam={vi.fn()}
      />,
    );

    await screen.findByText("A. Keeper");
    expect(screen.getByText("J. Smith")).toBeInTheDocument();

    fireEvent.change(screen.getByPlaceholderText("Search players"), {
      target: { value: "keeper" },
    });

    await waitFor(() => {
      expect(screen.queryByText("J. Smith")).not.toBeInTheDocument();
    });
    expect(screen.getByText("A. Keeper")).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: "Goalkeeper" }));
    fireEvent.click(await screen.findByText("A. Keeper"));

    expect(onSelectPlayer).toHaveBeenCalledWith("player-2");
  });

  /**
   * Given the directory is open
   * When a minimum age is typed in the filters
   * Then the backend is asked for that range, on the first page.
   */
  it("asks the backend for the age range typed in the filters", async () => {
    const gameState = createGameState();
    setupSliceMock(gameState);
    render(
      <PlayersListTab gameState={gameState} onSelectPlayer={vi.fn()} onSelectTeam={vi.fn()} />,
    );
    await screen.findByText("A. Keeper");

    fireEvent.change(screen.getByLabelText("players.filterAgeMin"), { target: { value: "21" } });

    await waitFor(() => {
      expect(mockedInvoke).toHaveBeenCalledWith(
        "get_players_page",
        expect.objectContaining({ query: expect.objectContaining({ age_min: 21, page: 1 }) }),
      );
    });
  });

  it("keeps team navigation separate from player row selection", async () => {
    const onSelectPlayer = vi.fn();
    const onSelectTeam = vi.fn();
    const gameState = createGameState();
    setupSliceMock(gameState);

    render(
      <PlayersListTab
        gameState={gameState}
        onSelectPlayer={onSelectPlayer}
        onSelectTeam={onSelectTeam}
      />,
    );

    await screen.findByText("A. Keeper");
    fireEvent.click(screen.getAllByRole("button", { name: "Beta FC" })[0]);

    expect(onSelectTeam).toHaveBeenCalledWith("team-2");
    expect(onSelectPlayer).not.toHaveBeenCalled();
  });

  it("renders localized free-agent labels for unattached players", async () => {
    const gameState: GameStateData = {
      ...createGameState(),
      players: [
        createPlayer({
          id: "player-free-agent",
          full_name: "Free Agent Player",
          match_name: "F. Agent",
          team_id: null,
          contract_end: null,
        }),
      ],
    };
    setupSliceMock(gameState);

    render(
      <PlayersListTab gameState={gameState} onSelectPlayer={vi.fn()} onSelectTeam={vi.fn()} />,
    );

    expect(await screen.findByText("Free Agent")).toBeInTheDocument();
  });

  it("renders a player photo shipped in an installed package", async () => {
    const gameState: GameStateData = {
      ...createGameState(),
      players: [
        createPlayer({
          id: "player-packaged",
          full_name: "Packaged Player",
          match_name: "P. Player",
          media: { face: "brazil-1962/assets/images/pele.png" },
        }),
      ],
    };
    setupSliceMock(gameState);

    render(
      <PlayersListTab gameState={gameState} onSelectPlayer={vi.fn()} onSelectTeam={vi.fn()} />,
    );

    // A package-qualified path resolves a tick after mount, so the row shows a
    // generated avatar first.
    const photo = await screen.findByRole("img", { name: "Packaged Player" });
    expect(photo).toHaveAttribute(
      "src",
      "asset://localhost//home/u/.local/share/ofm/package-assets/brazil-1962/assets/images/pele.png",
    );
  });

  it("offers context-menu actions for team navigation and scouting", async () => {
    const onGameUpdate = vi.fn();
    const onSelectPlayer = vi.fn();
    const onSelectTeam = vi.fn();
    const gameState = createGameState();
    gameState.staff = [createScout()];
    setupSliceMock(gameState, { send_scout: () => gameState });

    render(
      <PlayersListTab
        gameState={gameState}
        onGameUpdate={onGameUpdate}
        onSelectPlayer={onSelectPlayer}
        onSelectTeam={onSelectTeam}
      />,
    );

    const playerRow = (await screen.findByText("A. Keeper")).closest("tr");
    expect(playerRow).not.toBeNull();

    fireEvent.contextMenu(playerRow as HTMLTableRowElement);
    fireEvent.click(screen.getByRole("menuitem", { name: "View team" }));

    expect(onSelectTeam).toHaveBeenCalledWith("team-2");

    fireEvent.contextMenu(playerRow as HTMLTableRowElement);
    fireEvent.click(screen.getByRole("menuitem", { name: "Scout" }));

    await waitFor(() => {
      expect(mockedInvoke).toHaveBeenCalledWith("send_scout", {
        careerToken: 0,
        scoutId: "staff-1",
        playerId: "player-2",
      });
      expect(onGameUpdate).toHaveBeenCalledWith(gameState);
    });
  });

  it("shows scout assignment errors inline", async () => {
    const consoleErrorSpy = vi.spyOn(console, "error").mockImplementation(() => {});
    try {
      const onGameUpdate = vi.fn();
      const gameState = createGameState();
      gameState.staff = [createScout()];
      setupSliceMock(gameState, {
        send_scout: () => new Error("Scout is already assigned to another scouting task."),
      });

      render(
        <PlayersListTab
          gameState={gameState}
          onGameUpdate={onGameUpdate}
          onSelectPlayer={vi.fn()}
          onSelectTeam={vi.fn()}
        />,
      );

      const playerRow = (await screen.findByText("A. Keeper")).closest("tr");
      expect(playerRow).not.toBeNull();

      fireEvent.contextMenu(playerRow as HTMLTableRowElement);
      fireEvent.click(screen.getByRole("menuitem", { name: "Scout" }));

      await waitFor(() => {
        expect(screen.getByRole("alert")).toHaveTextContent(
          "Scout is already assigned to another scouting task.",
        );
      });

      expect(onGameUpdate).not.toHaveBeenCalled();
    } finally {
      consoleErrorSpy.mockRestore();
    }
  });

  /**
   * Given the manager's own player and a save that fails
   * When he lists the player for transfer from the context menu
   * Then the failure shows above the list, and nothing is reported as updated.
   */
  it("shows a failed transfer listing inline", async () => {
    const consoleErrorSpy = vi.spyOn(console, "error").mockImplementation(() => {});
    try {
      const onGameUpdate = vi.fn();
      const gameState = createGameState();
      setupSliceMock(gameState, {
        toggle_transfer_list: () => new Error("Could not save the listing."),
      });

      render(
        <PlayersListTab
          gameState={gameState}
          onGameUpdate={onGameUpdate}
          onSelectPlayer={vi.fn()}
          onSelectTeam={vi.fn()}
        />,
      );

      const playerRow = await screen.findByRole("row", { name: /J\. Smith/ });
      fireEvent.contextMenu(playerRow);
      fireEvent.click(screen.getByRole("menuitem", { name: "Add to transfer list" }));

      await waitFor(() => {
        expect(screen.getByRole("alert")).toHaveTextContent("Could not save the listing.");
      });
      // The new alert follows the design system: the danger token and a role size, in sentence
      // case, with no raw palette colour or fixed text size.
      const alert = screen.getByRole("alert");
      expect(alert).toHaveClass("text-danger", "bg-danger-tint", "text-body");
      expect(alert.className).not.toMatch(/text-red|text-xs|uppercase/);
      expect(onGameUpdate).not.toHaveBeenCalled();
    } finally {
      consoleErrorSpy.mockRestore();
    }
  });

  it("opens and submits a transfer bid from the player context menu", async () => {
    const onGameUpdate = vi.fn();
    const gameState = createGameState();
    const updatedState = createGameState();

    setupSliceMock(gameState, {
      preview_transfer_bid_financial_impact: () => ({
        projection: {
          transfer_budget_before: 250000,
          transfer_budget_after: -100000,
          finance_before: 500000,
          finance_after: 150000,
          annual_wage_bill_before: 1000,
          annual_wage_bill_after: 2000,
          annual_wage_budget: 50000,
          projected_wage_budget_usage_pct: 4,
          exceeds_transfer_budget: false,
          exceeds_finance: false,
        },
      }),
      make_transfer_bid: () => ({
        decision: "counter_offer",
        suggested_fee: 425000,
        is_terminal: false,
        feedback: {
          mood: "firm",
          headline_key: "headline",
          detail_key: null,
          tension: 45,
          patience: 62,
          round: 1,
        },
        game: updatedState,
      }),
    });

    render(
      <PlayersListTab
        gameState={gameState}
        onGameUpdate={onGameUpdate}
        onSelectPlayer={vi.fn()}
        onSelectTeam={vi.fn()}
      />,
    );

    const playerRow = (await screen.findByText("A. Keeper")).closest("tr");
    expect(playerRow).not.toBeNull();

    fireEvent.contextMenu(playerRow as HTMLTableRowElement);
    fireEvent.click(screen.getByRole("menuitem", { name: "Make Transfer Bid" }));

    expect(screen.getByText("Make Transfer Bid")).toBeInTheDocument();

    await waitFor(() => {
      expect(mockedInvoke).toHaveBeenCalledWith("preview_transfer_bid_financial_impact", {
        playerId: "player-2",
        fee: 300000,
      });
    });

    await waitFor(() => {
      expect(screen.getByRole("button", { name: "Submit Bid" })).not.toBeDisabled();
    });

    fireEvent.click(screen.getByRole("button", { name: "Submit Bid" }));

    await waitFor(() => {
      expect(mockedInvoke).toHaveBeenCalledWith("make_transfer_bid", {
        careerToken: 0,
        playerId: "player-2",
        fee: 300000,
      });
      expect(onGameUpdate).toHaveBeenCalledWith(updatedState);
    });
  });

  it("does not offer scouting or contract actions for retired free agents", async () => {
    const gameState: GameStateData = {
      ...createGameState(),
      players: [
        createPlayer({
          id: "retired-free-agent",
          full_name: "Retired Free Agent",
          match_name: "R. Agent",
          team_id: null,
          retired: true,
          contract_end: null,
        }),
      ],
    };
    setupSliceMock(gameState);

    render(
      <PlayersListTab
        gameState={gameState}
        onGameUpdate={vi.fn()}
        onSelectPlayer={vi.fn()}
        onSelectTeam={vi.fn()}
      />,
    );

    const playerRow = (await screen.findByText("R. Agent")).closest("tr");
    expect(playerRow).not.toBeNull();

    fireEvent.contextMenu(playerRow as HTMLTableRowElement);

    expect(screen.queryByRole("button", { name: "Offer Contract" })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Scout" })).not.toBeInTheDocument();
  });
});

describe("PlayersListTab rating tiers", () => {
  /**
   * Given two players rated 76 and 77, either side of the A-tier cut-off
   * When the players list renders
   * Then each rating takes the colour of its backend tier (B and A), not one from a threshold here.
   */
  it("colours each rating by its backend tier", async () => {
    const gameState: GameStateData = {
      ...createGameState(),
      players: [
        createPlayer({ id: "p-76", full_name: "Seventy Six", match_name: "S. Six", ovr: 76 }),
        createPlayer({ id: "p-77", full_name: "Seventy Seven", match_name: "S. Seven", ovr: 77 }),
      ],
    };
    setupSliceMock(gameState);

    render(
      <PlayersListTab gameState={gameState} onSelectPlayer={vi.fn()} onSelectTeam={vi.fn()} />,
    );

    expect(await screen.findByText("77")).toHaveClass(...ratingTierClass("A", "text").split(" "));
    expect(screen.getByText("76")).toHaveClass(...ratingTierClass("B", "text").split(" "));
  });

  /**
   * Given a player the club knows nothing private about (rated 88, but the backend sends no
   *      rating for him)
   * When the players list renders his row
   * Then his rating reads "–" in the neutral colour, never a number
   */
  it("shows a dash for a rating the club does not know", async () => {
    const stranger = createPlayer({
      id: "p-far",
      full_name: "Far Stranger",
      match_name: "F. Stranger",
      ovr: 88,
    });
    const gameState: GameStateData = { ...createGameState(), players: [stranger] };
    setupSliceMock(gameState, {
      get_players_page: (args) =>
        applyQuery(
          [{ ...summaryFrom(stranger, gameState.teams), ovr: null, wage: { kind: "hidden" } }],
          (args as { query: PlayersPageQuery }).query,
        ),
    });

    render(
      <PlayersListTab gameState={gameState} onSelectPlayer={vi.fn()} onSelectTeam={vi.fn()} />,
    );

    const row = (await screen.findByText("F. Stranger")).closest("tr") as HTMLElement;
    const headers = within(row.closest("table") as HTMLElement).getAllByRole("columnheader");
    const ovrColumn = headers.findIndex((header) => header.textContent?.includes("OVR"));
    const rating = within(row).getAllByRole("cell")[ovrColumn];
    expect(rating).toHaveTextContent("–");
    expect(rating).not.toHaveTextContent("88");
    expect(rating.firstElementChild).toHaveClass(...ratingTierClass("Rest", "text").split(" "));
  });
});

function setListView(view: "table" | "cards") {
  useSettingsStore.setState({
    settings: { ...useSettingsStore.getState().settings, list_view: view },
  });
}

describe("PlayersListTab cards view", () => {
  beforeEach(() => {
    mockedInvoke.mockReset();
    resetPackageAssetRoot();
    setListView("cards");
  });

  afterEach(() => setListView("table"));

  /**
   * Given list_view is "cards"
   * When the players list renders
   * Then each player is a card named for him, there is no table, and the card's name opens his
   *      profile while his club's button selects the club without opening him.
   */
  it("draws one card per player, and keeps the club button apart from the card", async () => {
    const onSelectPlayer = vi.fn();
    const onSelectTeam = vi.fn();
    const gameState = createGameState();
    setupSliceMock(gameState);

    render(
      <PlayersListTab
        gameState={gameState}
        onSelectPlayer={onSelectPlayer}
        onSelectTeam={onSelectTeam}
      />,
    );

    const card = await screen.findByRole("article", { name: "A. Keeper" });
    expect(screen.queryByRole("table")).toBeNull();
    expect(screen.getAllByRole("article")).toHaveLength(gameState.players.length);

    fireEvent.click(within(card).getByRole("button", { name: "Beta FC" }));
    expect(onSelectTeam).toHaveBeenCalledWith("team-2");
    expect(onSelectPlayer).not.toHaveBeenCalled();

    fireEvent.click(within(card).getByRole("button", { name: "A. Keeper" }));
    expect(onSelectPlayer).toHaveBeenCalledWith("player-2");
  });

  /**
   * Given a transfer-listed, injured free agent whose rating and wage the club may not see
   * When his card renders
   * Then it shows a dash for the rating, a dash for the wage, the free-agent label, and his
   *      listing and injury as status badges.
   */
  it("shows hidden figures as dashes and the listing and injury as status", async () => {
    const stranger = createPlayer({
      id: "p-far",
      full_name: "Far Stranger",
      match_name: "F. Stranger",
      team_id: null,
      ovr: 88,
    });
    const gameState: GameStateData = { ...createGameState(), players: [stranger] };
    setupSliceMock(gameState, {
      get_players_page: (args) =>
        applyQuery(
          [
            {
              ...summaryFrom(stranger, gameState.teams),
              ovr: null,
              wage: { kind: "hidden" },
              transfer_listed: true,
              injured: true,
            },
          ],
          (args as { query: PlayersPageQuery }).query,
        ),
    });

    render(
      <PlayersListTab gameState={gameState} onSelectPlayer={vi.fn()} onSelectTeam={vi.fn()} />,
    );

    const card = await screen.findByRole("article", { name: "F. Stranger" });
    expect(within(card).getByText("Free Agent")).toBeInTheDocument();
    expect(within(card).queryByText("88")).toBeNull();
    expect(within(card).getAllByText("–")).toHaveLength(2);
    expect(within(card).getByText("Transfer")).toBeInTheDocument();
    expect(within(card).getByText("Injured")).toBeInTheDocument();
  });

  /**
   * Given the table view is showing
   * When the player picks Cards in the view switch
   * Then the list becomes cards and the choice is saved as list_view.
   */
  it("switches to cards and saves the choice", async () => {
    setListView("table");
    const gameState = createGameState();
    setupSliceMock(gameState);

    render(
      <PlayersListTab gameState={gameState} onSelectPlayer={vi.fn()} onSelectTeam={vi.fn()} />,
    );
    await screen.findByRole("table");

    fireEvent.click(screen.getByRole("radio", { name: "common.listViewCards" }));

    expect(await screen.findAllByRole("article")).not.toHaveLength(0);
    expect(screen.queryByRole("table")).toBeNull();
    expect(mockedInvoke).toHaveBeenCalledWith(
      "save_settings",
      expect.objectContaining({ settings: expect.objectContaining({ list_view: "cards" }) }),
    );
  });

  /**
   * Given a card
   * When it is right-clicked
   * Then the same context menu as the table row opens, with its View profile action.
   */
  it("opens the row's context menu from a card", async () => {
    const onSelectPlayer = vi.fn();
    const gameState = createGameState();
    setupSliceMock(gameState);

    render(
      <PlayersListTab
        gameState={gameState}
        onSelectPlayer={onSelectPlayer}
        onSelectTeam={vi.fn()}
      />,
    );
    const card = await screen.findByRole("article", { name: "A. Keeper" });
    fireEvent.contextMenu(card);
    fireEvent.click(await screen.findByText("View profile"));

    expect(onSelectPlayer).toHaveBeenCalledWith("player-2");
  });
});

describe("PlayersListTab paging", () => {
  beforeEach(() => {
    mockedInvoke.mockReset();
    resetPackageAssetRoot();
  });

  afterEach(() => setListView("table"));

  /**
   * Given a result of 60 players at 30 a page
   * When the next page is chosen, in the table view and in the cards view
   * Then the footer reads "1 / 2" and the backend is asked for page 2.
   */
  it.each(["table", "cards"] as const)("pages through the %s view", async (view) => {
    setListView(view);
    const gameState = createGameState();
    const requested: number[] = [];
    setupSliceMock(gameState, {
      get_players_page: (args) => {
        const query = (args as { query: PlayersPageQuery }).query;
        requested.push(query.page);
        return { ...applyQuery([], query), total: 60, page_size: 30 };
      },
    });

    render(
      <PlayersListTab gameState={gameState} onSelectPlayer={vi.fn()} onSelectTeam={vi.fn()} />,
    );
    expect(await screen.findByText("1 / 2")).toBeInTheDocument();

    // Four icon-only buttons, each named for a screen reader.
    for (const name of ["common.firstPage", "common.previousPage", "common.lastPage"]) {
      expect(screen.getByRole("button", { name })).toBeInTheDocument();
    }
    fireEvent.click(screen.getByRole("button", { name: "common.nextPage" }));

    await waitFor(() => expect(requested).toContain(2));
  });
});

describe("PlayersListTab sort and load errors", () => {
  beforeEach(() => {
    mockedInvoke.mockReset();
    resetPackageAssetRoot();
  });

  afterEach(() => setListView("table"));

  /** The queries the list has asked the backend for, in order. */
  function requestedQueries(): PlayersPageQuery[] {
    return mockedInvoke.mock.calls
      .filter(([command]) => command === "get_players_page")
      .map(([, args]) => (args as { query: PlayersPageQuery }).query);
  }
  const lastQuery = () => requestedQueries().slice(-1)[0];

  /**
   * Given the cards view, which has no column headers
   * When the sort field is changed to Age, and then the direction is flipped
   * Then the list asks the backend for that field, and then for the other direction.
   */
  it("sorts the cards by the field and direction the sort control picks", async () => {
    setListView("cards");
    const gameState = createGameState();
    setupSliceMock(gameState);
    render(
      <PlayersListTab gameState={gameState} onSelectPlayer={vi.fn()} onSelectTeam={vi.fn()} />,
    );
    await screen.findAllByRole("article");

    fireEvent.click(screen.getByRole("combobox", { name: "common.sortBy" }));
    fireEvent.click(screen.getByRole("option", { name: "Age" }));
    await waitFor(() => expect(lastQuery()?.sort_key).toBe("age"));
    expect(lastQuery()?.sort_asc).toBe(false);

    fireEvent.click(screen.getByRole("button", { name: "common.sortAscending" }));
    await waitFor(() => expect(lastQuery()?.sort_asc).toBe(true));
    expect(lastQuery()?.sort_key).toBe("age");
  });

  /**
   * Given a sort picked in the cards view
   * When the player switches to the table
   * Then the table keeps that sort: it is one query, written by both controls.
   */
  it("keeps the sort when the view changes", async () => {
    setListView("cards");
    const gameState = createGameState();
    setupSliceMock(gameState);
    render(
      <PlayersListTab gameState={gameState} onSelectPlayer={vi.fn()} onSelectTeam={vi.fn()} />,
    );
    await screen.findAllByRole("article");
    fireEvent.click(screen.getByRole("combobox", { name: "common.sortBy" }));
    fireEvent.click(screen.getByRole("option", { name: "Age" }));
    await waitFor(() => expect(lastQuery()?.sort_key).toBe("age"));

    fireEvent.click(screen.getByRole("radio", { name: "common.listViewTable" }));
    await screen.findByRole("table");

    expect(lastQuery()?.sort_key).toBe("age");
  });

  /**
   * Given the first page of players fails to load
   * When the list renders, in the table and in the cards
   * Then the error is shown alone: no "No matches", which would say the search found no one.
   */
  it.each(["table", "cards"] as const)(
    "shows the load error without a no-match message in the %s view",
    async (view) => {
      setListView(view);
      const gameState = createGameState();
      setupSliceMock(gameState, { get_players_page: () => new Error("backend down") });
      render(
        <PlayersListTab gameState={gameState} onSelectPlayer={vi.fn()} onSelectTeam={vi.fn()} />,
      );

      expect(await screen.findByRole("alert")).toBeInTheDocument();
      expect(screen.queryByText("No matches")).toBeNull();
    },
  );
});
