import { useSquadFitness } from "../../hooks/useSquadFitness";
import type { GameStateData } from "../../store/gameStore";
import { Card, CardHeader, CardBody, Badge } from "../ui";
import { formatDateShort, getUserCompetition } from "../../lib/helpers";
import { useFetchedSquad } from "../../hooks/useFetchedSquad";
import { isFirstTeamSquadPlayer } from "../../lib/playerSquad";
import NextMatchDisplay from "../NextMatchDisplay";
import { resolveBoardObjective, resolveMessage, resolveNewsArticle } from "../../utils/backendI18n";
import {
  getHomeRosterOverview,
  getLeagueDigestArticles,
  getNextOpponentWidgetData,
  getOnboardingCompletionState,
  getRecentResultsForTeam,
} from "./HomeTab.helpers";
import HomeLeagueDigestCard from "./HomeLeagueDigestCard";
import HomeLeaguePositionCard from "./HomeLeaguePositionCard";
import HomeLatestNewsCard from "./HomeLatestNewsCard";
import HomeNextOpponentCard from "./HomeNextOpponentCard";
import HomePlayerMomentumCard from "./HomePlayerMomentumCard";
import HomeRecentResultsCard from "./HomeRecentResultsCard";
import HomeRecentMessagesCard from "./HomeRecentMessagesCard";
import HomeSquadOverviewCard from "./HomeSquadOverviewCard";
import HomeSeasonStatusCard from "./HomeSeasonStatusCard";
import HomeUnavailablePlayersCard from "./HomeUnavailablePlayersCard";
import { isMessageVisible } from "../../utils/newsVisibility";
import {
  Dumbbell,
  Mail,
  Flame,
  Scale,
  Feather,
  CheckCircle2,
  Circle,
  Users,
  Crosshair,
  UserCog,
} from "lucide-react";
import { useTranslation } from "react-i18next";
import HomeOnboardingChecklistCard from "./HomeOnboardingChecklistCard";
import JobOpportunitiesCard from "./JobOpportunitiesCard";

interface HomeTabProps {
  gameState: GameStateData;
  onNavigate?: (tab: string, context?: { messageId?: string }) => void;
  onGameUpdate?: (state: GameStateData) => void;
  visitedOnboardingTabs: ReadonlySet<string>;
}

const SCHEDULE_ICONS: Record<string, { icon: React.ReactNode; color: string }> = {
  Intense: { icon: <Flame className="w-3.5 h-3.5" />, color: "text-danger" },
  Balanced: {
    icon: <Scale className="w-3.5 h-3.5" />,
    color: "text-selected",
  },
  Light: {
    icon: <Feather className="w-3.5 h-3.5" />,
    color: "text-info",
  },
};

export default function HomeTab({
  gameState,
  onNavigate,
  onGameUpdate,
  visitedOnboardingTabs,
}: HomeTabProps) {
  const { t, i18n } = useTranslation();
  const myTeam = gameState.teams.find((tm) => tm.id === gameState.manager.team_id);
  const [fetchedSquad] = useFetchedSquad(
    myTeam?.id ?? null,
    gameState.clock.current_date,
    gameState,
  );
  const league = getUserCompetition(gameState);
  const roster = myTeam
    ? (fetchedSquad ?? gameState.players).filter(
        (p) => p.team_id === myTeam.id && isFirstTeamSquadPlayer(p),
      )
    : [];
  const { avgOvr, coldPlayers, hotPlayers, unavailablePlayers } = getHomeRosterOverview(roster);
  // Fitness is the backend's: injured players are not in the squad that can play.
  const fitness = useSquadFitness(gameState);
  const avgCondition =
    fitness?.average_condition != null ? Math.round(fitness.average_condition) : null;
  const avgConditionTone = fitness?.average_status?.tone ?? null;
  const exhaustedCount = fitness?.exhausted_count ?? 0;
  const resolveInjuryName = (injuryName: string): string => {
    if (injuryName.includes(".")) {
      return t(injuryName, { defaultValue: injuryName });
    }

    return t(`common.injuries.${injuryName}`, { defaultValue: injuryName });
  };

  // Current date / season context
  const lang = i18n.language;
  const seasonContext = gameState.season_context;
  const isPreseason = seasonContext.phase === "Preseason";
  const seasonStartLabel = seasonContext.season_start
    ? formatDateShort(seasonContext.season_start, lang)
    : null;
  const transferWindow = seasonContext.transfer_window;
  const transferWindowVariant =
    transferWindow.status === "DeadlineDay"
      ? "danger"
      : transferWindow.status === "Open"
        ? "success"
        : "neutral";
  const transferWindowSummary =
    transferWindow.status === "DeadlineDay"
      ? t("season.windowClosesToday")
      : transferWindow.status === "Open" && transferWindow.days_remaining !== null
        ? t("season.windowClosesInDays", {
            count: transferWindow.days_remaining,
          })
        : transferWindow.status === "Closed" && transferWindow.days_until_opens !== null
          ? t("season.windowOpensInDays", {
              count: transferWindow.days_until_opens,
            })
          : t("season.windowClosed");

  // League position — sort a copy: sorting the store's array in place is a
  // state mutation during render. Tiebreak matches the standings table
  // (points → goal difference → goals for).
  const myStandingIndex =
    !isPreseason && league && myTeam
      ? [...league.standings]
          .sort(
            (a, b) =>
              b.points - a.points ||
              b.goals_for - b.goals_against - (a.goals_for - a.goals_against) ||
              b.goals_for - a.goals_for,
          )
          .findIndex((s) => s.team_id === myTeam.id)
      : -1;
  const myStanding = myStandingIndex >= 0 ? myStandingIndex + 1 : null;
  const myStandingData =
    !isPreseason && league && myTeam
      ? (league.standings.find((s) => s.team_id === myTeam.id) ?? null)
      : null;

  const recentResults = getRecentResultsForTeam(gameState, myTeam?.id ?? null);

  // Training schedule
  const schedule = myTeam?.training_schedule || "Balanced";
  const schedIcons = SCHEDULE_ICONS[schedule] || SCHEDULE_ICONS.Balanced;
  const schedLabel = t(`common.trainingSchedules.${schedule}`, schedule);
  const focus = myTeam?.training_focus || "Physical";

  // Latest news — copy before sorting; gameState.news is the store's array.
  const latestNews = [...(gameState.news || [])]
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, 2)
    .map(resolveNewsArticle);
  const recentMessages = (gameState.messages || [])
    .filter((message) => isMessageVisible(message.date, gameState.clock?.current_date))
    .slice(0, 4)
    .map(resolveMessage);
  const nextOpponent = getNextOpponentWidgetData(gameState, t);
  const leagueDigestArticles = getLeagueDigestArticles(gameState).map(resolveNewsArticle);
  const boardObjectives = (gameState.board_objectives || []).map(resolveBoardObjective);
  const onboardingState = getOnboardingCompletionState(gameState, visitedOnboardingTabs);

  const onboardingSteps = [
    {
      id: "squad",
      done: onboardingState.hasVisitedSquadPage,
      label: t("onboarding.reviewSquad"),
      description: t("onboarding.reviewSquadDesc"),
      tab: "Squad",
      icon: <Users className="w-4 h-4" />,
    },
    {
      id: "staff",
      done: onboardingState.hasVisitedStaffPage,
      label: t("onboarding.hireStaff"),
      description: t("onboarding.hireStaffDesc"),
      tab: "Staff",
      icon: <UserCog className="w-4 h-4" />,
    },
    {
      id: "tactics",
      done: onboardingState.hasVisitedTacticsPage,
      label: t("onboarding.setTactics"),
      description: t("onboarding.setTacticsDesc"),
      tab: "Tactics",
      icon: <Crosshair className="w-4 h-4" />,
    },
    {
      id: "training",
      done: onboardingState.hasVisitedTrainingPage,
      label: t("onboarding.configTraining"),
      description: t("onboarding.configTrainingDesc"),
      tab: "Training",
      icon: <Dumbbell className="w-4 h-4" />,
    },
    {
      id: "inbox",
      done: onboardingState.hasReadInbox,
      label: t("onboarding.readMessages"),
      description: t("onboarding.readMessagesDesc"),
      tab: "Inbox",
      icon: <Mail className="w-4 h-4" />,
    },
  ];
  const completedSteps = onboardingState.completedSteps;

  const hasMomentum = roster.length > 0 && (hotPlayers.length > 0 || coldPlayers.length > 0);

  return (
    <div className="flex flex-col gap-5">
      {myTeam && isPreseason && (
        <HomeSeasonStatusCard
          phase={seasonContext.phase}
          seasonStartLabel={seasonStartLabel}
          daysUntilSeasonStart={seasonContext.days_until_season_start}
          transferWindowStatus={transferWindow.status}
          transferWindowVariant={transferWindowVariant}
          transferWindowSummary={transferWindowSummary}
          transferWindowOpensOn={transferWindow.opens_on}
          transferWindowClosesOn={transferWindow.closes_on}
          lang={lang}
        />
      )}

      {/* Onboarding — Getting Started Checklist */}
      {myTeam && onboardingState.showOnboarding && completedSteps < onboardingSteps.length && (
        <HomeOnboardingChecklistCard
          completedSteps={completedSteps}
          totalSteps={onboardingSteps.length}
          steps={onboardingSteps}
          onNavigate={onNavigate}
        />
      )}

      {myTeam ? (
        <>
          {/* Row 1: Next Match (3/4) + League Position (1/4) */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            <Card accent="primary" className="md:col-span-2 lg:col-span-3">
              <CardHeader>{t("home.nextMatch")}</CardHeader>
              <CardBody>
                <NextMatchDisplay gameState={gameState} />
              </CardBody>
            </Card>

            <HomeLeaguePositionCard
              isPreseason={isPreseason}
              phase={seasonContext.phase}
              seasonStartLabel={seasonStartLabel}
              myStanding={myStanding}
              myStandingData={myStandingData}
              teamForm={myTeam?.form ?? []}
              onNavigate={onNavigate}
            />
          </div>

          {/* Row 2: Four secondary cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            <HomeNextOpponentCard nextOpponent={nextOpponent} lang={lang} onNavigate={onNavigate} />
            <HomeSquadOverviewCard
              avgCondition={avgCondition}
              avgConditionTone={avgConditionTone}
              avgOvr={avgOvr}
              exhaustedCount={exhaustedCount}
              scheduleIcon={schedIcons.icon}
              scheduleColorClass={schedIcons.color}
              scheduleLabel={schedLabel}
              focus={focus}
              onNavigate={onNavigate}
            />
            <HomeRecentResultsCard
              recentResults={recentResults}
              teams={gameState.teams}
              onNavigate={onNavigate}
            />
            <HomeLatestNewsCard
              articles={latestNews}
              teams={gameState.teams}
              lang={lang}
              onNavigate={onNavigate}
            />
          </div>

          {onGameUpdate && (
            <JobOpportunitiesCard gameState={gameState} onGameUpdate={onGameUpdate} hideWhenEmpty />
          )}

          {/* Board Objectives */}
          {boardObjectives.length > 0 && (
            <Card>
              <CardHeader>{t("home.boardObjectives")}</CardHeader>
              <CardBody>
                <div className="flex flex-col gap-2.5">
                  {boardObjectives.map((obj) => (
                    <div key={obj.id} className="flex items-center gap-3">
                      {obj.met ? (
                        <CheckCircle2 className="w-4 h-4 text-positive flex-shrink-0" />
                      ) : (
                        <Circle className="w-4 h-4 text-fg-subtle flex-shrink-0" />
                      )}
                      <span
                        className={`text-body ${obj.met ? "text-positive line-through" : "text-fg"}`}
                      >
                        {obj.description}
                      </span>
                      <Badge
                        variant={obj.met ? "success" : "neutral"}
                        size="sm"
                        className="ml-auto"
                      >
                        {obj.met ? t("home.met") : t("home.inProgress")}
                      </Badge>
                    </div>
                  ))}
                </div>
                <div className="mt-3 pt-2 border-t border-line">
                  <p className="text-caption text-fg-subtle">
                    {t("home.objectivesMet", {
                      done: boardObjectives.filter((o) => o.met).length,
                      total: boardObjectives.length,
                      pct: gameState.manager.satisfaction,
                    })}
                  </p>
                </div>
              </CardBody>
            </Card>
          )}

          <HomeUnavailablePlayersCard
            players={unavailablePlayers}
            resolveInjuryName={resolveInjuryName}
            onNavigate={onNavigate}
          />

          {/* Row 3: League Digest + Player Momentum */}
          <div className={`grid grid-cols-1 gap-5 ${hasMomentum ? "md:grid-cols-2" : ""}`}>
            <HomeLeagueDigestCard
              articles={leagueDigestArticles}
              lang={lang}
              onNavigate={onNavigate}
            />
            {hasMomentum && (
              <HomePlayerMomentumCard
                hotPlayers={hotPlayers}
                coldPlayers={coldPlayers}
                onNavigate={onNavigate}
              />
            )}
          </div>
        </>
      ) : (
        <>
          <HomeLeaguePositionCard
            isPreseason={isPreseason}
            phase={seasonContext.phase}
            seasonStartLabel={seasonStartLabel}
            myStanding={myStanding}
            myStandingData={myStandingData}
            teamForm={[]}
            onNavigate={onNavigate}
          />
          {onGameUpdate && (
            <JobOpportunitiesCard gameState={gameState} onGameUpdate={onGameUpdate} />
          )}
        </>
      )}

      <HomeRecentMessagesCard messages={recentMessages} lang={lang} onNavigate={onNavigate} />
    </div>
  );
}
