import { render, screen, waitFor } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

import HomeTab from "./HomeTab";
import type {
  FixtureData,
  GameStateData,
  NewsArticle,
  PlayerData,
  TeamData,
} from "../../store/gameStore";
import {
  createConditionStatus,
  createSeasonContext,
  createSquadFitness,
} from "../../test-utils/factories";

const squadMocks = vi.hoisted(() => ({
  getSquad: vi.fn().mockResolvedValue([]),
  getSquadFitness: vi.fn().mockResolvedValue(null),
}));
vi.mock("../../services/squadService", () => ({
  getSquad: squadMocks.getSquad,
  getSquadFitness: squadMocks.getSquadFitness,
}));

const backendI18nMocks = vi.hoisted(() => ({
  resolveBoardObjective: vi.fn((value: unknown) => value),
  resolveMessage: vi.fn((value: unknown) => value),
  resolveNewsArticle: vi.fn((value: unknown) => value),
}));

vi.mock("../NextMatchDisplay", () => ({
  default: () => <div data-testid="next-match-display" />,
}));

vi.mock("./HomeSquadOverviewCard", () => ({
  default: ({
    avgCondition,
    avgConditionTone,
    avgOvr,
    exhaustedCount,
  }: {
    avgCondition: number;
    avgConditionTone: string | null;
    avgOvr: number;
    exhaustedCount: number;
  }) => (
    <div data-testid="home-squad-overview">
      {`${avgCondition}|${avgOvr}|${exhaustedCount}|tone:${avgConditionTone}`}
    </div>
  ),
}));

vi.mock("./HomeUnavailablePlayersCard", () => ({
  default: ({ players }: { players: Array<{ full_name: string }> }) => (
    <div data-testid="home-unavailable-players">
      {players.map((player) => player.full_name).join(",")}
    </div>
  ),
}));

vi.mock("../../utils/backendI18n", () => ({
  resolveBoardObjective: backendI18nMocks.resolveBoardObjective,
  resolveMessage: backendI18nMocks.resolveMessage,
  resolveNewsArticle: backendI18nMocks.resolveNewsArticle,
}));

vi.mock("react-i18next", () => ({
  useTranslation: () => ({
    i18n: { language: "en" },
    t: (key: string, params?: Record<string, string | number>) => {
      if (key === "home.nextOpponent") return "Next Opponent";
      if (key === "home.noUpcomingOpponent") return "No upcoming league fixture.";
      if (key === "home.leagueDigest") return "League Digest";
      if (key === "home.noLeagueDigest") return "No league digest yet.";
      if (key === "dashboard.news") return "News";
      if (key === "dashboard.schedule") return "Schedule";
      if (key === "common.matchday") return `Matchday ${params?.n}`;
      if (key === "season.friendly") return "Friendly";
      if (key === "home.home") return "Home";
      if (key === "home.away") return "Away";
      if (key === "home.pointsShort") return `${params?.points} pts`;
      if (key === "news.categories.LeagueRoundup") return "League Roundup";
      if (key === "news.categories.StandingsUpdate") return "Standings";
      return key;
    },
  }),
}));

function createTeam(overrides: Partial<TeamData> = {}): TeamData {
  return {
    id: "team-1",
    name: "Alpha FC",
    short_name: "ALP",
    country: "BR",
    city: "Rio",
    stadium_name: "Alpha Arena",
    stadium_capacity: 50000,
    finance: 0,
    manager_id: "manager-1",
    reputation: 50,
    wage_budget: 0,
    transfer_budget: 0,
    season_income: 0,
    season_expenses: 0,
    formation: "4-4-2",
    play_style: "Balanced",
    training_focus: "Physical",
    training_intensity: "Medium",
    training_schedule: "Balanced",
    founded_year: 1900,
    colors: {
      primary: "#111111",
      secondary: "#ffffff",
    },
    starting_xi_ids: [],
    match_roles: {
      captain: null,
      vice_captain: null,
      penalty_taker: null,
      free_kick_taker: null,
      corner_taker: null,
    },
    form: [],
    history: [],
    ...overrides,
  };
}

function createPlayer(overrides: Partial<PlayerData> = {}): PlayerData {
  return {
    id: "player-1",
    match_name: "J. Smith",
    full_name: "John Smith",
    date_of_birth: "2000-01-01",
    nationality: "BR",
    position: "Forward",
    natural_position: "Forward",
    alternate_positions: [],
    training_focus: null,
    attributes: {
      pace: 10,
      stamina: 10,
      strength: 10,
      agility: 10,
      passing: 10,
      shooting: 10,
      tackling: 10,
      dribbling: 10,
      defending: 10,
      positioning: 10,
      vision: 10,
      decisions: 10,
      composure: 10,
      aggression: 10,
      teamwork: 10,
      leadership: 10,
      handling: 10,
      reflexes: 10,
      aerial: 10,
    },
    condition: 80,
    morale: 80,
    injury: null,
    team_id: "team-1",
    retired: false,
    contract_end: null,
    wage: 0,
    market_value: 0,
    stats: {
      appearances: 0,
      goals: 0,
      assists: 0,
      clean_sheets: 0,
      yellow_cards: 0,
      red_cards: 0,
      avg_rating: 0,
      minutes_played: 0,
    },
    career: [],
    transfer_listed: false,
    loan_listed: false,
    transfer_offers: [],
    traits: [],
    ovr: 1,
    ...overrides,
  };
}

function createFixture(overrides: Partial<FixtureData> = {}): FixtureData {
  return {
    competitive: true,
    advancing_team_id: null,
    id: "fixture-1",
    matchday: 2,
    date: "2025-01-12",
    home_team_id: "team-1",
    away_team_id: "team-2",
    competition: "League",
    status: "Scheduled",
    result: null,
    ...overrides,
  };
}

function createNewsArticle(overrides: Partial<NewsArticle> = {}): NewsArticle {
  return {
    id: "news-1",
    headline: "Headline",
    body: "Body",
    source: "OpenFoot Times",
    date: "2025-01-10",
    category: "LeagueRoundup",
    team_ids: [],
    player_ids: [],
    match_score: null,
    read: false,
    ...overrides,
  };
}

function createGameState(overrides: Partial<GameStateData> = {}): GameStateData {
  return {
    season_context: createSeasonContext(),
    clock: {
      current_date: "2025-01-20T00:00:00Z",
      start_date: "2025-01-01T00:00:00Z",
    },
    manager: {
      display_name: "Jane Doe",
      id: "manager-1",
      first_name: "Jane",
      last_name: "Doe",
      date_of_birth: "1980-01-01",
      nationality: "BR",
      reputation: 50,
      satisfaction: 50,
      fan_approval: 50,
      team_id: "team-1",
      career_stats: {
        matches_managed: 0,
        wins: 0,
        draws: 0,
        losses: 0,
        trophies: 0,
        best_finish: null,
      },
      career_history: [],
    },
    teams: [
      createTeam(),
      createTeam({
        id: "team-2",
        name: "Beta FC",
        short_name: "BET",
        form: ["W", "D", "W"],
      }),
    ],
    players: [createPlayer()],
    staff: [],
    messages: [],
    news: [],
    league: {
      id: "league-1",
      name: "League",
      season: 1,
      fixtures: [createFixture()],
      standings: [
        {
          team_id: "team-2",
          played: 1,
          won: 1,
          drawn: 0,
          lost: 0,
          goals_for: 2,
          goals_against: 0,
          points: 3,
        },
        {
          team_id: "team-1",
          played: 1,
          won: 0,
          drawn: 0,
          lost: 1,
          goals_for: 0,
          goals_against: 2,
          points: 0,
        },
      ],
    },
    scouting_assignments: [],
    board_objectives: [],
    ...overrides,
  };
}

describe("HomeTab", (): void => {
  it("resolves latest news articles before rendering the home widget", (): void => {
    backendI18nMocks.resolveNewsArticle.mockImplementationOnce((value: unknown) => ({
      ...(value as NewsArticle),
      headline: "Resolved headline",
      source: "Resolved source",
    }));

    render(
      <HomeTab
        gameState={createGameState({
          news: [
            createNewsArticle({
              id: "news-resolve-1",
              headline: "Fallback headline",
              source: "Fallback source",
              category: "SeasonPreview",
              date: "2025-01-16",
            }),
          ],
        })}
        visitedOnboardingTabs={new Set<string>()}
      />,
    );

    expect(backendI18nMocks.resolveNewsArticle).toHaveBeenNthCalledWith(
      1,
      expect.objectContaining({ id: "news-resolve-1" }),
      0,
      expect.any(Array),
    );
    expect(screen.getByText("Resolved headline")).toBeInTheDocument();
    expect(screen.getByText(/Resolved source/)).toBeInTheDocument();
  });

  it("renders the next opponent and league digest widgets when data is available", (): void => {
    render(
      <HomeTab
        gameState={createGameState({
          news: [
            createNewsArticle({
              id: "digest-1",
              headline: "Standings headline",
              category: "StandingsUpdate",
              date: "2025-01-15",
            }),
          ],
        })}
        visitedOnboardingTabs={new Set<string>()}
      />,
    );

    expect(screen.getByText("Next Opponent")).toBeInTheDocument();
    expect(screen.getByText("Beta FC")).toBeInTheDocument();
    expect(screen.getByText("League Digest")).toBeInTheDocument();
    expect(screen.getAllByText("Standings headline").length).toBeGreaterThan(0);
  });

  it("renders widget empty states when opponent and digest data are unavailable", (): void => {
    render(
      <HomeTab
        gameState={createGameState({
          league: {
            id: "league-1",
            name: "League",
            season: 1,
            fixtures: [],
            standings: [],
          },
          news: [],
        })}
        visitedOnboardingTabs={new Set<string>()}
      />,
    );

    expect(screen.getByText("No upcoming league fixture.")).toBeInTheDocument();
    expect(screen.getByText("No league digest yet.")).toBeInTheDocument();
  });

  // Given the backend's fitness summary for the squad (45 on average, four exhausted of whom one
  //       is critical)
  // When Home shows the squad overview
  // Then it shows those figures: the average and the exhausted count (four, not the one critical)
  //      are the backend's, not a sum the screen makes over the players it holds.
  it("shows the squad fitness the backend reports", async () => {
    squadMocks.getSquadFitness.mockResolvedValueOnce(
      createSquadFitness({ average_condition: 45, exhausted_count: 4, critical_count: 1 }),
    );
    render(<HomeTab gameState={createGameState()} visitedOnboardingTabs={new Set()} />);
    await waitFor(() => expect(screen.getByTestId("home-squad-overview")).toHaveTextContent("45|"));
    expect(screen.getByTestId("home-squad-overview")).toHaveTextContent("45|0|4");
  });

  // Given the backend's summary painting an average of 90 critical (the band rule is the
  //       backend's, the fixture contradicts the number on purpose)
  // When Home shows the squad overview
  // Then the card is given the backend's tone for the average, not one picked from 90.
  it("gives the squad overview the backend's tone for the average", async () => {
    squadMocks.getSquadFitness.mockResolvedValueOnce(
      createSquadFitness({
        average_condition: 90,
        average_status: createConditionStatus("Critical"),
      }),
    );
    render(<HomeTab gameState={createGameState()} visitedOnboardingTabs={new Set()} />);
    await waitFor(() =>
      expect(screen.getByTestId("home-squad-overview")).toHaveTextContent("90|0|0|tone:bad"),
    );
  });

  // Given the backend has not answered yet (or has no healthy first-team player to average)
  // When Home shows the squad overview
  // Then the average is absent (null), not an invented 0.
  it("has no average condition until the backend gives one", async () => {
    squadMocks.getSquadFitness.mockResolvedValueOnce(
      createSquadFitness({ players: 0, average_condition: null }),
    );
    render(<HomeTab gameState={createGameState()} visitedOnboardingTabs={new Set()} />);

    expect(screen.getByTestId("home-squad-overview")).toHaveTextContent("null|");
    await waitFor(() => expect(squadMocks.getSquadFitness).toHaveBeenCalled());
    expect(screen.getByTestId("home-squad-overview")).toHaveTextContent("null|");
  });
  it("keeps youth academy players out of first-team home summaries", async () => {
    squadMocks.getSquadFitness.mockResolvedValueOnce(
      createSquadFitness({ players: 1, average_condition: 80 }),
    );
    const players = [
      createPlayer({
        id: "senior-1",
        full_name: "Senior Starter",
        condition: 80,
        injury: {
          name: "hamstring_strain",
          days_remaining: 5,
        },
      }),
      createPlayer({
        id: "youth-1",
        full_name: "Youth Prospect",
        condition: 10,
        injury: {
          name: "ankle_sprain",
          days_remaining: 14,
        },
        squad_role: "Youth",
      }),
    ];
    squadMocks.getSquad.mockResolvedValueOnce(players);
    render(
      <HomeTab
        gameState={createGameState({ players })}
        visitedOnboardingTabs={new Set<string>()}
      />,
    );

    await waitFor(() =>
      expect(screen.getByTestId("home-squad-overview")).toHaveTextContent("80|1|0"),
    );
    expect(screen.getByTestId("home-unavailable-players")).toHaveTextContent("Senior Starter");
    expect(screen.getByTestId("home-unavailable-players")).not.toHaveTextContent("Youth Prospect");
  });

  // Regression: HomeTab sorted gameState.news and league.standings IN PLACE
  // during render — a mutation of the Zustand store's arrays that silently
  // reordered them for every other consumer.
  it("does not mutate the store's news or standings arrays when rendering", (): void => {
    const gameState = createGameState({
      news: [
        createNewsArticle({ id: "news-old", date: "2025-01-10" }),
        createNewsArticle({ id: "news-new", date: "2025-01-18" }),
      ],
      league: {
        id: "league-1",
        name: "League",
        season: 1,
        fixtures: [createFixture()],
        // Stored deliberately NOT in table order: an in-place sort would
        // move team-2 (3 pts) to the front.
        standings: [
          {
            team_id: "team-1",
            played: 1,
            won: 0,
            drawn: 0,
            lost: 1,
            goals_for: 0,
            goals_against: 2,
            points: 0,
          },
          {
            team_id: "team-2",
            played: 1,
            won: 1,
            drawn: 0,
            lost: 0,
            goals_for: 2,
            goals_against: 0,
            points: 3,
          },
        ],
      },
    });
    const newsBefore = gameState.news;
    const standingsBefore = gameState.league!.standings;
    const newsOrder = newsBefore.map((article) => article.id);
    const standingsOrder = standingsBefore.map((entry) => entry.team_id);

    render(<HomeTab gameState={gameState} visitedOnboardingTabs={new Set<string>()} />);

    expect(gameState.news).toBe(newsBefore);
    expect(gameState.news.map((article) => article.id)).toEqual(newsOrder);
    expect(gameState.league!.standings).toBe(standingsBefore);
    expect(gameState.league!.standings.map((entry) => entry.team_id)).toEqual(standingsOrder);
  });
});
