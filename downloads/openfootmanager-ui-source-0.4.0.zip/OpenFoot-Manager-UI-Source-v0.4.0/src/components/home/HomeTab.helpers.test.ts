import { describe, expect, it, beforeEach } from "vitest";
import i18n, { i18nReady } from "../../i18n";

import type {
  FixtureData,
  GameStateData,
  MessageData,
  NewsArticle,
  PlayerData,
  TeamData,
} from "../../store/gameStore";
import {
  getHomeRosterOverview,
  getLeagueDigestArticles,
  getNextOpponentWidgetData,
  getOnboardingCompletionState,
  getRecentResultsForTeam,
  loadVisitedOnboardingTabs,
  saveVisitedOnboardingTabs,
} from "./HomeTab.helpers";
import { createSeasonContext } from "../../test-utils/factories";

beforeEach((): void => {
  localStorage.clear();
});

function createTeam(overrides: Partial<TeamData> = {}): TeamData {
  return {
    id: "team-1",
    name: "Alpha FC",
    short_name: "ALP",
    country: "BR",
    city: "Rio",
    stadium_name: "Alpha Arena",
    stadium_capacity: 50000,
    finance: 0,
    manager_id: "manager-1",
    reputation: 50,
    wage_budget: 0,
    transfer_budget: 0,
    season_income: 0,
    season_expenses: 0,
    formation: "4-4-2",
    play_style: "Balanced",
    training_focus: "Physical",
    training_intensity: "Medium",
    training_schedule: "Balanced",
    founded_year: 1900,
    colors: {
      primary: "#111111",
      secondary: "#ffffff",
    },
    starting_xi_ids: [],
    form: [],
    history: [],
    ...overrides,
  };
}

function createFixture(overrides: Partial<FixtureData> = {}): FixtureData {
  return {
    competitive: true,
    advancing_team_id: null,
    id: "fixture-1",
    matchday: 1,
    date: "2025-01-10",
    home_team_id: "team-1",
    away_team_id: "team-2",
    competition: "League",
    status: "Scheduled",
    result: null,
    ...overrides,
  };
}

function createNewsArticle(overrides: Partial<NewsArticle> = {}): NewsArticle {
  return {
    id: "news-1",
    headline: "Headline",
    body: "Body",
    source: "OpenFoot Times",
    date: "2025-01-10",
    category: "LeagueRoundup",
    team_ids: [],
    player_ids: [],
    match_score: null,
    read: false,
    ...overrides,
  };
}

function createPlayer(overrides: Partial<PlayerData> = {}): PlayerData {
  return {
    id: "player-1",
    match_name: "J. Smith",
    full_name: "John Smith",
    date_of_birth: "2000-01-01",
    nationality: "BR",
    position: "Forward",
    natural_position: "Forward",
    alternate_positions: [],
    training_focus: null,
    attributes: {
      pace: 10,
      stamina: 10,
      strength: 10,
      agility: 10,
      passing: 10,
      shooting: 10,
      tackling: 10,
      dribbling: 10,
      defending: 10,
      positioning: 10,
      vision: 10,
      decisions: 10,
      composure: 10,
      aggression: 10,
      teamwork: 10,
      leadership: 10,
      handling: 10,
      reflexes: 10,
      aerial: 10,
    },
    condition: 80,
    morale: 80,
    injury: null,
    team_id: "team-1",
    retired: false,
    contract_end: null,
    wage: 0,
    market_value: 0,
    stats: {
      appearances: 0,
      goals: 0,
      assists: 0,
      clean_sheets: 0,
      yellow_cards: 0,
      red_cards: 0,
      avg_rating: 0,
      minutes_played: 0,
    },
    career: [],
    transfer_listed: false,
    loan_listed: false,
    transfer_offers: [],
    traits: [],
    ...overrides,
  };
}

function createMessage(overrides: Partial<MessageData> = {}): MessageData {
  return {
    id: "message-1",
    subject: "Subject",
    body: "Body",
    sender: "Sender",
    sender_role: "Role",
    date: "2025-01-10",
    read: false,
    category: "System",
    priority: "Normal",
    actions: [],
    context: {
      team_id: null,
      player_id: null,
      fixture_id: null,
      match_result: null,
    },
    ...overrides,
  };
}

function createGameState(overrides: Partial<GameStateData> = {}): GameStateData {
  return {
    season_context: createSeasonContext(),
    clock: {
      current_date: "2025-01-03T00:00:00Z",
      start_date: "2025-01-01T00:00:00Z",
    },
    manager: {
      display_name: "Jane Doe",
      id: "manager-1",
      first_name: "Jane",
      last_name: "Doe",
      date_of_birth: "1980-01-01",
      nationality: "BR",
      reputation: 50,
      satisfaction: 50,
      fan_approval: 50,
      team_id: "team-1",
      career_stats: {
        matches_managed: 0,
        wins: 0,
        draws: 0,
        losses: 0,
        trophies: 0,
        best_finish: null,
      },
      career_history: [],
    },
    teams: [createTeam()],
    players: [createPlayer()],
    staff: [],
    messages: [],
    news: [],
    league: {
      id: "league-1",
      name: "League",
      season: 1,
      fixtures: [],
      standings: [],
    },
    scouting_assignments: [],
    board_objectives: [],
    ...overrides,
  };
}

// What the backend sends on 3 January 2025 for a season that started on the 1st: in season, and the
// window (30 days either side of the start) still open.
const inSeasonOnThe3rdOfJanuary = createSeasonContext({
  phase: "InSeason",
  season_start: "2025-01-01",
  season_end: "2025-05-01",
  transfer_window: {
    status: "Open",
    opens_on: "2024-12-02",
    closes_on: "2025-01-31",
    days_until_opens: null,
    days_remaining: 28,
  },
});

describe("HomeTab.helpers", (): void => {
  it("derives the next opponent widget data from the next scheduled fixture", (): void => {
    const gameState = createGameState({
      season_context: inSeasonOnThe3rdOfJanuary,
      teams: [
        createTeam(),
        createTeam({
          id: "team-2",
          name: "Beta FC",
          short_name: "BET",
          form: ["W", "D", "W"],
        }),
      ],
      league: {
        id: "league-1",
        name: "League",
        season: 1,
        fixtures: [
          createFixture({
            id: "fixture-completed",
            date: "2025-01-05",
            matchday: 1,
            status: "Completed",
            result: {
              home_goals: 1,
              away_goals: 0,
              home_scorers: [],
              away_scorers: [],
            },
          }),
          createFixture({
            id: "fixture-next",
            date: "2025-01-12",
            matchday: 2,
            status: "Scheduled",
          }),
        ],
        standings: [
          {
            team_id: "team-2",
            played: 1,
            won: 1,
            drawn: 0,
            lost: 0,
            goals_for: 2,
            goals_against: 0,
            points: 3,
          },
          {
            team_id: "team-1",
            played: 1,
            won: 0,
            drawn: 0,
            lost: 1,
            goals_for: 0,
            goals_against: 2,
            points: 0,
          },
        ],
      },
    });

    const result = getNextOpponentWidgetData(gameState, i18n.getFixedT("en"));

    expect(result).not.toBeNull();
    expect(result?.fixture.id).toBe("fixture-next");
    expect(result?.opponent.name).toBe("Beta FC");
    expect(result?.isHome).toBe(true);
    expect(result?.standingPosition).toBe(1);
    expect(result?.standingPoints).toBe(3);
    expect(result?.recentForm).toEqual(["W", "D", "W"]);
  });

  it("derives the next opponent from the user's competition when game.league is a stale all-teams league", (): void => {
    const gameState = createGameState({
      season_context: inSeasonOnThe3rdOfJanuary,
      teams: [
        createTeam(),
        createTeam({
          id: "team-2",
          name: "Beta FC",
          short_name: "BET",
          form: ["W", "D", "W"],
        }),
      ],
      active_competition_ids: ["comp-domestic"],
      competitions: [
        {
          id: "comp-domestic",
          name: "Brazil First Division",
          kind: "League",
          scope: "Domestic",
          season: 1,
          participant_ids: ["team-1", "team-2"],
          fixtures: [
            createFixture({
              id: "comp-fixture-next",
              date: "2025-01-12",
              matchday: 2,
              status: "Scheduled",
            }),
          ],
          standings: [
            {
              team_id: "team-2",
              played: 1,
              won: 1,
              drawn: 0,
              lost: 0,
              goals_for: 2,
              goals_against: 0,
              points: 3,
            },
            {
              team_id: "team-1",
              played: 1,
              won: 0,
              drawn: 0,
              lost: 1,
              goals_for: 0,
              goals_against: 2,
              points: 0,
            },
          ],
        },
      ],
      // Stale legacy league spanning the whole world — should be ignored.
      league: {
        id: "stale-world-league",
        name: "Stale World League",
        season: 1,
        fixtures: [
          createFixture({
            id: "stale-fixture",
            date: "2025-01-04",
            matchday: 1,
            away_team_id: "team-999",
            status: "Scheduled",
          }),
        ],
        standings: [],
      },
    });

    const result = getNextOpponentWidgetData(gameState, i18n.getFixedT("en"));

    expect(result).not.toBeNull();
    expect(result?.fixture.id).toBe("comp-fixture-next");
    expect(result?.opponent.name).toBe("Beta FC");
    expect(result?.isHome).toBe(true);
    expect(result?.standingPosition).toBe(1);
    expect(result?.standingPoints).toBe(3);
  });

  it("names the competition of a next fixture that is a cup tie", (): void => {
    const gameState = createGameState({
      teams: [createTeam(), createTeam({ id: "team-2", name: "Beta FC", short_name: "BET" })],
      competitions: [
        {
          id: "comp-cup",
          name: "Brazil Cup",
          kind: "Cup",
          scope: "Domestic",
          season: 1,
          participant_ids: ["team-1", "team-2"],
          fixtures: [
            createFixture({
              id: "cup-tie",
              competition_id: "comp-cup",
              competition: "Cup",
              status: "Scheduled",
            }),
          ],
          standings: [],
        },
      ],
    });

    const result = getNextOpponentWidgetData(gameState, i18n.getFixedT("en"));

    expect(result?.fixture.id).toBe("cup-tie");
    expect(result?.competitionName).toBe("Brazil Cup");
  });

  it("localizes the next opponent's competition when it has a name key", async () => {
    await i18nReady;
    await i18n.loadLanguages("pt-BR");
    const gameState = createGameState({
      teams: [createTeam(), createTeam({ id: "team-2", name: "Beta FC", short_name: "BET" })],
      competitions: [
        {
          id: "world-cup-2026",
          name: "2026 World Cup",
          name_key: "tournaments.competitions.worldCup",
          season: 2026,
          participant_ids: ["team-1", "team-2"],
          fixtures: [
            createFixture({
              competition_id: "world-cup-2026",
              competition: "InternationalNation",
            }),
          ],
          standings: [],
        },
      ],
    });

    const result = getNextOpponentWidgetData(gameState, i18n.getFixedT("pt-BR"));

    expect(result?.competitionName).toBe("Copa do Mundo 2026");
  });

  it("returns the latest league digest articles in reverse chronological order", (): void => {
    const gameState = createGameState({
      news: [
        createNewsArticle({
          id: "generic-news",
          category: "TransferRumour",
          date: "2025-01-12",
        }),
        createNewsArticle({
          id: "roundup-news",
          category: "LeagueRoundup",
          date: "2025-01-14",
        }),
        createNewsArticle({
          id: "standings-news",
          category: "StandingsUpdate",
          date: "2025-01-15",
        }),
      ],
    });

    const result = getLeagueDigestArticles(gameState);

    expect(result.map((article) => article.id)).toEqual(["standings-news", "roundup-news"]);
  });

  it("builds roster overview metrics, unavailable players, and momentum groups", (): void => {
    const roster = [
      createPlayer({
        id: "player-hot",
        full_name: "Hot Player",
        morale: 90,
        condition: 88,
        ovr: 72,
      }),
      createPlayer({
        id: "player-cold",
        full_name: "Cold Player",
        morale: 35,
        condition: 32,
        ovr: 58,
      }),
      createPlayer({
        id: "player-injured",
        full_name: "Injured Player",
        morale: 75,
        condition: 64,
        ovr: 64,
        injury: {
          name: "Hamstring",
          days_remaining: 14,
        },
      }),
    ];

    const result = getHomeRosterOverview(roster);

    // (72 + 58 + 64) / 3 = 64.67, rounded down as the clubs directory and the team profile do.
    expect(result.avgOvr).toBe(64);
    expect(result.unavailablePlayers.map((player) => player.id)).toEqual(["player-injured"]);
    expect(result.hotPlayers.map((player) => player.id)).toEqual(["player-hot"]);
    expect(result.coldPlayers.map((player) => player.id)).toEqual(["player-cold"]);
  });

  it("returns the latest completed results for the managed team", (): void => {
    const gameState = createGameState({
      teams: [
        createTeam(),
        createTeam({ id: "team-2", name: "Beta FC" }),
        createTeam({ id: "team-3", name: "Gamma FC" }),
      ],
      league: {
        id: "league-1",
        name: "League",
        season: 1,
        standings: [],
        fixtures: [
          createFixture({
            id: "fixture-1",
            date: "2025-01-05",
            status: "Completed",
            result: {
              home_goals: 2,
              away_goals: 1,
              home_scorers: [],
              away_scorers: [],
            },
          }),
          createFixture({
            id: "fixture-2",
            date: "2025-01-08",
            home_team_id: "team-3",
            away_team_id: "team-1",
            status: "Completed",
            result: {
              home_goals: 0,
              away_goals: 0,
              home_scorers: [],
              away_scorers: [],
            },
          }),
          createFixture({
            id: "fixture-3",
            date: "2025-01-10",
            status: "Scheduled",
          }),
        ],
      },
    });

    const result = getRecentResultsForTeam(gameState, "team-1");

    expect(result.map((entry) => entry.fixture.id)).toEqual(["fixture-1", "fixture-2"]);
    expect(result[0]).toMatchObject({
      isHome: true,
      myGoals: 2,
      opponentGoals: 1,
      opponentId: "team-2",
      resultCode: "W",
    });
    expect(result[1]).toMatchObject({
      isHome: false,
      myGoals: 0,
      opponentGoals: 0,
      opponentId: "team-3",
      resultCode: "D",
    });
  });

  it("reads recent results from the user's competitions, ignoring a stale league", (): void => {
    const gameState = createGameState({
      teams: [createTeam(), createTeam({ id: "team-2", name: "Beta FC" })],
      active_competition_ids: ["comp-domestic"],
      competitions: [
        {
          id: "comp-domestic",
          name: "Brazil First Division",
          kind: "League",
          scope: "Domestic",
          season: 1,
          participant_ids: ["team-1", "team-2"],
          standings: [],
          fixtures: [
            createFixture({
              id: "comp-result",
              date: "2025-01-05",
              status: "Completed",
              result: {
                home_goals: 3,
                away_goals: 1,
                home_scorers: [],
                away_scorers: [],
              },
            }),
          ],
        },
      ],
      league: {
        id: "stale-world-league",
        name: "Stale World League",
        season: 1,
        standings: [],
        fixtures: [
          createFixture({
            id: "stale-result",
            date: "2025-01-06",
            away_team_id: "team-999",
            status: "Completed",
            result: {
              home_goals: 9,
              away_goals: 0,
              home_scorers: [],
              away_scorers: [],
            },
          }),
        ],
      },
    });

    const result = getRecentResultsForTeam(gameState, "team-1");

    expect(result.map((entry) => entry.fixture.id)).toEqual(["comp-result"]);
    expect(result[0]).toMatchObject({ myGoals: 3, opponentGoals: 1, resultCode: "W" });
  });

  it("starts with no visited onboarding pages and no read inbox step", (): void => {
    const state = getOnboardingCompletionState(createGameState(), new Set<string>());

    expect(state.hasVisitedSquadPage).toBe(false);
    expect(state.hasVisitedStaffPage).toBe(false);
    expect(state.hasVisitedTacticsPage).toBe(false);
    expect(state.hasVisitedTrainingPage).toBe(false);
    expect(state.hasReadInbox).toBe(false);
    expect(state.completedSteps).toBe(0);
  });

  it("marks visited onboarding pages as done", (): void => {
    const state = getOnboardingCompletionState(
      createGameState(),
      new Set<string>(["Squad", "Tactics"]),
    );

    expect(state.hasVisitedSquadPage).toBe(true);
    expect(state.hasVisitedTacticsPage).toBe(true);
    expect(state.hasVisitedStaffPage).toBe(false);
    expect(state.hasVisitedTrainingPage).toBe(false);
    expect(state.completedSteps).toBe(2);
  });

  it("marks inbox complete after at least one message is read", (): void => {
    const gameState = createGameState({
      messages: [
        createMessage({
          id: "message-1",
          read: true,
        }),
        createMessage({
          id: "message-2",
          category: "System",
          read: false,
        }),
      ],
    });

    const state = getOnboardingCompletionState(gameState, new Set<string>());

    expect(state.hasReadInbox).toBe(true);
  });

  it("counts page visits together with the inbox step", (): void => {
    const gameState = createGameState({
      messages: [
        createMessage({
          id: "message-1",
          read: true,
        }),
      ],
    });
    const state = getOnboardingCompletionState(
      gameState,
      new Set<string>(["Squad", "Staff", "Training"]),
    );

    expect(state.completedSteps).toBe(4);
  });

  it("hides onboarding after the first week", (): void => {
    const gameState = createGameState({
      clock: {
        current_date: "2025-01-10T00:00:00Z",
        start_date: "2025-01-01T00:00:00Z",
      },
    });

    const state = getOnboardingCompletionState(gameState, new Set<string>());

    expect(state.showOnboarding).toBe(false);
  });

  it("persists visited onboarding tabs per save", (): void => {
    const gameState = createGameState();
    const otherGameState = createGameState({
      clock: {
        current_date: "2025-02-03T00:00:00Z",
        start_date: "2025-02-01T00:00:00Z",
      },
      manager: {
        ...createGameState().manager,
        id: "manager-2",
      },
    });

    saveVisitedOnboardingTabs(gameState, new Set<string>(["Squad", "Training"]), localStorage);

    expect(Array.from(loadVisitedOnboardingTabs(gameState, localStorage))).toEqual([
      "Squad",
      "Training",
    ]);
    expect(Array.from(loadVisitedOnboardingTabs(otherGameState, localStorage))).toEqual([]);
  });

  it("isolates visited onboarding tabs by active save id", (): void => {
    const gameState = createGameState();

    saveVisitedOnboardingTabs(
      gameState,
      new Set<string>(["Squad", "Training"]),
      localStorage,
      "save-a",
    );

    expect(Array.from(loadVisitedOnboardingTabs(gameState, localStorage, "save-a"))).toEqual([
      "Squad",
      "Training",
    ]);
    expect(Array.from(loadVisitedOnboardingTabs(gameState, localStorage, "save-b"))).toEqual([]);
  });

  it("keeps onboarding completed after reloading persisted progress", (): void => {
    const gameState = createGameState({
      messages: [
        createMessage({
          id: "message-1",
          read: true,
        }),
      ],
    });

    saveVisitedOnboardingTabs(
      gameState,
      new Set<string>(["Squad", "Staff", "Tactics", "Training"]),
      localStorage,
    );

    const reloadedVisitedTabs = loadVisitedOnboardingTabs(gameState, localStorage);
    const state = getOnboardingCompletionState(gameState, reloadedVisitedTabs);

    expect(state.hasVisitedSquadPage).toBe(true);
    expect(state.hasVisitedStaffPage).toBe(true);
    expect(state.hasVisitedTacticsPage).toBe(true);
    expect(state.hasVisitedTrainingPage).toBe(true);
    expect(state.hasReadInbox).toBe(true);
    expect(state.completedSteps).toBe(5);
  });
});
