import type { TFunction } from "i18next";
import { useTranslation } from "react-i18next";

import TournamentsFixtureRow from "./TournamentsFixtureRow";
import type { TournamentsTeamLookup } from "./teamLookup";
import { formatMatchDate } from "../../lib/helpers";
import { Card, CardBody } from "../ui";
import type { FixtureData } from "../../store/gameStore";

interface TournamentsFixturesViewProps {
  /** Matchdays in playing order, each with its fixtures. */
  sortedMatchdays: Array<[number, FixtureData[]]>;
  teams: TournamentsTeamLookup;
}

/** One date, or the first and last when a round was postponed in part. */
function playedDates(fixtures: FixtureData[], t: TFunction): string {
  const dates = fixtures.map((fixture) => fixture.date).sort();
  const first = dates[0];
  const last = dates[dates.length - 1];
  return first === last
    ? formatMatchDate(first)
    : t("schedule.dateRange", { from: formatMatchDate(first), to: formatMatchDate(last) });
}

/** The competition's fixture list, one card per matchday. */
export default function TournamentsFixturesView({
  sortedMatchdays,
  teams,
}: TournamentsFixturesViewProps) {
  const { t } = useTranslation();

  return (
    <div className="flex flex-col gap-4">
      {sortedMatchdays.map(([matchday, fixtures]) => (
        <Card key={matchday}>
          <div className="px-5 py-3 border-b border-line bg-sunken rounded-t-xl">
            <h4 className="font-heading font-bold text-body uppercase tracking-label text-fg-muted">
              {t("schedule.matchday", { number: matchday })} — {playedDates(fixtures, t)}
            </h4>
          </div>
          <CardBody className="p-0">
            <div className="divide-y divide-line">
              {fixtures.map((fixture) => (
                <TournamentsFixtureRow
                  key={fixture.id}
                  fixture={fixture}
                  testId={`tournaments-fixture-${fixture.id}`}
                  teams={teams}
                />
              ))}
            </div>
          </CardBody>
        </Card>
      ))}
    </div>
  );
}
