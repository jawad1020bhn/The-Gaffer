import { render, screen, within } from "@testing-library/react";
import { describe, expect, it } from "vitest";

import type { FixtureData } from "../../store/gameStore";
import KnockoutBracket from "./KnockoutBracket";

function penaltyFixture(): FixtureData {
  return {
    competitive: true,
    advancing_team_id: "away",
    id: "ko-1",
    matchday: 1,
    date: "2026-07-10",
    home_team_id: "home",
    away_team_id: "away",
    competition: "InternationalNation",
    status: "Completed",
    result: {
      home_goals: 1,
      away_goals: 1,
      home_scorers: [],
      away_scorers: [],
      home_penalties: 2,
      away_penalties: 4,
    },
  };
}

/** The goals say the home side won; the backend's answer is what the bracket follows. */
function fixtureWhoseBackendAnswerIsAway(): FixtureData {
  const fixture = penaltyFixture();
  fixture.result = { home_goals: 2, away_goals: 1, home_scorers: [], away_scorers: [] };
  return fixture;
}

function renderBracket(fixture: FixtureData) {
  return render(
    <KnockoutBracket
      rounds={[{ id: "r1", name: "Final", fixture_ids: [fixture.id], completed: true }]}
      fixtures={[fixture]}
      resolveTeamName={(id) => (id === "home" ? "Brazil" : "France")}
      localizedRoundName={(name) => name}
      roundCompleteLabel="Complete"
      roundInProgressLabel="In progress"
      byeLabel="Bye"
      tbdLabel="TBD"
    />,
  );
}

describe("KnockoutBracket penalty shootouts", () => {
  it("advances the shootout winner even though the goals are level", () => {
    renderBracket(penaltyFixture());

    const slot = screen.getByTestId("tournaments-bracket-ko-1");
    // The away side won 4-2 on penalties: its shootout tally is shown...
    expect(within(slot).getByText("(4)")).toBeInTheDocument();
    expect(within(slot).getByText("(2)")).toBeInTheDocument();
    // ...and it is actually marked as the winner — the level score must not
    // leave both rows neutral (the "wrong team advanced" regression).
    const awayRow = within(slot).getByText("France").closest("div");
    const homeRow = within(slot).getByText("Brazil").closest("div");
    expect(awayRow?.className).toContain("bg-selected-tint");
    expect(homeRow?.className).not.toContain("bg-selected-tint");
  });

  it("does not show a shootout tally when the tie was settled in normal time", () => {
    const fixture = penaltyFixture();
    fixture.advancing_team_id = "home";
    fixture.result = {
      home_goals: 2,
      away_goals: 1,
      home_scorers: [],
      away_scorers: [],
    };
    renderBracket(fixture);

    const slot = screen.getByTestId("tournaments-bracket-ko-1");
    expect(within(slot).queryByText(/\(\d+\)/)).not.toBeInTheDocument();
  });

  /**
   * Given a played tie whose goals favour the home side but for which the backend names the away side
   * When the bracket renders it
   * Then the away row is the winner: the bracket follows the backend, it does not compare scores.
   */
  it("marks the side the backend says advances, not the side with more goals", () => {
    renderBracket(fixtureWhoseBackendAnswerIsAway());

    const slot = screen.getByTestId("tournaments-bracket-ko-1");
    expect(within(slot).getByText("France").closest("div")?.className).toContain(
      "bg-selected-tint",
    );
    expect(within(slot).getByText("Brazil").closest("div")?.className).not.toContain(
      "bg-selected-tint",
    );
  });

  /**
   * Given a tie with no result yet and no answer from the backend
   * When the bracket renders it
   * Then neither row is marked.
   */
  it("marks no side before there is a result", () => {
    const fixture = penaltyFixture();
    fixture.result = null;
    fixture.advancing_team_id = null;
    renderBracket(fixture);

    const slot = screen.getByTestId("tournaments-bracket-ko-1");
    expect(within(slot).getByText("France").closest("div")?.className).not.toContain(
      "bg-selected-tint",
    );
    expect(within(slot).getByText("Brazil").closest("div")?.className).not.toContain(
      "bg-selected-tint",
    );
  });
});
