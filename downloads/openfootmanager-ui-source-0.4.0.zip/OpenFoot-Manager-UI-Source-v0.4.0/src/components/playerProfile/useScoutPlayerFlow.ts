import { useEffect, useState } from "react";

import type { GameStateData, PlayerData } from "../../store/gameStore";
import { sendScout as sendScoutRequest } from "../../services/scoutingService";
import { resolveTranslatedErrorMessage } from "../../utils/errorMessage";
import {
  getScoutAvailability,
  type PlayerProfileScoutStatus,
  type ScoutAvailability,
} from "./PlayerProfile.scouting";

interface UseScoutPlayerFlowArgs {
  player: PlayerData;
  gameState: GameStateData;
  onGameUpdate?: (game: GameStateData) => void;
}

interface UseScoutPlayerFlowResult {
  scoutAvailability: ScoutAvailability;
  scoutStatus: PlayerProfileScoutStatus;
  scoutError: string | null;
  sendScout: () => void;
}

/**
 * Sending a scout to watch this player.
 *
 * `scoutAvailability` is derived from the current status as well as the squad,
 * so the two travel together — a scout already on their way is not available
 * to send again.
 */
export function useScoutPlayerFlow({
  player,
  gameState,
  onGameUpdate,
}: UseScoutPlayerFlowArgs): UseScoutPlayerFlowResult {
  const [scoutStatus, setScoutStatus] = useState<PlayerProfileScoutStatus>("idle");
  const [scoutError, setScoutError] = useState<string | null>(null);

  // The profile is not remounted when the manager moves to another player, so
  // without this the last player's "sent" status carries over and the new
  // profile claims a scout is already watching them.
  useEffect(() => {
    setScoutStatus("idle");
    setScoutError(null);
  }, [player.id]);

  const scoutAvailability = getScoutAvailability({
    staff: gameState.staff,
    scoutingAssignments: gameState.scouting_assignments || [],
    youthScoutingAssignments: gameState.youth_scouting_assignments || [],
    managerTeamId: gameState.manager.team_id,
    playerId: player.id,
    scoutStatus,
  });

  function sendScout(): void {
    const availableScout = scoutAvailability.availableScout;
    if (!availableScout || !onGameUpdate) {
      return;
    }

    void (async () => {
      setScoutStatus("sending");
      setScoutError(null);

      try {
        const updated = await sendScoutRequest(availableScout.id, player.id);
        onGameUpdate(updated);
        setScoutStatus("sent");
      } catch (err) {
        setScoutError(resolveTranslatedErrorMessage(err));
        setScoutStatus("error");
      }
    })();
  }

  return { scoutAvailability, scoutStatus, scoutError, sendScout };
}
