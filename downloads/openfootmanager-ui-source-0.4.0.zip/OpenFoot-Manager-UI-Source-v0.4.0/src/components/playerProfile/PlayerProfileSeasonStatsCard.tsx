import type { PlayerSeasonStats } from "../../store/gameStore";
import { Card, CardBody, CardHeader } from "../ui";

type TranslateFn = (key: string) => string;

interface PlayerProfileSeasonStatsCardProps {
  stats: PlayerSeasonStats;
  seasonRatingRated: boolean;
  t: TranslateFn;
}

export default function PlayerProfileSeasonStatsCard({
  stats,
  seasonRatingRated,
  t,
}: PlayerProfileSeasonStatsCardProps) {
  return (
    <Card>
      <CardHeader>{t("playerProfile.seasonStats")}</CardHeader>
      <CardBody>
        <div className="grid grid-cols-4 md:grid-cols-8 gap-3">
          <StatBox label={t("playerProfile.apps")} value={stats.appearances} />
          <StatBox label={t("playerProfile.goals")} value={stats.goals} />
          <StatBox label={t("playerProfile.assists")} value={stats.assists} />
          <StatBox label={t("playerProfile.mins")} value={stats.minutes_played} />
          <StatBox label={t("playerProfile.cleanSheets")} value={stats.clean_sheets} />
          <StatBox label={t("playerProfile.yellows")} value={stats.yellow_cards} />
          <StatBox label={t("playerProfile.reds")} value={stats.red_cards} />
          <StatBox
            label={t("playerProfile.avgRating")}
            value={seasonRatingRated ? stats.avg_rating.toFixed(1) : "–"}
          />
        </div>
      </CardBody>
    </Card>
  );
}

function StatBox({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="text-center p-2.5 bg-sunken rounded-control">
      <p className="font-heading font-bold text-heading text-fg tabular-nums">{value}</p>
      <p className="text-caption text-fg-subtle font-heading uppercase tracking-label">{label}</p>
    </div>
  );
}
