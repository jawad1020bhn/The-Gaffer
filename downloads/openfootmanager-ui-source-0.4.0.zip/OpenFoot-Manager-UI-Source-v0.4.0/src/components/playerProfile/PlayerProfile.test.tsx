import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { useState } from "react";
import { beforeEach } from "vitest";
import { describe, expect, it, vi } from "vitest";
import { invoke } from "@tauri-apps/api/core";
import type { InvokeArgs } from "@tauri-apps/api/core";
import type { GameStateData, PlayerData, StaffData, TeamData } from "../../store/gameStore";
import type { PlayerKnowledge, VisibleWage } from "../../services/scoutingService";
import PlayerProfile from "./PlayerProfile";
import { createSeasonContext } from "../../test-utils/factories";

/**
 * The fields these mocks read out of an invoke payload. Tauri's IPC boundary is untyped by
 * nature — every command takes a different shape — so this names what is actually touched
 * rather than reaching for `any` and switching type-checking off for the whole object.
 */
type MockInvokePayload = {
  request?: { playerId?: string };
  fee?: number;
  weeklyWage?: number;
};

function hasWeeklyWage(text: string, amount: string): boolean {
  return text.replace(/\s+/g, "").includes(`€${amount}/wk`);
}

// What the backend's contract warning stages read as on a badge, by player id; a test says which
// players are at risk. The hook that asks for them has its own test.
const riskLevels = vi.hoisted(() => ({
  current: {} as Record<string, "critical" | "warning" | "stable">,
}));

vi.mock("../../hooks/useContractWarningStages", () => ({
  useContractRiskLevels: () => (playerId: string) => riskLevels.current[playerId] ?? "stable",
}));

// What the club knows about each player, by id, as the backend's knowledge rule would answer; a test
// names the rivals it shows. Everyone else reads as the club's own, which most of these tests render.
// The hook that asks for it has its own test.
// Each revision the profile hands the hook is kept, so a test can see when it would ask again.
const knowledge = vi.hoisted(() => ({
  current: {} as Record<string, PlayerKnowledge>,
  revisions: [] as string[],
}));

vi.mock("../../hooks/usePlayerKnowledge", () => ({
  usePlayerKnowledge: (_playerIds: string[], revision: string) => {
    knowledge.revisions.push(revision);
    return (playerId: string) => knowledge.current[playerId] ?? ({ kind: "own" } as const);
  },
}));

// The wage the club may see, by player id, as the backend's `visible_wage` would answer. Everyone
// else reads as the club's own player on his current wage, which the profile's revision key ends
// with, as the backend would answer after a renewal.
const wages = vi.hoisted(() => ({
  current: {} as Record<string, VisibleWage>,
  revisions: [] as string[],
}));

vi.mock("../../hooks/useVisibleWage", () => ({
  useVisibleWage: (playerId: string, revision: string) => {
    wages.revisions.push(revision);
    return {
      status: "answered" as const,
      value:
        wages.current[playerId] ??
        ({ kind: "exact", weekly: Number(JSON.parse(revision).at(-1)) } as const),
    };
  },
}));

// The club holds no opinion of anyone's potential in these tests; PlayerProfile.potential.test.tsx
// shows one, through the real hook. The hook has its own test.
vi.mock("../../hooks/usePotentialOpinion", () => ({
  usePotentialOpinion: () => ({ status: "answered", value: null }),
}));
// Nor its ratings at positions: PlayerProfilePositionRatings and usePositionRatings have their own.
vi.mock("../../hooks/usePositionRatings", () => ({
  usePositionRatings: () => ({ status: "answered", value: null }),
}));

vi.mock("@tauri-apps/api/core", () => ({
  invoke: vi.fn(),
}));

vi.mock("react-i18next", () => ({
  initReactI18next: {
    type: "3rdParty",
    init: () => {},
  },
  useTranslation: () => ({
    t: (key: string, params?: Record<string, string | number>) => {
      if (key === "common.back") return "Back";
      if (key === "common.contract") return "Contract";
      if (key === "common.renewContract") return "Renew Contract";
      if (key === "common.cancel") return "Cancel";
      if (key === "common.done") return "Done";
      if (key === "common.submit") return "Submit";
      if (key === "common.condition") return "Condition";
      if (key === "common.morale") return "Morale";
      if (key === "common.value") return "Value";
      if (key === "common.wage") return "Wage";
      if (key === "common.age") return "Age";
      if (key.startsWith("common.ordinal.")) {
        const suffixes: Record<string, string> = { one: "st", two: "nd", few: "rd", other: "th" };
        return `${params?.n}${suffixes[key.split(".")[2]] ?? "th"}`;
      }
      if (key === "common.viewTeam") return "View team";
      if (key === "common.freeAgent") return "Free Agent";
      if (key === "common.unknown") return "Unknown";
      if (key === "finances.perWeekSuffix") return "/wk";
      if (key === "finances.perYearSuffix") return "/yr";
      if (key === "finances.marketValue") return "Market Value";
      if (key === "finances.contractRiskCritical") return "Critical";
      if (key === "finances.contractRiskWarning") return "Warning";
      if (key === "finances.contractRiskStable") return "Stable";
      if (key === "finances.contractExpiresOn") return `Expires ${params?.date}`;
      if (key === "playerProfile.contractInfo") return "Contract Info";
      if (key === "playerProfile.dateOfBirth") return "Date of Birth";
      if (key === "playerProfile.weeklyWage") return "Weekly Wage";
      if (key === "playerProfile.approximateWage") return `about ${params?.wage}`;
      if (key === "playerProfile.annualWage") return "Annual Wage";
      if (key === "playerProfile.noContract") return "No Contract";
      if (key === "playerProfile.yearsRemaining") return "Years Remaining";
      if (key === "playerProfile.contractRisk") return "Contract Risk";
      if (key === "playerProfile.renewalTitle") return "Renew Contract";
      if (key === "playerProfile.renewalWage") return "Offered Wage";
      if (key === "playerProfile.renewalLength") return "Contract Length";
      if (key === "playerProfile.renewalLengthYears") return `${params?.count} years`;
      if (key === "playerProfile.renewalSubmit") return "Submit Offer";
      if (key === "playerProfile.renewalBudgetWarning") return "Exceeds wage budget";
      if (key === "playerProfile.renewalInvalidWage") return "Enter a valid weekly wage";
      if (key === "playerProfile.renewalAccepted") return "Offer accepted";
      if (key === "playerProfile.renewalRejected") return "Offer rejected";
      if (key === "playerProfile.renewalCounter")
        return `Wants more: ${params?.wage}/wk for ${params?.years} years`;
      if (key === "playerProfile.renewalBlocked")
        return "Talks are blocked after your earlier decision";
      if (key === "playerProfile.renewalCooledOff")
        return "Previous talks cooled off, so this starts as a fresh conversation.";
      if (key === "playerProfile.letContractExpire") return "Let Expire";
      if (key === "playerProfile.reopenContractTalks") return "Reopen Talks";
      if (key === "playerProfile.terminateContract") return "Terminate Now";
      if (key === "playerProfile.terminateContractTitle") return "Terminate Contract";
      if (key === "playerProfile.terminateContractBody")
        return `Release ${params?.name} immediately.`;
      if (key === "playerProfile.terminationSeverance") return "Severance";
      if (key === "playerProfile.projectedHealthyPlayers") return "Healthy players after release";
      if (key === "playerProfile.terminationUnsafe")
        return "This release would leave the squad unable to field a matchday XI.";
      if (key === "playerProfile.confirmTerminateContract") return "Terminate Contract";
      if (key === "playerProfile.delegateRenewal") return "Delegate to Assistant";
      if (key === "playerProfile.renewalDelegateMissingReport")
        return "Assistant report did not include this player.";
      if (key === "be.error.contracts.noAssistantManagerAssigned")
        return "Hire an assistant manager before delegating contract talks.";
      if (key === "be.error.contracts.playerHasNoActiveContract")
        return "This player does not have an active contract.";
      if (key === "playerProfile.renewalConversationTitle") return "Negotiation pulse";
      if (key === "playerProfile.renewalProjectionTitle") return "Projected financial impact";
      if (key === "playerProfile.renewalProjectionWageBill")
        return `Weekly wage bill ${params?.before} -> ${params?.after}`;
      if (key === "playerProfile.renewalProjectionBudgetUsage")
        return `Wage budget use ${params?.before}% -> ${params?.after}%`;
      if (key === "playerProfile.renewalProjectionRunway")
        return `Cash runway ${params?.before} -> ${params?.after}`;
      if (key === "playerProfile.renewalRound") return `Round ${params?.count}`;
      if (key === "playerProfile.renewalPatience") return "Patience";
      if (key === "playerProfile.renewalTension") return "Tension";
      if (key === "playerProfile.renewalFeedbackFirmHeadline")
        return "They want stronger terms before moving.";
      if (key === "playerProfile.renewalFeedbackFirmDetail")
        return "The discussion is still open, but wage level and contract length need to feel clearly worthwhile from their side.";
      if (key === "playerProfile.loanStatus") return "Loan Status";
      if (key === "playerProfile.loanedInFrom") return `On loan from ${params?.team}`;
      if (key === "playerProfile.loanedOutTo") return `On loan at ${params?.team}`;
      if (key === "playerProfile.loanBetweenClubs")
        return `On loan from ${params?.parent} to ${params?.loanTeam}`;
      if (key === "playerProfile.loanUntil") return `Until ${params?.date}`;
      if (key === "playerProfile.loanWageSplit")
        return `${params?.percent}% wages covered by loan club`;
      if (key === "playerProfile.loanBuyOption") return `Buy option ${params?.fee}`;
      if (key === "playerProfile.attributes") return "Attributes";
      if (key === "playerProfile.seasonStats") return "Season Stats";
      if (key === "playerProfile.advancedStats") return "Advanced Stats";
      if (key === "playerProfile.shots") return "Shots";
      if (key === "playerProfile.shotsOnTarget") return "Shots On Target";
      if (key === "playerProfile.passes") return "Passes";
      if (key === "playerProfile.tacklesWon") return "Tackles Won";
      if (key === "playerProfile.interceptions") return "Interceptions";
      if (key === "playerProfile.foulsCommitted") return "Fouls Committed";
      if (key === "playerProfile.per90") return "Per 90";
      if (key === "playerProfile.passAccuracy") return "Pass Accuracy";
      if (key === "playerProfile.percentile") return "Percentile";
      if (key === "playerProfile.percentileUnavailable") return "Percentile unavailable";
      if (key === "playerProfile.recentMatches") return "Recent Matches";
      if (key === "playerProfile.vs") return "vs";
      if (key === "playerProfile.noRecentMatches") return "No recent match data";
      if (key === "playerProfile.careerHistory") return "Career History";
      if (key === "playerProfile.noCareer") return "No Career";
      if (key === "playerProfile.movementHistory") return "Movement History";
      if (key === "playerProfile.noMovementHistory") return "No movement history";
      if (key === "playerProfile.movementPermanentTransfer") return "Transfer";
      if (key === "playerProfile.movementLoanStart") return "Loan";
      if (key === "playerProfile.movementLoanReturn") return "Loan return";
      if (key === "playerProfile.movementLoanToBuy") return "Loan-to-buy";
      if (key === "playerProfile.movementFreeAgentSigning") return "Free agent";
      if (key === "playerProfile.movementReleased") return "Released";
      if (key === "playerProfile.movementFromTo") return `${params?.from} -> ${params?.to}`;
      if (key === "playerProfile.movementTo") return `Joined ${params?.to}`;
      if (key === "playerProfile.movementFrom") return `Left ${params?.from}`;
      if (key === "playerProfile.movementFee") return `Fee ${params?.fee}`;
      if (key === "playerProfile.movementLoanUntil") return `Loan until ${params?.date}`;
      if (key === "scouting.noScoutsHint") return "Hire a scout first";
      if (key === "scouting.scoutingInProgress") return "Scouting in progress";
      if (key === "scouting.scoutBtn") return "Scout";
      if (key === "finances.wagePerWeek") return "Wage/wk";
      if (key === "transfers.offerContract") return "Offer Contract";
      if (key === "transfers.close") return "Close";
      if (key === "transfers.submitting") return "Submitting...";
      if (key === "transfers.playerValue") return `Value: ${params?.value}`;
      return key;
    },
    i18n: { language: "en" },
  }),
}));

vi.mock("../../utils/backendI18n", () => ({
  resolveBackendText: (_key?: string, fallback?: string, _params?: Record<string, string>) =>
    fallback ?? "",
  // The banners' one resolver; this file's own texts for the keys it provokes.
  resolveBackendError: (error: unknown) => {
    const message = error instanceof Error ? error.message : String(error);
    if (message === "be.error.contracts.noAssistantManagerAssigned") {
      return "Hire an assistant manager before delegating contract talks.";
    }
    if (message === "be.error.contracts.playerHasNoActiveContract") {
      return "This player does not have an active contract.";
    }
    return message;
  },
}));

vi.mock("../../lib/countries", () => ({
  countryName: () => "England",
  isValidCountryCode: () => true,
  normaliseNationality: (value: string) => value,
  resolveCountryFlagCode: () => "GB",
}));

function createTeam(overrides: Partial<TeamData> = {}): TeamData {
  return {
    id: "team-1",
    name: "Alpha FC",
    short_name: "ALP",
    country: "GB",
    city: "London",
    stadium_name: "Alpha Ground",
    stadium_capacity: 30000,
    finance: 500000,
    manager_id: "manager-1",
    reputation: 50,
    wage_budget: 50000,
    transfer_budget: 250000,
    season_income: 0,
    season_expenses: 0,
    formation: "4-4-2",
    play_style: "Balanced",
    training_focus: "General",
    training_intensity: "Balanced",
    training_schedule: "Balanced",
    founded_year: 1900,
    colors: { primary: "#000000", secondary: "#ffffff" },
    starting_xi_ids: [],
    form: [],
    history: [],
    ...overrides,
  };
}

function createPlayer(overrides: Partial<PlayerData> = {}): PlayerData {
  return {
    id: "player-1",
    match_name: "J. Smith",
    full_name: "John Smith",
    date_of_birth: "2000-01-01",
    nationality: "GB",
    position: "Forward",
    natural_position: "Forward",
    alternate_positions: [],
    training_focus: null,
    attributes: {
      pace: 60,
      stamina: 60,
      strength: 60,
      agility: 60,
      passing: 60,
      shooting: 60,
      tackling: 60,
      dribbling: 60,
      defending: 60,
      positioning: 60,
      vision: 60,
      decisions: 60,
      composure: 60,
      aggression: 60,
      teamwork: 60,
      leadership: 60,
      handling: 20,
      reflexes: 20,
      aerial: 60,
    },
    condition: 80,
    morale: 75,
    injury: null,
    team_id: "team-1",
    retired: false,
    contract_end: "2026-10-15",
    wage: 12000,
    market_value: 350000,
    stats: {
      appearances: 0,
      goals: 0,
      assists: 0,
      clean_sheets: 0,
      yellow_cards: 0,
      red_cards: 0,
      avg_rating: 0,
      minutes_played: 0,
      shots: 0,
      shots_on_target: 0,
      passes_completed: 0,
      passes_attempted: 0,
      tackles_won: 0,
      interceptions: 0,
      fouls_committed: 0,
    },
    career: [],
    transfer_listed: false,
    loan_listed: false,
    transfer_offers: [],
    movement_history: [],
    traits: [],
    ...overrides,
  };
}

function createStaff(overrides: Partial<StaffData> = {}): StaffData {
  return {
    id: "staff-1",
    first_name: "Alex",
    last_name: "Assistant",
    display_name: "Alex Assistant",
    date_of_birth: "1980-01-01",
    nationality: "GB",
    role: "AssistantManager" as const,
    attributes: {
      coaching: 70,
      judgingAbility: 60,
      judgingPotential: 60,
      physiotherapy: 20,
    },
    team_id: "team-1",
    specialization: "General",
    wage: 1200,
    contract_end: "2027-06-30",
    ...overrides,
  };
}

function createGameState(player: PlayerData, staff: StaffData[] = []): GameStateData {
  return {
    season_context: createSeasonContext(),
    clock: {
      current_date: "2026-08-01T00:00:00Z",
      start_date: "2026-07-01T00:00:00Z",
    },
    manager: {
      display_name: "Jane Doe",
      id: "manager-1",
      first_name: "Jane",
      last_name: "Doe",
      date_of_birth: "1980-01-01",
      nationality: "GB",
      reputation: 50,
      satisfaction: 50,
      fan_approval: 50,
      team_id: "team-1",
      career_stats: {
        matches_managed: 0,
        wins: 0,
        draws: 0,
        losses: 0,
        trophies: 0,
        best_finish: null,
      },
      career_history: [],
    },
    teams: [createTeam()],
    players: [player],
    staff,
    messages: [],
    news: [],
    league: {
      id: "league-1",
      name: "League",
      season: 1,
      fixtures: [],
      standings: [],
    },
    scouting_assignments: [],
    board_objectives: [],
  };
}

function createAdvancedStatsSummary() {
  return {
    percentileEligible: false,
    metrics: {
      shots: { total: 0, per90: null, percentile: null },
      shotsOnTarget: { total: 0, per90: null, percentile: null },
      passes: {
        completed: 0,
        attempted: 0,
        accuracy: null,
        percentile: null,
      },
      tacklesWon: { total: 0, per90: null, percentile: null },
      interceptions: { total: 0, per90: null, percentile: null },
      foulsCommitted: { total: 0, per90: null, percentile: null },
    },
  };
}

function defaultInvokeResponse(command: string) {
  if (command === "get_player_stats_overview") {
    return createAdvancedStatsSummary();
  }

  if (command === "get_player_match_history") {
    return [];
  }

  if (command === "get_scouted_report") {
    return null;
  }

  return createGameState(createPlayer());
}

function RenewalHarness({ initialPlayer }: { initialPlayer?: PlayerData }) {
  const [gameState, setGameState] = useState<GameStateData>(
    createGameState(initialPlayer ?? createPlayer()),
  );

  return (
    <PlayerProfile
      player={gameState.players[0]}
      gameState={gameState}
      isOwnClub
      onGameUpdate={setGameState}
    />
  );
}

describe("PlayerProfile contract surfaces", () => {
  beforeEach(() => {
    riskLevels.current = {};
    knowledge.current = {};
    vi.mocked(invoke).mockReset();
    vi.mocked(invoke).mockImplementation(async (command: string) => defaultInvokeResponse(command));
  });

  // The dashboard opens a profile straight into one of these modals when the
  // player arrives from an inbox action. Both are driven by effects, so nothing
  // is clicked and no other test in this file reaches them.
  it("opens the renewal modal on arrival when asked to", async () => {
    const player = createPlayer();

    render(
      <PlayerProfile
        player={player}
        gameState={createGameState(player, [createStaff()])}
        isOwnClub
        startWithRenewalModal
        onGameUpdate={vi.fn()}
      />,
    );

    await waitFor(() => {
      expect(screen.getByRole("button", { name: "Submit Offer" })).toBeInTheDocument();
    });
  });

  it("opens the termination modal on arrival when asked to", async () => {
    const player = createPlayer();

    vi.mocked(invoke).mockImplementation(async (command: string) => {
      if (command === "preview_contract_termination") {
        return {
          preview: {
            player_id: "player-1",
            player_name: "J. Smith",
            severance_cost: 132000,
            squad_safety: {
              team_id: "team-1",
              projected_roster_size: 11,
              healthy_players: 11,
              healthy_goalkeepers: 1,
              effective_xi_size: 11,
              can_field_matchday_squad: true,
              missing_reasons: [],
            },
          },
        };
      }

      return defaultInvokeResponse(command);
    });

    render(
      <PlayerProfile
        player={player}
        gameState={createGameState(player, [createStaff()])}
        isOwnClub
        startWithTerminationModal
        onGameUpdate={vi.fn()}
      />,
    );

    await waitFor(() => {
      expect(invoke).toHaveBeenCalledWith("preview_contract_termination", {
        playerId: "player-1",
      });
    });
    await waitFor(() => {
      expect(screen.getByText("Severance")).toBeInTheDocument();
    });
  });

  // `isOwnClub={false}` alone is not enough: the manager still owns the
  // contract whenever the player's club is theirs. Only a player at another
  // club is genuinely not theirs to renew or release.
  it("leaves both modals shut for a player at another club", async () => {
    const player = createPlayer({ team_id: "team-2" });

    render(
      <PlayerProfile
        player={player}
        gameState={createGameState(player, [createStaff()])}
        isOwnClub={false}
        startWithRenewalModal
        startWithTerminationModal
        onGameUpdate={vi.fn()}
      />,
    );

    await waitFor(() => {
      expect(screen.getByText("Contract Info")).toBeInTheDocument();
    });
    expect(screen.queryByRole("button", { name: "Submit Offer" })).toBeNull();
    expect(invoke).not.toHaveBeenCalledWith("preview_contract_termination", expect.anything());
  });

  /**
   * Given a player at another club whom a scout reported on, flagged out of date by the backend
   * When the profile opens
   * Then the scouted attributes show instead of the hidden placeholder, marked out of date
   */
  it("shows a scouted player's snapshot attributes with the backend's out-of-date verdict", async () => {
    const player = createPlayer({ team_id: "team-2" });
    knowledge.current = {
      [player.id]: { kind: "scouted", scouted_on: "2026-03-10", current: false },
    };
    vi.mocked(invoke).mockImplementation(async (command: string, args?: InvokeArgs) => {
      if (command === "get_scouted_report") {
        expect(args).toEqual({ playerId: player.id });
        return {
          player_id: player.id,
          scouted_on: "2026-03-10",
          attributes: { ...player.attributes, pace: 77 },
          out_of_date: true,
        };
      }
      return defaultInvokeResponse(command);
    });

    render(
      <PlayerProfile
        player={player}
        gameState={createGameState(player, [createStaff()])}
        isOwnClub={false}
        onGameUpdate={vi.fn()}
      />,
    );

    expect(await screen.findByText("playerProfile.scoutReportOutOfDate")).toBeInTheDocument();
    expect(screen.getByText("77")).toBeInTheDocument();
    expect(screen.queryByText("playerProfile.attributesHidden")).not.toBeInTheDocument();
  });

  /**
   * Given a player nobody has scouted
   * When the profile opens
   * Then the attributes stay hidden
   */
  it("keeps the attributes hidden when the backend has no report", async () => {
    const player = createPlayer({ team_id: "team-2" });
    knowledge.current = { [player.id]: { kind: "unknown" } };
    vi.mocked(invoke).mockImplementation(async (command: string) => {
      if (command === "get_scouted_report") return null;
      return defaultInvokeResponse(command);
    });

    render(
      <PlayerProfile
        player={player}
        gameState={createGameState(player, [createStaff()])}
        isOwnClub={false}
        onGameUpdate={vi.fn()}
      />,
    );

    await waitFor(() => {
      expect(invoke).toHaveBeenCalledWith("get_scouted_report", { playerId: player.id });
    });
    expect(screen.getByText("playerProfile.attributesHidden")).toBeInTheDocument();
  });

  /**
   * Given a player born on 10 March 2000 and a game date of 1 August 2030
   * When the profile opens
   * Then it shows age 30
   */
  it("shows the age on the game's current date", () => {
    const player = createPlayer({ date_of_birth: "2000-03-10" });
    const state = createGameState(player);
    state.clock = { ...state.clock, current_date: "2030-08-01T00:00:00Z" };

    render(<PlayerProfile player={player} gameState={state} isOwnClub />);

    expect(screen.getByText("Age 30")).toBeInTheDocument();
  });

  /**
   * Given a player's profile, shown under the dashboard header that already has a Back
   * When it renders
   * Then it adds no second Back of its own
   */
  it("leaves Back to the dashboard header", () => {
    const player = createPlayer();

    render(<PlayerProfile player={player} gameState={createGameState(player)} isOwnClub />);

    expect(screen.queryByRole("button", { name: "Back" })).not.toBeInTheDocument();
  });

  /**
   * Given the same player the day before and the day after his birthday in 2031
   * When the profile opens on each date
   * Then it shows 30, then 31
   */
  it.each([
    { date: "2031-03-09T00:00:00Z", age: 30 },
    { date: "2031-03-10T00:00:00Z", age: 31 },
  ])("changes the age when the birthday passes ($date)", ({ date, age }) => {
    const player = createPlayer({ date_of_birth: "2000-03-10" });
    const state = createGameState(player);
    state.clock = { ...state.clock, current_date: date };

    render(<PlayerProfile player={player} gameState={state} isOwnClub />);

    expect(screen.getByText(`Age ${age}`)).toBeInTheDocument();
  });

  it("renders expiry date, years remaining, and contract risk for the selected player", () => {
    const player = createPlayer();
    riskLevels.current = { [player.id]: "critical" };
    const gameState = createGameState(player);

    render(<PlayerProfile player={player} gameState={gameState} isOwnClub />);

    expect(screen.getByText("Contract Info")).toBeInTheDocument();
    expect(screen.getByText("Expires October 15, 2026")).toBeInTheDocument();
    expect(screen.getByText("Years Remaining")).toBeInTheDocument();
    expect(screen.getByText("Contract Risk")).toBeInTheDocument();
    expect(screen.getByText("Critical")).toBeInTheDocument();
    expect(screen.getByText("Weekly Wage")).toBeInTheDocument();
    expect(
      screen.getAllByText((_, element) => hasWeeklyWage(element?.textContent ?? "", "12K")).length,
    ).toBeGreaterThan(0);
  });

  it("hides contract actions for loaned-in players owned by another club", () => {
    const player = createPlayer({
      team_id: "team-1",
      active_loan: {
        parent_team_id: "team-2",
        loan_team_id: "team-1",
        start_date: "2026-08-01",
        end_date: "2027-01-01",
        wage_contribution_pct: 75,
        buy_option_fee: null,
        loan_start_minutes: 0,
        loan_start_appearances: 0,
        development_reported_minutes: 0,
        development_reported_appearances: 0,
      },
    });

    const gameState = createGameState(player);
    gameState.teams.push(
      createTeam({
        id: "team-2",
        name: "Beta FC",
        short_name: "BET",
        manager_id: null,
      }),
    );

    render(
      <PlayerProfile player={player} gameState={gameState} isOwnClub onGameUpdate={vi.fn()} />,
    );

    expect(screen.getByText("Loan Status")).toBeInTheDocument();
    expect(screen.getByText("On loan from Beta FC")).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Renew Contract" })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Let Expire" })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Terminate Now" })).not.toBeInTheDocument();
  });

  it("shows contract actions for players loaned out by the manager club", () => {
    const player = createPlayer({
      team_id: "team-2",
      active_loan: {
        parent_team_id: "team-1",
        loan_team_id: "team-2",
        start_date: "2026-08-01",
        end_date: "2027-01-01",
        wage_contribution_pct: 75,
        buy_option_fee: null,
        loan_start_minutes: 0,
        loan_start_appearances: 0,
        development_reported_minutes: 0,
        development_reported_appearances: 0,
      },
    });

    const gameState = createGameState(player);
    gameState.teams.push(
      createTeam({
        id: "team-2",
        name: "Beta FC",
        short_name: "BET",
        manager_id: null,
      }),
    );

    render(
      <PlayerProfile
        player={player}
        gameState={gameState}
        isOwnClub={false}
        onGameUpdate={vi.fn()}
      />,
    );

    expect(screen.getByText("Loan Status")).toBeInTheDocument();
    expect(screen.getByText("On loan at Beta FC")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Renew Contract" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Let Expire" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Terminate Now" })).toBeInTheDocument();
    expect(screen.queryByText("Hire a scout first")).not.toBeInTheDocument();
    expect(screen.queryByText("playerProfile.attributesHidden")).not.toBeInTheDocument();
    expect(screen.queryAllByText("??")).toHaveLength(0);
  });

  it("allows selecting the player's team from the hero header", () => {
    const player = createPlayer();
    const gameState = createGameState(player);
    const onSelectTeam = vi.fn();

    render(
      <PlayerProfile player={player} gameState={gameState} isOwnClub onSelectTeam={onSelectTeam} />,
    );

    fireEvent.click(screen.getByRole("button", { name: "Alpha FC" }));

    expect(onSelectTeam).toHaveBeenCalledWith("team-1");
  });

  it("offers a context menu action to open the player's team", () => {
    const player = createPlayer();
    const gameState = createGameState(player);
    const onSelectTeam = vi.fn();

    render(
      <PlayerProfile player={player} gameState={gameState} isOwnClub onSelectTeam={onSelectTeam} />,
    );

    fireEvent.contextMenu(screen.getByTestId("player-profile-team-link"));
    fireEvent.click(screen.getByRole("menuitem", { name: "View team" }));

    expect(onSelectTeam).toHaveBeenCalledWith("team-1");
  });

  it("loads advanced stats from the backend overview query", async () => {
    const player = createPlayer({
      stats: {
        appearances: 10,
        goals: 4,
        assists: 3,
        clean_sheets: 0,
        yellow_cards: 1,
        red_cards: 0,
        avg_rating: 7.2,
        minutes_played: 450,
        shots: 20,
        shots_on_target: 10,
        passes_completed: 80,
        passes_attempted: 100,
        tackles_won: 9,
        interceptions: 6,
        fouls_committed: 5,
      },
    });
    const peerA = createPlayer({
      id: "player-2",
      match_name: "A. Peer",
      full_name: "Alpha Peer",
      stats: {
        ...player.stats,
        shots: 10,
        shots_on_target: 5,
        passes_completed: 70,
        passes_attempted: 100,
        tackles_won: 6,
        interceptions: 4,
        fouls_committed: 3,
      },
    });
    const peerB = createPlayer({
      id: "player-3",
      match_name: "B. Peer",
      full_name: "Bravo Peer",
      stats: {
        ...player.stats,
        shots: 15,
        shots_on_target: 8,
        passes_completed: 75,
        passes_attempted: 100,
        tackles_won: 7,
        interceptions: 5,
        fouls_committed: 4,
      },
    });
    const gameState = {
      ...createGameState(player),
      players: [player, peerA, peerB],
    };

    vi.mocked(invoke).mockImplementation(async (command: string) => {
      if (command === "get_player_stats_overview") {
        return {
          percentileEligible: true,
          metrics: {
            shots: { total: 33, per90: 6.6, percentile: 88 },
            shotsOnTarget: { total: 14, per90: 2.8, percentile: 81 },
            passes: {
              completed: 144,
              attempted: 180,
              accuracy: 80,
              percentile: 77,
            },
            tacklesWon: { total: 15, per90: 3, percentile: 72 },
            interceptions: { total: 11, per90: 2.2, percentile: 70 },
            foulsCommitted: { total: 8, per90: 1.6, percentile: 41 },
          },
        };
      }

      if (command === "get_player_match_history") {
        return [];
      }

      return defaultInvokeResponse(command);
    });

    render(<PlayerProfile player={player} gameState={gameState} isOwnClub />);

    await waitFor(() => {
      expect(invoke).toHaveBeenCalledWith("get_player_stats_overview", {
        playerId: "player-1",
      });
      expect(screen.getByText("Advanced Stats")).toBeInTheDocument();
      expect(screen.getByText("Shots")).toBeInTheDocument();
      expect(screen.getAllByText("33").length).toBeGreaterThan(0);
      expect(screen.getAllByText("80%").length).toBeGreaterThan(0);
      expect(screen.getByText("88th")).toBeInTheDocument();
    });
  });

  /**
   * Given the backend overview flags the season rating as available or not
   * When the profile opens for a player with a stored 7.2 average
   * Then the season card shows 7.2 only when the flag says so
   */
  it.each([
    { seasonRatingRated: true, shown: "7.2" },
    { seasonRatingRated: false, shown: "–" },
  ])(
    "shows the season average only when the backend flags it ($seasonRatingRated)",
    async ({ seasonRatingRated, shown }) => {
      const player = createPlayer({
        stats: { ...createPlayer().stats, avg_rating: 7.2, minutes_played: 450 },
      });
      vi.mocked(invoke).mockImplementation(async (command: string) => {
        if (command === "get_player_stats_overview") {
          return {
            ...createAdvancedStatsSummary(),
            percentileEligible: true,
            seasonRatingRated,
          };
        }
        if (command === "get_player_match_history") {
          return [];
        }
        return defaultInvokeResponse(command);
      });

      render(<PlayerProfile player={player} gameState={createGameState(player)} isOwnClub />);

      await waitFor(() => {
        expect(
          screen.getByText("playerProfile.avgRating").previousElementSibling,
        ).toHaveTextContent(shown);
      });
    },
  );

  it("loads and renders recent player match history", async () => {
    const player = createPlayer({
      stats: {
        appearances: 10,
        goals: 4,
        assists: 3,
        clean_sheets: 0,
        yellow_cards: 1,
        red_cards: 0,
        avg_rating: 7.2,
        minutes_played: 450,
        shots: 20,
        shots_on_target: 10,
        passes_completed: 80,
        passes_attempted: 100,
        tackles_won: 9,
        interceptions: 6,
        fouls_committed: 5,
      },
    });
    vi.mocked(invoke).mockImplementation(async (command: string) => {
      if (command === "get_player_match_history") {
        return [
          {
            fixture_id: "fixture-1",
            date: "2025-06-17",
            competition: "League",
            matchday: 2,
            opponent_team_id: "team-3",
            opponent_name: "Bravo FC",
            team_goals: 3,
            opponent_goals: 0,
            minutes_played: 88,
            goals: 2,
            assists: 1,
            shots: 5,
            shots_on_target: 3,
            rating: 8.4,
            rated: true,
          },
        ];
      }

      return defaultInvokeResponse(command);
    });

    render(<PlayerProfile player={player} gameState={createGameState(player)} isOwnClub />);

    await waitFor(() => {
      expect(invoke).toHaveBeenCalledWith("get_player_match_history", {
        playerId: "player-1",
        limit: 5,
      });
      expect(screen.getByText("Recent Matches")).toBeInTheDocument();
      expect(screen.getByText("Bravo FC")).toBeInTheDocument();
      expect(screen.getByText("3-0")).toBeInTheDocument();
      expect(screen.getByText("8.4")).toBeInTheDocument();
    });
  });

  it("renders player movement history from transfers and loans", async () => {
    const player = createPlayer({
      movement_history: [
        {
          date: "2026-08-01",
          kind: "permanent_transfer",
          from_team_id: "team-2",
          from_team_name: "Beta FC",
          to_team_id: "team-1",
          to_team_name: "Alpha FC",
          fee: 1_250_000,
          loan_end_date: null,
        },
        {
          date: "2027-01-01",
          kind: "loan_return",
          from_team_id: "team-3",
          from_team_name: "Gamma FC",
          to_team_id: "team-1",
          to_team_name: "Alpha FC",
          fee: null,
          loan_end_date: "2027-01-01",
        },
      ],
    });

    render(<PlayerProfile player={player} gameState={createGameState(player)} isOwnClub />);

    expect(screen.getByText("Movement History")).toBeInTheDocument();
    expect(screen.getByText("Gamma FC -> Alpha FC")).toBeInTheDocument();
    expect(screen.getByText("Beta FC -> Alpha FC")).toBeInTheDocument();
    expect(screen.getByText("Fee €1,250,000")).toBeInTheDocument();
    expect(screen.getByText("Loan until 2027-01-01")).toBeInTheDocument();
  });

  it("validates renewal offers before submission", async () => {
    vi.mocked(invoke).mockImplementation(async (command: string, payload?: InvokeArgs) => {
      const args = payload as MockInvokePayload | undefined;
      if (command === "preview_renewal_financial_impact") {
        const offered = Number(args?.weeklyWage ?? 0);
        return {
          projection: {
            current_annual_wage_bill: 24000,
            projected_annual_wage_bill: 24000 - 12000 + offered,
            annual_wage_budget: 50000,
            annual_soft_cap: 55000,
            current_weekly_wage_spend: 24000,
            projected_weekly_wage_spend: 24000 - 12000 + offered,
            current_cash_runway_weeks: 1084,
            projected_cash_runway_weeks: 500,
            currently_over_budget: false,
            policy_allows: offered <= 55000,
          },
        };
      }

      return defaultInvokeResponse(command);
    });

    render(<RenewalHarness />);

    fireEvent.click(screen.getByRole("button", { name: "Renew Contract" }));

    fireEvent.change(screen.getByLabelText("Offered Wage"), {
      target: { value: "0" },
    });

    expect(screen.getByText("Enter a valid weekly wage")).toBeInTheDocument();

    fireEvent.change(screen.getByLabelText("Offered Wage"), {
      target: { value: "60000" },
    });

    await waitFor(() => {
      expect(screen.getByText("Exceeds wage budget")).toBeInTheDocument();
      expect(screen.getByRole("button", { name: "Submit Offer" })).toBeDisabled();
      expect(screen.getByText("Projected financial impact")).toBeInTheDocument();
    });
  });

  it("submits a renewal offer and refreshes contract data when accepted", async () => {
    const updatedPlayer = createPlayer({
      contract_end: "2029-08-01",
      wage: 15000,
    });
    const updatedGame = createGameState(updatedPlayer);

    vi.mocked(invoke).mockImplementation(async (command: string) => {
      if (command === "propose_renewal") {
        return {
          outcome: "accepted",
          game: updatedGame,
          suggested_wage: null,
          suggested_years: null,
          session_status: "agreed",
          is_terminal: true,
        };
      }

      return defaultInvokeResponse(command);
    });

    render(<RenewalHarness />);

    fireEvent.click(screen.getByRole("button", { name: "Renew Contract" }));
    fireEvent.change(screen.getByLabelText("Offered Wage"), {
      target: { value: "15000" },
    });
    fireEvent.change(screen.getByLabelText("Contract Length"), {
      target: { value: "3" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Submit Offer" }));

    await waitFor(() => {
      expect(invoke).toHaveBeenCalledWith("propose_renewal", {
        careerToken: 0,
        playerId: "player-1",
        weeklyWage: 15000,
        contractYears: 3,
      });
    });

    await waitFor(() => {
      expect(screen.getByText("Offer accepted")).toBeInTheDocument();
      expect(screen.getByText("Expires August 1, 2029")).toBeInTheDocument();
      expect(
        screen.getAllByText((_, element) => hasWeeklyWage(element?.textContent ?? "", "15K"))
          .length,
      ).toBeGreaterThan(0);
      expect(screen.getByText("Stable")).toBeInTheDocument();
      expect(screen.getByRole("button", { name: "Done" })).toBeInTheDocument();
      expect(screen.queryByRole("button", { name: "Submit Offer" })).not.toBeInTheDocument();
    });
  });

  it("shows a rejected state when the renewal offer is turned down", async () => {
    vi.mocked(invoke).mockImplementation(async (command: string) => {
      if (command === "propose_renewal") {
        return {
          outcome: "rejected",
          game: createGameState(createPlayer()),
          suggested_wage: null,
          suggested_years: null,
          session_status: "stalled",
          is_terminal: false,
        };
      }

      return defaultInvokeResponse(command);
    });

    render(<RenewalHarness />);

    fireEvent.click(screen.getByRole("button", { name: "Renew Contract" }));
    fireEvent.change(screen.getByLabelText("Offered Wage"), {
      target: { value: "12000" },
    });
    fireEvent.change(screen.getByLabelText("Contract Length"), {
      target: { value: "2" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Submit Offer" }));

    await waitFor(() => {
      expect(screen.getByText("Offer rejected")).toBeInTheDocument();
    });
  });

  it("shows improved terms when the player wants more", async () => {
    vi.mocked(invoke).mockImplementation(async (command: string) => {
      if (command === "propose_renewal") {
        return {
          outcome: "counter_offer",
          game: createGameState(createPlayer()),
          suggested_wage: 16000,
          suggested_years: 4,
          session_status: "open",
          is_terminal: false,
          feedback: {
            mood: "firm",
            headline_key: "playerProfile.renewalFeedbackFirmHeadline",
            detail_key: "playerProfile.renewalFeedbackFirmDetail",
            tension: 58,
            patience: 64,
            round: 1,
            params: {},
          },
        };
      }

      return defaultInvokeResponse(command);
    });

    render(<RenewalHarness />);

    fireEvent.click(screen.getByRole("button", { name: "Renew Contract" }));
    fireEvent.change(screen.getByLabelText("Offered Wage"), {
      target: { value: "13000" },
    });
    fireEvent.change(screen.getByLabelText("Contract Length"), {
      target: { value: "2" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Submit Offer" }));

    await waitFor(() => {
      expect(screen.getByText("Wants more: €16,000/wk for 4 years")).toBeInTheDocument();
      expect(screen.getByText("Negotiation pulse")).toBeInTheDocument();
      expect(screen.getByText("They want stronger terms before moving.")).toBeInTheDocument();
      expect(screen.getByText("Round 1")).toBeInTheDocument();
      expect(screen.getByText("Patience")).toBeInTheDocument();
      expect(screen.getByText("Tension")).toBeInTheDocument();
    });
  });

  it("shows a cooled-off notice when stale talks reset before a new offer", async () => {
    vi.mocked(invoke).mockImplementation(async (command: string) => {
      if (command === "propose_renewal") {
        return {
          outcome: "counter_offer",
          game: createGameState(createPlayer()),
          suggested_wage: 15500,
          suggested_years: 3,
          session_status: "open",
          is_terminal: false,
          cooled_off: true,
          feedback: {
            mood: "calm",
            headline_key: "playerProfile.renewalFeedbackCalmHeadline",
            detail_key: "playerProfile.renewalFeedbackCalmDetail",
            tension: 34,
            patience: 76,
            round: 1,
            params: {},
          },
        };
      }

      return defaultInvokeResponse(command);
    });

    render(<RenewalHarness />);

    fireEvent.click(screen.getByRole("button", { name: "Renew Contract" }));
    fireEvent.change(screen.getByLabelText("Offered Wage"), {
      target: { value: "13500" },
    });
    fireEvent.change(screen.getByLabelText("Contract Length"), {
      target: { value: "2" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Submit Offer" }));

    await waitFor(() => {
      expect(
        screen.getByText("Previous talks cooled off, so this starts as a fresh conversation."),
      ).toBeInTheDocument();
      expect(screen.getByText("Round 1")).toBeInTheDocument();
    });
  });

  it("can delegate a single renewal attempt to the assistant", async () => {
    const delegatedPlayer = createPlayer({
      contract_end: "2029-08-01",
      wage: 14000,
    });
    const updatedGame = createGameState(delegatedPlayer);

    vi.mocked(invoke).mockImplementation(async (command: string) => {
      if (command === "delegate_renewals") {
        return {
          game: updatedGame,
          report: {
            success_count: 1,
            failure_count: 0,
            stalled_count: 0,
            cases: [
              {
                player_id: "player-1",
                player_name: "John Smith",
                status: "successful",
                agreed_wage: 14000,
                agreed_years: 3,
                note: "I was able to close this one without needing you to step in.",
              },
            ],
          },
        };
      }

      return defaultInvokeResponse(command);
    });

    render(
      <PlayerProfile
        player={createPlayer()}
        gameState={createGameState(createPlayer(), [createStaff()])}
        isOwnClub
        onGameUpdate={vi.fn()}
      />,
    );

    fireEvent.click(screen.getByRole("button", { name: "Renew Contract" }));
    fireEvent.click(screen.getByRole("button", { name: "Delegate to Assistant" }));

    await waitFor(() => {
      expect(invoke).toHaveBeenCalledWith("delegate_renewals", {
        careerToken: 0,
        playerIds: ["player-1"],
        maxWageIncreasePct: 35,
        maxContractYears: 3,
      });
    });

    await waitFor(() => {
      expect(screen.getByText("Offer accepted")).toBeInTheDocument();
      expect(screen.getByRole("button", { name: "Done" })).toBeInTheDocument();
    });
  });

  it("shows a localized error when the assistant report omits the player", async () => {
    vi.mocked(invoke).mockImplementation(async (command: string) => {
      if (command === "delegate_renewals") {
        return {
          game: createGameState(createPlayer()),
          report: {
            success_count: 0,
            failure_count: 0,
            stalled_count: 0,
            cases: [],
          },
        };
      }

      return defaultInvokeResponse(command);
    });

    render(
      <PlayerProfile
        player={createPlayer()}
        gameState={createGameState(createPlayer(), [createStaff()])}
        isOwnClub
        onGameUpdate={vi.fn()}
      />,
    );

    fireEvent.click(screen.getByRole("button", { name: "Renew Contract" }));
    fireEvent.click(screen.getByRole("button", { name: "Delegate to Assistant" }));

    await waitFor(() => {
      expect(screen.getByText("Assistant report did not include this player.")).toBeInTheDocument();
    });
  });

  // The delegated-renewal report has three outcomes and each maps to a
  // different terminal-ness: only `stalled` leaves the negotiation open for the
  // manager to take over by hand. Covered here because the two non-successful
  // branches had no test at all.
  it("leaves renewal talks open when the assistant reports a stalled case", async () => {
    vi.mocked(invoke).mockImplementation(async (command: string) => {
      if (command === "delegate_renewals") {
        return {
          game: createGameState(createPlayer()),
          report: {
            success_count: 0,
            failure_count: 0,
            stalled_count: 1,
            cases: [
              {
                player_id: "player-1",
                player_name: "John Smith",
                status: "stalled",
                note: "They want to see how the season goes before signing.",
              },
            ],
          },
        };
      }

      return defaultInvokeResponse(command);
    });

    render(
      <PlayerProfile
        player={createPlayer()}
        gameState={createGameState(createPlayer(), [createStaff()])}
        isOwnClub
        onGameUpdate={vi.fn()}
      />,
    );

    fireEvent.click(screen.getByRole("button", { name: "Renew Contract" }));
    fireEvent.click(screen.getByRole("button", { name: "Delegate to Assistant" }));

    await waitFor(() => {
      expect(screen.getByText("Offer rejected")).toBeInTheDocument();
    });

    // Not terminal: the manager can still put an offer in themselves.
    expect(screen.getByRole("button", { name: "Submit Offer" })).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Done" })).toBeNull();
  });

  it("closes renewal talks when the assistant reports a failed case", async () => {
    vi.mocked(invoke).mockImplementation(async (command: string) => {
      if (command === "delegate_renewals") {
        return {
          game: createGameState(createPlayer()),
          report: {
            success_count: 0,
            failure_count: 1,
            stalled_count: 0,
            cases: [
              {
                player_id: "player-1",
                player_name: "John Smith",
                status: "failed",
                note: "They have already decided to move on.",
              },
            ],
          },
        };
      }

      return defaultInvokeResponse(command);
    });

    render(
      <PlayerProfile
        player={createPlayer()}
        gameState={createGameState(createPlayer(), [createStaff()])}
        isOwnClub
        onGameUpdate={vi.fn()}
      />,
    );

    fireEvent.click(screen.getByRole("button", { name: "Renew Contract" }));
    fireEvent.click(screen.getByRole("button", { name: "Delegate to Assistant" }));

    await waitFor(() => {
      expect(screen.getByText("Talks are blocked after your earlier decision")).toBeInTheDocument();
    });

    // Terminal: nothing left for the manager to offer.
    expect(screen.getByRole("button", { name: "Done" })).toBeInTheDocument();
  });

  it("disables renewal delegation when no assistant manager is assigned", async () => {
    render(<RenewalHarness />);

    fireEvent.click(screen.getByRole("button", { name: "Renew Contract" }));

    await waitFor(() => {
      expect(screen.getByRole("button", { name: "Delegate to Assistant" })).toBeDisabled();
    });
  });

  it("localizes the no-assistant delegation error if the command still fails", async () => {
    vi.mocked(invoke).mockImplementation(async (command: string) => {
      if (command === "delegate_renewals") {
        throw "be.error.contracts.noAssistantManagerAssigned";
      }

      return defaultInvokeResponse(command);
    });

    render(
      <PlayerProfile
        player={createPlayer()}
        gameState={createGameState(createPlayer(), [createStaff()])}
        isOwnClub
        onGameUpdate={vi.fn()}
      />,
    );

    fireEvent.click(screen.getByRole("button", { name: "Renew Contract" }));
    fireEvent.click(screen.getByRole("button", { name: "Delegate to Assistant" }));

    await waitFor(() => {
      expect(
        screen.getByText("Hire an assistant manager before delegating contract talks."),
      ).toBeInTheDocument();
    });
  });

  it("marks a contract to expire and can reopen talks", async () => {
    const markedPlayer = createPlayer({
      morale_core: {
        manager_trust: 50,
        renewal_state: {
          status: "Blocked",
          manager_blocked_until: null,
          last_attempt_date: "2026-08-01",
          last_assistant_attempt_date: null,
          last_outcome: "BlockedByManager",
          conversation_round: 0,
          exit_intent: {
            kind: "let_expire",
            set_on: "2026-08-01",
            reason: "manager_profile_action",
          },
        },
      },
    });

    vi.mocked(invoke).mockImplementation(async (command: string) => {
      if (command === "set_contract_exit_intent") {
        return { game: createGameState(markedPlayer) };
      }

      if (command === "clear_contract_exit_intent") {
        return { game: createGameState(createPlayer()) };
      }

      return defaultInvokeResponse(command);
    });

    render(<RenewalHarness />);

    fireEvent.click(screen.getByRole("button", { name: "Let Expire" }));

    await waitFor(() => {
      expect(invoke).toHaveBeenCalledWith("set_contract_exit_intent", {
        careerToken: 0,
        playerId: "player-1",
        reason: "manager_profile_action",
      });
      expect(screen.getByRole("button", { name: "Reopen Talks" })).toBeInTheDocument();
    });

    fireEvent.click(screen.getByRole("button", { name: "Reopen Talks" }));

    await waitFor(() => {
      expect(invoke).toHaveBeenCalledWith("clear_contract_exit_intent", {
        careerToken: 0,
        playerId: "player-1",
      });
      expect(screen.getByRole("button", { name: "Let Expire" })).toBeInTheDocument();
    });
  });

  // Regression for #193 / follow-up on PR #245.
  //
  // Backend `RenewalSessionStatus::Blocked` serializes as `"Blocked"` (PascalCase)
  // — serde's default enum representation. The PR #245 fix compared against a
  // lowercase `"blocked"` literal, so the guard was always false and the block
  // was never restored on modal reopen. Existing fixtures used lowercase too,
  // so they matched the buggy frontend and the bug slipped through. This test
  // uses the real wire shape and asserts the modal opens in terminal (blocked)
  // state — only the "Done" button, no Submit path.
  it("restores blocked state when reopening the renewal modal after being blocked", async () => {
    const blockedPlayer = createPlayer({
      morale_core: {
        manager_trust: 30,
        renewal_state: {
          status: "Blocked",
          manager_blocked_until: "2099-01-01",
          last_attempt_date: "2026-08-01",
          last_assistant_attempt_date: null,
          last_outcome: "BlockedByManager",
          conversation_round: 1,
          exit_intent: null,
        },
      },
    });

    render(<RenewalHarness initialPlayer={blockedPlayer} />);

    fireEvent.click(screen.getByRole("button", { name: "Renew Contract" }));

    await waitFor(() => {
      expect(screen.getByRole("button", { name: "Done" })).toBeInTheDocument();
    });
    expect(screen.queryByRole("button", { name: "Submit Offer" })).not.toBeInTheDocument();
  });

  it("localizes contract action failures instead of showing raw backend keys", async () => {
    vi.mocked(invoke).mockImplementation(async (command: string) => {
      if (command === "set_contract_exit_intent") {
        throw "be.error.contracts.playerHasNoActiveContract";
      }

      return defaultInvokeResponse(command);
    });

    render(<RenewalHarness />);

    fireEvent.click(screen.getByRole("button", { name: "Let Expire" }));

    await waitFor(() => {
      expect(screen.getByText("This player does not have an active contract.")).toBeInTheDocument();
    });
  });

  // The four contract actions share one `submitting` flag, and it is what
  // disables the buttons. Without it a second action could be started on top of
  // the first, so no termination preview may be requested while an exit intent
  // is still in flight.
  it("locks the contract actions while one of them is in flight", async () => {
    let releaseExitIntent: (() => void) | undefined;

    vi.mocked(invoke).mockImplementation(async (command: string) => {
      if (command === "set_contract_exit_intent") {
        await new Promise<void>((resolve) => {
          releaseExitIntent = resolve;
        });
        return { game: createGameState(createPlayer()) };
      }

      return defaultInvokeResponse(command);
    });

    render(<RenewalHarness />);

    fireEvent.click(screen.getByRole("button", { name: "Let Expire" }));
    await waitFor(() => {
      expect(invoke).toHaveBeenCalledWith("set_contract_exit_intent", {
        careerToken: 0,
        playerId: "player-1",
        reason: "manager_profile_action",
      });
    });

    const terminate = screen.getByRole("button", { name: "Terminate Now" });
    expect(terminate).toBeDisabled();

    fireEvent.click(terminate);
    expect(invoke).not.toHaveBeenCalledWith("preview_contract_termination", expect.anything());

    releaseExitIntent?.();
    await waitFor(() => {
      expect(screen.getByRole("button", { name: "Terminate Now" })).toBeEnabled();
    });
  });

  it("previews and confirms immediate contract termination", async () => {
    const releasedPlayer = createPlayer({
      team_id: null,
      contract_end: null,
      wage: 0,
    });

    vi.mocked(invoke).mockImplementation(async (command: string) => {
      if (command === "preview_contract_termination") {
        return {
          preview: {
            player_id: "player-1",
            player_name: "J. Smith",
            severance_cost: 132000,
            squad_safety: {
              team_id: "team-1",
              projected_roster_size: 11,
              healthy_players: 11,
              healthy_goalkeepers: 1,
              effective_xi_size: 11,
              can_field_matchday_squad: true,
              missing_reasons: [],
            },
          },
        };
      }

      if (command === "terminate_contract_now") {
        return {
          game: createGameState(releasedPlayer),
          severance_cost: 132000,
          squad_safety: {
            team_id: "team-1",
            projected_roster_size: 11,
            healthy_players: 11,
            healthy_goalkeepers: 1,
            effective_xi_size: 11,
            can_field_matchday_squad: true,
            missing_reasons: [],
          },
        };
      }

      return defaultInvokeResponse(command);
    });

    render(<RenewalHarness />);

    fireEvent.click(screen.getByRole("button", { name: "Terminate Now" }));

    await waitFor(() => {
      expect(invoke).toHaveBeenCalledWith("preview_contract_termination", {
        playerId: "player-1",
      });
      expect(screen.getByText("Severance")).toBeInTheDocument();
      expect(screen.getByText("11/11")).toBeInTheDocument();
    });

    fireEvent.click(screen.getByRole("button", { name: "Terminate Contract" }));

    await waitFor(() => {
      expect(invoke).toHaveBeenCalledWith("terminate_contract_now", {
        careerToken: 0,
        playerId: "player-1",
      });
      expect(screen.getByText("No Contract")).toBeInTheDocument();
    });
  });
});

// `DashboardWorkspaceContent` renders `<PlayerProfile />` without a `key`, so
// switching player reuses the component instance and every piece of hook state
// survives. Anything scoped to one player has to reset on `player.id` itself.
describe("PlayerProfile switching between players", () => {
  beforeEach(() => {
    vi.mocked(invoke).mockReset();
    vi.mocked(invoke).mockImplementation(async (command: string) => defaultInvokeResponse(command));
  });

  function scoutStaff(): StaffData {
    return createStaff({ id: "scout-1", role: "Scout" as StaffData["role"] });
  }

  // Scouting is offered for players the manager does *not* have, so both of
  // these sit at another club.
  it("re-enables scouting for the next player after one has been scouted", async () => {
    const first = createPlayer({ team_id: "team-2" });
    const gameState = createGameState(first, [scoutStaff()]);

    const { rerender } = render(
      <PlayerProfile
        player={first}
        gameState={gameState}
        isOwnClub={false}
        onGameUpdate={vi.fn()}
      />,
    );

    fireEvent.click(screen.getByRole("button", { name: "Scout" }));
    await waitFor(() => {
      expect(invoke).toHaveBeenCalledWith("send_scout", {
        careerToken: 0,
        scoutId: "scout-1",
        playerId: "player-1",
      });
    });

    const second = createPlayer({
      id: "player-2",
      full_name: "Sam Other",
      team_id: "team-2",
    });
    rerender(
      <PlayerProfile
        player={second}
        gameState={createGameState(second, [scoutStaff()])}
        isOwnClub={false}
        onGameUpdate={vi.fn()}
      />,
    );

    // The scout was sent to look at player-1, so player-2 is not being
    // scouted and must still be offered.
    await waitFor(() => {
      expect(screen.getByRole("button", { name: "Scout" })).toBeEnabled();
    });
    expect(screen.queryByText("Scouting in progress")).toBeNull();
  });

  it("drops the previous player's recent matches on arrival", async () => {
    const first = createPlayer({ stats: { ...createPlayer().stats, appearances: 3 } });

    vi.mocked(invoke).mockImplementation(async (command: string, args?: unknown) => {
      if (command === "get_player_match_history") {
        const playerId = (args as { playerId: string }).playerId;
        if (playerId === "player-1") {
          return [
            {
              fixture_id: "fixture-1",
              opponent_name: "Rivals FC",
              date: "2026-07-20",
              is_home: true,
              goals: 1,
              assists: 0,
              rating: 7.5,
              rated: true,
              minutes_played: 90,
            },
          ];
        }
        return [];
      }

      return defaultInvokeResponse(command);
    });

    const { rerender } = render(
      <PlayerProfile
        player={first}
        gameState={createGameState(first)}
        isOwnClub
        onGameUpdate={vi.fn()}
      />,
    );

    await waitFor(() => {
      expect(screen.getByText("Rivals FC")).toBeInTheDocument();
    });

    const second = createPlayer({
      id: "player-2",
      full_name: "Sam Other",
      stats: { ...createPlayer().stats, appearances: 3 },
    });
    rerender(
      <PlayerProfile
        player={second}
        gameState={createGameState(second)}
        isOwnClub
        onGameUpdate={vi.fn()}
      />,
    );

    await waitFor(() => {
      expect(screen.queryByText("Rivals FC")).toBeNull();
    });
  });
});

describe("PlayerProfile free agent signing", () => {
  beforeEach(() => {
    vi.mocked(invoke).mockReset();
    vi.mocked(invoke).mockImplementation(async (command: string) => defaultInvokeResponse(command));
  });

  it("shows Offer Contract button for a free agent player", () => {
    const freeAgent = createPlayer({
      team_id: null,
      contract_end: null,
      wage: 0,
    });
    const gameState = createGameState(freeAgent);

    render(
      <PlayerProfile
        player={freeAgent}
        gameState={gameState}
        isOwnClub={false}
        onGameUpdate={vi.fn()}
      />,
    );

    expect(screen.getByRole("button", { name: "Offer Contract" })).toBeInTheDocument();
  });

  it("does not show Offer Contract for a retired free agent", () => {
    const retired = createPlayer({
      team_id: null,
      contract_end: null,
      wage: 0,
      retired: true,
    });
    const gameState = createGameState(retired);

    render(
      <PlayerProfile
        player={retired}
        gameState={gameState}
        isOwnClub={false}
        onGameUpdate={vi.fn()}
      />,
    );

    expect(screen.queryByRole("button", { name: "Offer Contract" })).not.toBeInTheDocument();
  });

  it("opens the contract modal when Offer Contract is clicked", async () => {
    const freeAgent = createPlayer({
      team_id: null,
      contract_end: null,
      wage: 0,
      market_value: 600_000,
    });
    const gameState = createGameState(freeAgent);

    render(
      <PlayerProfile
        player={freeAgent}
        gameState={gameState}
        isOwnClub={false}
        onGameUpdate={vi.fn()}
      />,
    );

    fireEvent.click(screen.getByRole("button", { name: "Offer Contract" }));

    await waitFor(() => {
      expect(screen.getByRole("dialog", { name: "Offer Contract" })).toBeInTheDocument();
    });
  });

  it("submits offer_free_agent_contract and updates game state on acceptance", async () => {
    const freeAgent = createPlayer({
      team_id: null,
      contract_end: null,
      wage: 0,
      market_value: 600_000,
    });
    const signedPlayer = createPlayer({
      team_id: "team-1",
      contract_end: "2029-08-01",
      wage: 4_000,
    });
    const onGameUpdate = vi.fn();

    vi.mocked(invoke).mockImplementation(async (command: string) => {
      if (command === "get_free_agent_opening_offer") {
        return { weekly_wage: 3000, contract_years: 3 };
      }
      if (command === "offer_free_agent_contract") {
        return {
          outcome: "accepted",
          game: createGameState(signedPlayer),
          suggested_wage: null,
          suggested_years: null,
          session_status: "agreed",
          is_terminal: true,
          cooled_off: false,
          feedback: null,
        };
      }
      return defaultInvokeResponse(command);
    });

    render(
      <PlayerProfile
        player={freeAgent}
        gameState={createGameState(freeAgent)}
        isOwnClub={false}
        onGameUpdate={onGameUpdate}
      />,
    );

    fireEvent.click(screen.getByRole("button", { name: "Offer Contract" }));

    await waitFor(() => {
      expect(screen.getByRole("dialog", { name: "Offer Contract" })).toBeInTheDocument();
    });
    await waitFor(() => {
      expect(screen.getByRole("button", { name: "Submit Offer" })).toBeEnabled();
    });

    fireEvent.click(screen.getByRole("button", { name: "Submit Offer" }));

    await waitFor(() => {
      expect(invoke).toHaveBeenCalledWith("offer_free_agent_contract", {
        careerToken: 0,
        playerId: "player-1",
        weeklyWage: 3000,
        contractYears: 3,
      });
      expect(onGameUpdate).toHaveBeenCalled();
    });
  });
});

describe("PlayerProfile shows only what the club knows", () => {
  beforeEach(() => {
    riskLevels.current = {};
    knowledge.current = {};
    knowledge.revisions = [];
    wages.current = {};
    wages.revisions = [];
    vi.mocked(invoke).mockReset();
    vi.mocked(invoke).mockImplementation(async (command: string) => defaultInvokeResponse(command));
  });

  // Renders a rival's profile, then the same profile on `next`, and says whether the profile handed
  // the knowledge and wage hooks a new revision for it: whether they would ask the backend again.
  function asksAgainOn(next: (gameState: GameStateData) => GameStateData) {
    const player = rival();
    const gameState = createGameState(player);
    const { rerender } = render(
      <PlayerProfile
        player={player}
        gameState={gameState}
        isOwnClub={false}
        onGameUpdate={vi.fn()}
      />,
    );
    const last = (revisions: string[]) => revisions[revisions.length - 1];
    const before = [last(knowledge.revisions), last(wages.revisions)];
    rerender(
      <PlayerProfile
        player={player}
        gameState={next(gameState)}
        isOwnClub={false}
        onGameUpdate={vi.fn()}
      />,
    );
    return [last(knowledge.revisions) !== before[0], last(wages.revisions) !== before[1]];
  }

  /**
   * Given a rival's profile open on the last day of a season
   * When the season rolls over on the same date (promotion and relegation change who is known)
   * Then the profile asks again what the club knows and which wage it may see
   */
  it("asks again about a rival when the season rolls over on the same date", () => {
    expect(
      asksAgainOn((gameState) => ({
        ...gameState,
        season_context: { ...gameState.season_context, season_start: "2099-07-01" },
      })),
    ).toEqual([true, true]);
  });

  /**
   * Given a rival's profile open
   * When another career is installed under it, on the same date, with the same clubs
   * Then the profile asks again what the club knows and which wage it may see
   */
  it("asks again about a rival when another career is installed under the profile", () => {
    expect(
      asksAgainOn((gameState) => ({
        ...gameState,
        career_token: (gameState.career_token ?? 0) + 1,
      })),
    ).toEqual([true, true]);
  });

  // Condition 80, morale 75, a weekly wage of 12K (also on his contract in the movement history)
  // and the Wonderkid tag: each one something a club only knows about its own player. The tag
  // shows only as the club's opinion (PlayerProfile.potential.test.tsx); his own copy, which
  // tells his true potential, never shows.
  function rival(): PlayerData {
    return createPlayer({
      team_id: "team-2",
      ovr: 77,
      condition: 80,
      morale: 75,
      traits: ["Wonderkid"],
      movement_history: [
        {
          date: "2025-07-01",
          kind: "initial_contract",
          to_team_id: "team-2",
          to_team_name: "Rival FC",
          contract: {
            start: "2025-07-01",
            end: "2028-06-30",
            weekly_wage: 12_000,
            source: "initial",
          },
        },
      ],
    });
  }

  // The movement history's wage on a contract, which only the club's own player shows.
  const showsMovementWage = () => screen.queryByText("playerProfile.movementWage") !== null;

  function renderProfile(player: PlayerData) {
    render(
      <PlayerProfile
        player={player}
        gameState={createGameState(player, [createStaff()])}
        isOwnClub={false}
        onGameUpdate={vi.fn()}
      />,
    );
  }

  // The contract card's weekly wage row: its value, apart from its label.
  const contractWageValue = () =>
    screen.getByText("Weekly Wage").parentElement?.textContent?.replace("Weekly Wage", "").trim();

  const showsWage = () =>
    screen.queryAllByText((_, element) => hasWeeklyWage(element?.textContent ?? "", "12K")).length >
    0;

  /**
   * Given a player at a club in another division, never scouted
   * When his profile opens
   * Then his OVR, condition, morale, wage, attributes and Wonderkid tag are not shown; his market
   *      value, which is public, is
   */
  it("shows only public facts about a player the club does not know", async () => {
    const player = rival();
    knowledge.current = { [player.id]: { kind: "unknown" } };
    wages.current = { [player.id]: { kind: "hidden" } };

    renderProfile(player);

    expect(await screen.findByText("playerProfile.attributesHidden")).toBeInTheDocument();
    expect(screen.queryByText("80%")).not.toBeInTheDocument();
    expect(screen.queryByText("75%")).not.toBeInTheDocument();
    expect(showsWage()).toBe(false);
    expect(contractWageValue()).toBe("–");
    expect(showsMovementWage()).toBe(false);
    expect(screen.queryByText("77")).not.toBeInTheDocument();
    expect(screen.queryByText(/Wonderkid/)).not.toBeInTheDocument();
    expect(screen.getAllByText("€350K").length).toBeGreaterThan(0);
  });

  /**
   * Given a player at a club in the manager's own division, never scouted
   * When his profile opens
   * Then his OVR and attributes show, as the staff see him every season; the Wonderkid tag, which
   *      tells his potential, waits for a scout; his condition, morale and wage stay his club's
   *      business
   */
  it("shows a known rival's attributes but not his potential or his club's private state", async () => {
    const player = rival();
    knowledge.current = { [player.id]: { kind: "known" } };
    wages.current = { [player.id]: { kind: "hidden" } };

    renderProfile(player);

    expect(await screen.findByText("77")).toBeInTheDocument();
    expect(screen.queryByText(/Wonderkid/)).not.toBeInTheDocument();
    expect(screen.queryByText("playerProfile.attributesHidden")).not.toBeInTheDocument();
    expect(screen.queryByText("80%")).not.toBeInTheDocument();
    expect(screen.queryByText("75%")).not.toBeInTheDocument();
    expect(showsWage()).toBe(false);
    expect(contractWageValue()).toBe("–");
    expect(showsMovementWage()).toBe(false);
  });

  /**
   * Given a player in another division whom a scout reported on this season
   * When his profile opens
   * Then the scout's attributes show and his wage reads as about the figure, but not his OVR (no
   *      estimate yet), his condition, his morale or his own Wonderkid tag
   */
  it("shows a scouted player's report but not what the scout could not see", async () => {
    const player = rival();
    knowledge.current = {
      [player.id]: { kind: "scouted", scouted_on: "2026-09-01", current: true },
    };
    wages.current = { [player.id]: { kind: "approximate", weekly: 16_000 } };
    vi.mocked(invoke).mockImplementation(async (command: string) => {
      if (command === "get_scouted_report") {
        return {
          player_id: player.id,
          scouted_on: "2026-09-01",
          attributes: player.attributes,
          out_of_date: false,
        };
      }
      return defaultInvokeResponse(command);
    });

    renderProfile(player);

    await waitFor(() => {
      expect(screen.queryByText("playerProfile.attributesHidden")).not.toBeInTheDocument();
    });
    expect(screen.queryByText(/Wonderkid/)).not.toBeInTheDocument();
    expect(screen.queryByText("80%")).not.toBeInTheDocument();
    expect(screen.queryByText("77")).not.toBeInTheDocument();
    expect(contractWageValue()).toBe("about €16,000/wk");
    expect(screen.getAllByText("about €16K/wk").length).toBeGreaterThan(0);
    expect(showsMovementWage()).toBe(false);
  });

  /**
   * Given the club's own player
   * When his profile opens
   * Then his condition, morale and exact wage show; his own Wonderkid tag does not, as only the
   *      club's opinion of him tags him
   */
  it("shows the club's own player's private state but not his own Wonderkid tag", () => {
    const player = createPlayer({
      ovr: 77,
      condition: 80,
      morale: 75,
      traits: ["Wonderkid"],
      movement_history: rival().movement_history,
    });
    knowledge.current = { [player.id]: { kind: "own" } };

    render(<PlayerProfile player={player} gameState={createGameState(player)} isOwnClub />);

    expect(screen.getAllByText("80%").length).toBeGreaterThan(0);
    expect(screen.getAllByText("75%").length).toBeGreaterThan(0);
    expect(showsWage()).toBe(true);
    expect(contractWageValue()).not.toBe("–");
    expect(showsMovementWage()).toBe(true);
    expect(screen.getByText("77")).toBeInTheDocument();
    expect(screen.queryByText(/Wonderkid/)).not.toBeInTheDocument();
  });
});
