import { getPlayerOvr } from "../../lib/helpers";
import { useContractRiskLevels } from "../../hooks/useContractWarningStages";
import type { PlayerData, GameStateData } from "../../store/gameStore";
import { useTranslation } from "react-i18next";
import { Select } from "../ui";
import { getRoleOptions } from "../../lib/playerRoles";
import { getDeployedPosition } from "../squad/SquadTab.helpers";
import { setPlayerRole as setPlayerRoleService } from "../../services/squadService";
import type { PlayerRole } from "../../store/types";
import FreeAgentContractModal from "../transfers/FreeAgentContractModal";
import TransferBidModal from "../transfers/TransferBidModal";
import { useFreeAgentContractFlow } from "../transfers/useFreeAgentContractFlow";
import { useTransferBidFlow } from "../transfers/useTransferBidFlow";
import PlayerProfileActionsMenu from "./PlayerProfileActionsMenu";
import {
  formatPlayerWage,
  formatPlayerWageCompact,
  getPlayerTeamName,
} from "./PlayerProfile.helpers";
import { useVisibleWage } from "../../hooks/useVisibleWage";
import { answeredOr } from "../../hooks/useKnowledgeAnswer";
import ProfileLoadFailed from "./ProfileLoadFailed";
import { buildPlayerProfileRelationship } from "./PlayerProfile.viewModel";
import PlayerProfileAdvancedStatsCard from "./PlayerProfileAdvancedStatsCard";
import { buildPlayerAttributeGroups, isGoalkeeper } from "./PlayerProfile.attributes";
import { calcAgeOnDate } from "../../lib/valueFormatting";
import { formatDate } from "../../lib/dateFormatting";
import PlayerProfileAttributesCard from "./PlayerProfileAttributesCard";
import PlayerProfileCareerHistoryCard from "./PlayerProfileCareerHistoryCard";
import PlayerProfileContractCard from "./PlayerProfileContractCard";
import PlayerProfileHeroCard from "./PlayerProfileHeroCard";
import PlayerProfileInjuryBanner from "./PlayerProfileInjuryBanner";
import PlayerProfileLoanStatusBanner from "./PlayerProfileLoanStatusBanner";
import PlayerProfileMovementHistoryCard from "./PlayerProfileMovementHistoryCard";
import PlayerProfileRecentMatchesCard from "./PlayerProfileRecentMatchesCard";
import PlayerProfileRenewalModal from "./PlayerProfileRenewalModal";
import PlayerProfileSeasonStatsCard from "./PlayerProfileSeasonStatsCard";
import PlayerProfileTerminationModal from "./PlayerProfileTerminationModal";
import { useScoutedReport } from "./useScoutedReport";
import PlayerProfilePotentialOpinion from "./PlayerProfilePotentialOpinion";
import PlayerProfilePositionRatings from "./PlayerProfilePositionRatings";
import { usePositionRatings } from "../../hooks/usePositionRatings";
import { usePotentialOpinion } from "../../hooks/usePotentialOpinion";
import { useContractActionsFlow } from "./useContractActionsFlow";
import { useInitialModalIntent } from "./useInitialModalIntent";
import { usePlayerProfileData } from "./usePlayerProfileData";
import { useScoutPlayerFlow } from "./useScoutPlayerFlow";
import { useContractRenewalFlow } from "./useContractRenewalFlow";
import { naturalPositionOf } from "../../lib/positions";
import {
  gameKnowledgeRevision,
  HIDDEN_WAGE,
  knowsPlayerRating,
  knowsPrivateState,
  ownLineupRevision,
  visibleTraits,
  visibleWageText,
} from "../../lib/playerKnowledge";
import { usePlayerKnowledge } from "../../hooks/usePlayerKnowledge";

interface PlayerProfileProps {
  player: PlayerData;
  gameState: GameStateData;
  isOwnClub: boolean;
  startWithRenewalModal?: boolean;
  startWithTerminationModal?: boolean;
  onSelectTeam?: (id: string) => void;
  onGameUpdate?: (g: GameStateData) => void;
}

export default function PlayerProfile({
  player,
  gameState,
  isOwnClub,
  startWithRenewalModal = false,
  startWithTerminationModal = false,
  onSelectTeam,
  onGameUpdate,
}: PlayerProfileProps) {
  const { t, i18n } = useTranslation();
  const primaryPosition = naturalPositionOf(player);
  const footednessLabel = t(`common.footedness.${player.footedness || "Right"}`);
  const weakFootValue = player.weak_foot ?? 2;

  const { advancedStats, recentMatches } = usePlayerProfileData({
    player,
    currentDate: gameState.clock.current_date,
  });
  const { scoutAvailability, scoutStatus, scoutError, sendScout } = useScoutPlayerFlow({
    player,
    gameState,
    onGameUpdate,
  });
  const ovr = getPlayerOvr(player);
  const age = calcAgeOnDate(player.date_of_birth, gameState.clock.current_date);
  const revision = gameKnowledgeRevision(gameState, {
    playerClubId: player.team_id,
    wage: player.wage,
  });
  const knowledge = usePlayerKnowledge([player.id], revision)(player.id);
  // Each answer is loading, answered or failed; a failed one shows "Couldn't load" and a retry,
  // never the empty state that means the club knows nothing (#1108).
  const wageAnswer = useVisibleWage(player.id, revision);
  const visibleWage = answeredOr(wageAnswer, HIDDEN_WAGE);
  const wageRetry = wageAnswer.status === "failed" ? wageAnswer.retry : undefined;
  // The club's opinion of his potential: a range from his scout or his coaches, never the number.
  const opinionAnswer = usePotentialOpinion(player.id, revision);
  const potentialOpinion = answeredOr(opinionAnswer, null);
  // The slot he is played in moves with the lineup, which the knowledge revision does not follow.
  const ratingsAnswer = usePositionRatings(
    player.id,
    `${revision}|${ownLineupRevision(gameState)}`,
  );
  const positionRatings = answeredOr(ratingsAnswer, null);
  const showsPrivateState = knowsPrivateState(knowledge);
  const playerTeam = gameState.teams.find((team) => team.id === player.team_id);
  const currentTacticalRole: PlayerRole = playerTeam?.player_roles?.[player.id] ?? "Standard";
  // Offer roles for the deployed slot when the player is in the starting XI —
  // the backend validates set_player_role against it, so natural-position
  // roles would be rejected for an out-of-position starter (issue #272).
  const roleValidationPosition =
    (playerTeam && getDeployedPosition(playerTeam, player.id)) || primaryPosition;
  const tacticalRoleOptions = getRoleOptions(roleValidationPosition, currentTacticalRole);
  const teamName = getPlayerTeamName(gameState.teams, player.team_id, {
    freeAgent: t("common.freeAgent"),
    unknown: t("common.unknown"),
  });
  const contractRiskLevel = useContractRiskLevels(
    [player],
    gameState.clock.current_date,
  )(player.id);
  const contractRiskLabel =
    contractRiskLevel === "critical"
      ? t("finances.contractRiskCritical")
      : contractRiskLevel === "warning"
        ? t("finances.contractRiskWarning")
        : t("finances.contractRiskStable");
  const {
    managerTeamId,
    isManagerOwnedProfile,
    isManagerSquadProfile,
    isFreeAgent,
    hasLetExpireIntent,
    hasAssistantManager,
  } = buildPlayerProfileRelationship(player, gameState, isOwnClub);

  const {
    freeAgentTarget,
    contractWage,
    setContractWage,
    contractLength,
    setContractLength,
    contractFeedback,
    contractProjection,
    contractSubmitting,
    contractSubmitDisabled,
    contractStatusMessage,
    contractStatusClassName,
    openFreeAgentContract,
    closeFreeAgentContract,
    submitFreeAgentContract,
  } = useFreeAgentContractFlow({ gameState, onGameUpdate });

  const {
    bidTarget,
    bidAmount,
    setBidAmount,
    bidResult,
    bidLoading,
    bidFeedback,
    bidProjection,
    bidFee,
    activeBidOffer,
    myTeam,
    hasExistingOffer,
    talksResumeOn,
    bidSubmitDisabled,
    openBidNegotiation,
    closeBidNegotiation,
    handleMakeBid,
  } = useTransferBidFlow({ gameState, onGameUpdate });

  const {
    showRenewalModal,
    renewalWage,
    setRenewalWage,
    renewalLength,
    setRenewalLength,
    renewalSubmitting,
    renewalIsTerminal,
    renewalCooledOff,
    renewalFeedback,
    renewalProjection,
    isRenewalWageValid,
    renewalViolatesSoftCap,
    renewalSubmitDisabled,
    renewalStatusMessage,
    renewalStatusClassName,
    openRenewalModal,
    closeRenewalModal,
    handleRenewalSubmit,
    handleDelegateRenewal,
  } = useContractRenewalFlow({
    player,
    gameState,
    hasAssistantManager,
    onGameUpdate,
  });
  const scoutedReport = useScoutedReport(
    player.id,
    !isManagerSquadProfile,
    gameState.clock.current_date,
  );
  const attributesPlayer = scoutedReport
    ? { ...player, attributes: scoutedReport.attributes }
    : player;
  const attrGroups = buildPlayerAttributeGroups(attributesPlayer, t);

  const {
    contractActionSubmitting,
    contractActionError,
    setContractActionError,
    terminationPreview,
    showTerminationModal,
    handleMarkLetExpire,
    handleClearLetExpire,
    openTerminationModal,
    closeTerminationModal,
    handleTerminateContract,
  } = useContractActionsFlow({ player, onGameUpdate });

  // Both modals can be asked for on arrival, when the player reaches this
  // profile from an inbox action. One shared reset key, so switching player
  // re-arms both.
  const modalIntentResetKey = `${player.id}|${startWithRenewalModal}|${startWithTerminationModal}`;

  useInitialModalIntent({
    requested: startWithRenewalModal,
    allowed: isManagerOwnedProfile,
    isOpen: showRenewalModal,
    open: openRenewalModal,
    resetKey: modalIntentResetKey,
  });

  useInitialModalIntent({
    requested: startWithTerminationModal,
    allowed: isManagerOwnedProfile,
    isOpen: showTerminationModal,
    open: () => void openTerminationModal(),
    resetKey: modalIntentResetKey,
  });

  async function handleTacticalRoleChange(role: PlayerRole): Promise<void> {
    if (!onGameUpdate) return;
    try {
      const updated = await setPlayerRoleService(player.id, role);
      onGameUpdate(updated);
    } catch (error) {
      console.error("Failed to set player role:", error);
    }
  }

  return (
    <div>
      {onGameUpdate ? (
        <div className="mb-4 flex justify-end">
          <PlayerProfileActionsMenu
            player={player}
            gameState={gameState}
            isManagerOwnedProfile={isManagerOwnedProfile}
            isFreeAgent={isFreeAgent}
            hasLetExpireIntent={hasLetExpireIntent}
            contractRiskLevel={contractRiskLevel}
            actionSubmitting={contractActionSubmitting}
            onGameUpdate={onGameUpdate}
            onOpenRenewal={openRenewalModal}
            onMarkLetExpire={() => void handleMarkLetExpire()}
            onClearLetExpire={() => void handleClearLetExpire()}
            onOpenTermination={() => void openTerminationModal()}
            onOpenBid={() => openBidNegotiation(player)}
            onOpenFreeAgentContract={() => openFreeAgentContract(player)}
            onError={setContractActionError}
          />
        </div>
      ) : null}

      <PlayerProfileHeroCard
        player={player}
        ovr={knowsPlayerRating(knowledge) ? ovr : null}
        wageText={
          wageRetry
            ? t("playerProfile.loadFailed")
            : visibleWageText(visibleWage, formatPlayerWageCompact, t)
        }
        wageRetry={wageRetry}
        primaryPosition={primaryPosition}
        age={age}
        teamName={teamName}
        footednessLabel={footednessLabel}
        weakFootValue={weakFootValue}
        language={i18n.language}
        isOwnClub={isManagerSquadProfile || !onGameUpdate}
        scoutAvailability={scoutAvailability}
        scoutStatus={scoutStatus}
        scoutError={scoutError}
        onScout={sendScout}
        onSelectTeam={onSelectTeam}
        team={playerTeam}
        traits={visibleTraits(player.traits ?? [], potentialOpinion)}
        showsPrivateState={showsPrivateState}
        t={t}
      />

      {player.active_loan ? (
        <PlayerProfileLoanStatusBanner
          loan={player.active_loan}
          teams={gameState.teams}
          managerTeamId={managerTeamId}
          language={i18n.language}
          t={t}
        />
      ) : null}

      {/* Injury banner */}
      {player.injury ? <PlayerProfileInjuryBanner injury={player.injury} t={t} /> : null}

      {isOwnClub && onGameUpdate && (
        <div className="mb-4 flex items-center gap-3 rounded-panel border border-line bg-panel px-4 py-3">
          <span className="shrink-0 text-body font-medium text-fg-muted">
            {t("tactics.playerRoleLabel")}
          </span>
          <Select
            selectSize="sm"
            value={currentTacticalRole}
            onChange={(e) => {
              void handleTacticalRoleChange(e.target.value as PlayerRole);
            }}
            aria-label={t("tactics.playerRoleLabel")}
          >
            {tacticalRoleOptions.map((role) => (
              <option key={role} value={role}>
                {t(`tactics.playerRoles.${role}`, role)}
              </option>
            ))}
          </Select>
        </div>
      )}

      {/* Main content grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <PlayerProfileContractCard
          dateOfBirth={player.date_of_birth}
          contractEnd={player.contract_end}
          currentDate={gameState.clock.current_date}
          condition={showsPrivateState ? player.condition : null}
          morale={showsPrivateState ? player.morale : null}
          marketValue={player.market_value}
          wageText={
            wageRetry
              ? t("playerProfile.loadFailed")
              : visibleWageText(visibleWage, formatPlayerWage, t)
          }
          wageRetry={wageRetry}
          language={i18n.language}
          contractRiskLevel={contractRiskLevel}
          contractRiskLabel={contractRiskLabel}
          isOwnClub={isManagerOwnedProfile}
          isFreeAgent={isFreeAgent}
          hasLetExpireIntent={hasLetExpireIntent}
          actionSubmitting={contractActionSubmitting}
          onOpenRenewal={openRenewalModal}
          onMarkLetExpire={() => void handleMarkLetExpire()}
          onClearLetExpire={() => void handleClearLetExpire()}
          onOpenTermination={() => void openTerminationModal()}
          onOpenFreeAgentContract={() => openFreeAgentContract(player)}
          t={t}
        />

        {contractActionError ? (
          <div className="lg:col-span-3 rounded-control border bg-danger-tint px-4 py-3 text-body text-danger border-danger/50">
            {contractActionError}
          </div>
        ) : null}

        <PlayerProfileAttributesCard
          attrGroups={attrGroups}
          player={attributesPlayer}
          attributesVisible={knowsPlayerRating(knowledge) || scoutedReport !== null}
          scoutNote={
            scoutedReport
              ? {
                  scoutedLabel: t("playerProfile.scoutedOn", {
                    date: formatDate(scoutedReport.scouted_on, i18n.language),
                  }),
                  outOfDate: scoutedReport.out_of_date,
                  outOfDateLabel: t("playerProfile.scoutReportOutOfDate"),
                }
              : undefined
          }
          isGk={isGoalkeeper(player)}
          title={t("playerProfile.attributes")}
          averageLabel={t("common.average")}
          hiddenTitle={t("playerProfile.attributesHidden")}
          hiddenBody={t("playerProfile.scoutToView")}
          listLabel={t("common.listView")}
          radarLabel={t("common.radarView")}
          potentialOpinion={
            opinionAnswer.status === "failed" ? (
              <ProfileLoadFailed t={t} onRetry={opinionAnswer.retry} />
            ) : potentialOpinion ? (
              <PlayerProfilePotentialOpinion
                opinion={potentialOpinion}
                locale={i18n.language}
                t={t}
              />
            ) : null
          }
          positionRatings={
            ratingsAnswer.status === "failed" ? (
              <ProfileLoadFailed t={t} onRetry={ratingsAnswer.retry} />
            ) : positionRatings ? (
              <PlayerProfilePositionRatings
                ratings={positionRatings}
                locale={i18n.language}
                t={t}
              />
            ) : null
          }
        />
      </div>

      {/* Full-width data cards, stacked for a uniform page */}
      <div className="grid grid-cols-1 gap-5 mt-5">
        <PlayerProfileSeasonStatsCard
          stats={player.stats}
          seasonRatingRated={advancedStats.seasonRatingRated}
          t={t}
        />

        <PlayerProfileAdvancedStatsCard summary={advancedStats} t={t} />

        <PlayerProfileCareerHistoryCard career={player.career} t={t} />

        <PlayerProfileMovementHistoryCard
          movementHistory={player.movement_history ?? []}
          showsWages={visibleWage.kind === "exact"}
          t={t}
        />

        <PlayerProfileRecentMatchesCard matches={recentMatches} t={t} />
      </div>

      {bidTarget && (
        <TransferBidModal
          bidTarget={bidTarget}
          teams={gameState.teams}
          bidAmount={bidAmount}
          onBidAmountChange={setBidAmount}
          myTeam={myTeam}
          bidFee={bidFee}
          bidProjection={bidProjection}
          bidFeedback={bidFeedback}
          activeBidOffer={activeBidOffer}
          hasExistingOffer={hasExistingOffer}
          talksResumeOn={talksResumeOn}
          bidResult={bidResult}
          bidLoading={bidLoading}
          bidSubmitDisabled={bidSubmitDisabled}
          onSubmit={handleMakeBid}
          onClose={closeBidNegotiation}
        />
      )}
      {freeAgentTarget && (
        <FreeAgentContractModal
          player={freeAgentTarget}
          teams={gameState.teams}
          wage={contractWage}
          onWageChange={setContractWage}
          contractLength={contractLength}
          onContractLengthChange={setContractLength}
          projection={contractProjection}
          feedback={contractFeedback}
          statusMessage={contractStatusMessage(t)}
          statusClassName={contractStatusClassName}
          submitting={contractSubmitting}
          submitDisabled={contractSubmitDisabled}
          onSubmit={submitFreeAgentContract}
          onClose={closeFreeAgentContract}
        />
      )}

      <PlayerProfileRenewalModal
        show={showRenewalModal}
        playerName={player.full_name}
        t={t}
        renewalWage={renewalWage}
        renewalLength={renewalLength}
        renewalIsTerminal={renewalIsTerminal}
        isRenewalWageValid={isRenewalWageValid}
        renewalViolatesSoftCap={renewalViolatesSoftCap}
        renewalProjection={renewalProjection}
        renewalStatusMessage={renewalStatusMessage}
        renewalStatusClassName={renewalStatusClassName}
        renewalCooledOff={renewalCooledOff}
        renewalFeedback={renewalFeedback}
        renewalSubmitDisabled={renewalSubmitDisabled}
        delegateRenewalDisabled={!hasAssistantManager || renewalSubmitting}
        onWageChange={setRenewalWage}
        onLengthChange={setRenewalLength}
        onClose={closeRenewalModal}
        onDelegate={() => void handleDelegateRenewal()}
        onSubmit={() => void handleRenewalSubmit()}
      />

      <PlayerProfileTerminationModal
        show={showTerminationModal}
        playerName={player.full_name}
        t={t}
        preview={terminationPreview}
        errorMessage={contractActionError}
        submitting={contractActionSubmitting}
        onCancel={closeTerminationModal}
        onConfirm={() => void handleTerminateContract()}
      />
    </div>
  );
}
