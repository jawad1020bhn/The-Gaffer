import type { SquadFitness } from "../../services/squadService";
import type { PositionTable } from "../../lib/positionTable";
import type { FixtureData, GameStateData, PlayerData, TeamData } from "../../store/gameStore";
import { formatVal } from "../../lib/helpers";
import { competitionDisplayName } from "../../lib/competitionName";
import { getAllFixturesAcrossCompetitions } from "../../lib/fixtures";
import { getActiveCompetitions } from "../../lib/helpers";
import type { TeamFinanceSnapshotData } from "../../services/financeService";
import { buildStartingXIIds } from "../squad/SquadTab.helpers";
import { isMessageVisible } from "../../utils/newsVisibility";

export interface DashboardAlert {
  id: string;
  text: string;
  tab: string;
  severity: "warn" | "info";
}

export interface DashboardSearchResults {
  matchedPlayers: PlayerData[];
  matchedTeams: TeamData[];
}

type DashboardAlertTranslator = (key: string, options?: Record<string, unknown>) => string;
type DashboardFinanceVerdict = Pick<
  TeamFinanceSnapshotData,
  | "cashRunwayWeeks"
  | "currentlyInDebt"
  | "runwayStatus"
  | "wageBudgetStatus"
  | "wageBudgetUsagePercent"
>;

export function getTodayMatchFixture(gameState: GameStateData): FixtureData | null {
  const fixtures = getAllFixturesAcrossCompetitions(gameState);
  const today = gameState.clock.current_date.split("T")[0];

  return (
    fixtures.find((fixture) => {
      return (
        fixture.date === today &&
        fixture.status === "Scheduled" &&
        (fixture.home_team_id === gameState.manager.team_id ||
          fixture.away_team_id === gameState.manager.team_id)
      );
    }) ?? null
  );
}

export function getUnreadMessagesCount(gameState: GameStateData): number {
  return gameState.messages.filter(
    (message) => !message.read && isMessageVisible(message.date, gameState.clock?.current_date),
  ).length;
}

/**
 * The name of the competition the club's standing is in, for the always-visible sidebar. Which
 * competition counts is the backend's call (it ships the standing); this only picks the wording:
 * the translated display name when the game carries that competition, else the backend's own name.
 */
export function clubCompetitionLabel(
  gameState: GameStateData,
  standing: { competition_id: string; competition_name: string } | null,
  t: DashboardAlertTranslator,
): string | null {
  if (!standing) {
    return null;
  }

  const competition = getActiveCompetitions(gameState).find(
    (candidate) => candidate.id === standing.competition_id,
  );

  return competition ? competitionDisplayName(competition, t) : standing.competition_name || null;
}

export function getManagerTeamName(gameState: GameStateData): string | null {
  return gameState.teams.find((team) => team.id === gameState.manager.team_id)?.name ?? null;
}

export function getDashboardSearchResults(
  gameState: GameStateData,
  query: string,
): DashboardSearchResults {
  const normalizedQuery = query.trim().toLowerCase();

  if (normalizedQuery.length < 2) {
    return {
      matchedPlayers: [],
      matchedTeams: [],
    };
  }

  return {
    matchedPlayers: gameState.players
      .filter((player) => {
        return (
          player.full_name.toLowerCase().includes(normalizedQuery) ||
          player.match_name.toLowerCase().includes(normalizedQuery)
        );
      })
      .slice(0, 5),
    matchedTeams: gameState.teams
      .filter((team) => {
        return (
          team.name.toLowerCase().includes(normalizedQuery) ||
          team.short_name.toLowerCase().includes(normalizedQuery)
        );
      })
      .slice(0, 4),
  };
}

export function getDashboardAlerts(
  gameState: GameStateData,
  positionTable: PositionTable,
  hasMatchToday: boolean,
  t: DashboardAlertTranslator,
  financeSnapshot?: DashboardFinanceVerdict | null,
  fitness?: SquadFitness | null,
): DashboardAlert[] {
  const alerts: DashboardAlert[] = [];
  const myTeam = gameState.teams.find((team) => team.id === gameState.manager.team_id);
  const roster = myTeam ? gameState.players.filter((player) => player.team_id === myTeam.id) : [];
  // Players in a critical state, as the backend counts them (injured players are not in the squad
  // that can play).
  const exhaustedCount = fitness?.critical_count ?? 0;
  const urgentUnreadCount = gameState.messages.filter((message) => {
    return (
      !message.read &&
      message.priority === "Urgent" &&
      isMessageVisible(message.date, gameState.clock?.current_date)
    );
  }).length;
  const savedStartingXi = myTeam?.starting_xi_ids ?? [];
  const effectiveStartingXi = myTeam
    ? buildStartingXIIds(roster, savedStartingXi, myTeam.formation, positionTable)
    : [];
  const xiPlayersOnRoster = effectiveStartingXi.filter((playerId) => {
    return roster.some((player) => player.id === playerId);
  });
  const injuredInXiCount = xiPlayersOnRoster.filter((playerId) => {
    return roster.find((player) => player.id === playerId)?.injury;
  }).length;
  const healthyXiCount = xiPlayersOnRoster.length - injuredInXiCount;

  if (exhaustedCount >= 3) {
    alerts.push({
      id: "exhausted",
      text: t("dashboard.alerts.exhausted", { count: exhaustedCount }),
      tab: "Training",
      severity: "warn",
    });
  }

  if (savedStartingXi.length > 0) {
    if (injuredInXiCount > 0) {
      alerts.push({
        id: "injured_xi",
        text: t("dashboard.alerts.injuredStartingXi", {
          count: injuredInXiCount,
        }),
        tab: "Squad",
        severity: "warn",
      });
    }

    if (healthyXiCount < 11 && injuredInXiCount === 0 && roster.length >= 11) {
      alerts.push({
        id: "xi",
        text: t("dashboard.alerts.incompleteStartingXi"),
        tab: "Squad",
        severity: "warn",
      });
    }
  }

  if (urgentUnreadCount > 0) {
    alerts.push({
      id: "urgent",
      text: t("dashboard.alerts.urgentUnread", { count: urgentUnreadCount }),
      tab: "Inbox",
      severity: "warn",
    });
  }

  if (myTeam && financeSnapshot) {
    if (financeSnapshot.currentlyInDebt || financeSnapshot.runwayStatus === "critical") {
      alerts.push({
        id: "finance_crisis",
        text: t("dashboard.alerts.financeCrisis", {
          balance: formatVal(myTeam.finance),
          weeks: financeSnapshot.cashRunwayWeeks ?? 0,
        }),
        tab: "Finances",
        severity: "warn",
      });
    } else if (financeSnapshot.runwayStatus === "warning") {
      alerts.push({
        id: "finance_runway",
        text: t("dashboard.alerts.financeRunway", {
          count: financeSnapshot.cashRunwayWeeks,
        }),
        tab: "Finances",
        severity: "warn",
      });
    }

    if (
      financeSnapshot.wageBudgetStatus === "warning" ||
      financeSnapshot.wageBudgetStatus === "critical"
    ) {
      alerts.push({
        id: "wage_pressure",
        text: t("dashboard.alerts.wagePressure", {
          percent: financeSnapshot.wageBudgetUsagePercent,
        }),
        tab: "Finances",
        severity: "warn",
      });
    }
  }

  if (hasMatchToday && savedStartingXi.length > 0 && healthyXiCount < 11) {
    alerts.push({
      id: "matchxi",
      text: t("dashboard.alerts.matchTodayStartingXi"),
      tab: "Squad",
      severity: "warn",
    });
  }

  return alerts;
}
