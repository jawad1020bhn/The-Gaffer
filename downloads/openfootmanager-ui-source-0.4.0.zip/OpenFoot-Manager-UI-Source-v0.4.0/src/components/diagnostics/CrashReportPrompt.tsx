import { useCallback, useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { AlertTriangle } from "lucide-react";

import { formatDate } from "../../lib/dateFormatting";
import { logError } from "../../lib/logger";
import { type CrashNotice, crashNotice, dismissCrashNotice } from "../../services/reportService";
import { Button, Dialog } from "../ui";

interface CrashReportPromptProps {
  onReport: () => void;
}

/**
 * The crash record only survives until this session ends, so the main menu asks once. Either answer
 * is final for this launch: the backend clears the crash file at startup.
 */
export function CrashReportPrompt({ onReport }: CrashReportPromptProps) {
  const [notice, setNotice] = useState<CrashNotice | null>(null);

  useEffect(() => {
    let cancelled = false;
    void crashNotice()
      .then((pending) => {
        if (!cancelled) setNotice(pending ?? null);
      })
      .catch((error: unknown) => {
        // A prompt is a courtesy. Failing to offer it must not get in front of the menu.
        logError(`[report] could not read the crash notice: ${String(error)}`);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const answer = useCallback(
    (report: boolean) => {
      setNotice(null);
      void dismissCrashNotice().catch((error: unknown) => {
        logError(`[report] could not record the crash prompt answer: ${String(error)}`);
      });
      if (report) onReport();
    },
    [onReport],
  );

  if (notice === null) return null;
  return <CrashPromptDialog notice={notice} onAnswer={answer} />;
}

/** Split out so its focus handling starts when the dialog appears, not when the menu mounts. */
function CrashPromptDialog({
  notice,
  onAnswer,
}: {
  notice: CrashNotice;
  onAnswer: (report: boolean) => void;
}) {
  const { t, i18n } = useTranslation();
  const headingRef = useRef<HTMLHeadingElement>(null);
  const decline = useCallback(() => onAnswer(false), [onAnswer]);

  useEffect(() => {
    headingRef.current?.focus();
  }, []);

  return (
    <Dialog
      labelledBy="crash-prompt-title"
      describedBy="crash-prompt-body"
      onClose={decline}
      className="w-full max-w-md rounded-panel p-6"
    >
      <div className="flex items-start gap-3">
        <span className="text-warning shrink-0 mt-0.5">
          <AlertTriangle className="w-5 h-5" aria-hidden="true" />
        </span>
        <div className="flex-1 min-w-0">
          <h2
            id="crash-prompt-title"
            ref={headingRef}
            tabIndex={-1}
            className="font-heading font-bold uppercase tracking-label text-title text-fg focus:outline-none"
          >
            {t("crashPrompt.title")}
          </h2>
          <p id="crash-prompt-body" className="mt-2 text-body text-fg">
            {t("crashPrompt.body")}
          </p>
          <p className="mt-2 text-caption font-mono text-fg-muted">
            <time dateTime={notice.occurred_at}>
              {formatDate(notice.occurred_at, i18n.language)}
            </time>
            {notice.app_version !== "" && ` · v${notice.app_version}`}
          </p>
        </div>
      </div>
      <div className="flex gap-3 mt-6">
        <Button className="flex-1" onClick={() => onAnswer(true)}>
          {t("crashPrompt.report")}
        </Button>
        <Button variant="outline" onClick={decline}>
          {t("crashPrompt.notNow")}
        </Button>
      </div>
    </Dialog>
  );
}
