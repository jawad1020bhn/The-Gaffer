import { describe, expect, it } from "vitest";
import type { PlayerData } from "../../store/gameStore";
import { createPositionTable } from "../../lib/positionTable";
import type { FamiliarityTable } from "../../hooks/useFamiliarity";
import type { Familiarity } from "../../store/generated/Familiarity";
import { pendingFamiliarityTable } from "../../test-utils/familiarity";
import { cannedPositionTable } from "../../test-utils/positionTable";
import {
  applyLineupDrop,
  buildAssignBestFitSlot,
  applyLineupSwap,
  buildActivePositionMap,
  buildDemoteFromStartingXi,
  buildRoleCoverageSummary,
  getBestRoleForFormation,
  getCurrentPosition,
  getDeployedPosition,
  buildPitchRows,
  buildPitchSlotRows,
  buildPromoteToStartingXi,
  buildStartingXIIds,
  getSquadTacticalFit,
  lineupReady,
  getPitchSlotWidth,
  getPreferredPositions,
  isPlayerOutOfPosition,
  parseFormationSlots,
  positionCode,
  translatePositionAbbreviation,
} from "./SquadTab.helpers";

const makePlayer = (
  id: string,
  position: string,
  overrides: Partial<PlayerData> = {},
): PlayerData => ({
  id,
  match_name: id,
  full_name: `Player ${id}`,
  date_of_birth: "1998-01-01",
  nationality: "GB",
  position,
  natural_position: position,
  alternate_positions: [],
  training_focus: null,
  attributes: {
    pace: 60,
    stamina: 60,
    strength: 60,
    agility: 60,
    passing: 60,
    shooting: 60,
    tackling: 60,
    dribbling: 60,
    defending: 60,
    positioning: 60,
    vision: 60,
    decisions: 60,
    composure: 60,
    aggression: 60,
    teamwork: 60,
    leadership: 60,
    handling: 60,
    reflexes: 60,
    aerial: 60,
  },
  condition: 100,
  morale: 80,
  injury: null,
  match_day_eligible: true,
  team_id: "team1",
  retired: false,
  contract_end: "2027-06-30",
  wage: 1000,
  market_value: 100000,
  stats: {
    appearances: 0,
    goals: 0,
    assists: 0,
    clean_sheets: 0,
    yellow_cards: 0,
    red_cards: 0,
    avg_rating: 0,
    minutes_played: 0,
  },
  career: [],
  transfer_listed: false,
  loan_listed: false,
  transfer_offers: [],
  traits: [],
  ...overrides,
});

describe("SquadTab helpers", () => {
  it("normalises detailed positions into core roles", () => {
    expect(cannedPositionTable().groupOf("Center Back")).toBe("Defender");
    expect(cannedPositionTable().groupOf("Winger")).toBe("Forward");
    expect(cannedPositionTable().groupOf("Striker")).toBe("Forward");
    expect(cannedPositionTable().groupOf("Goalkeeper")).toBe("Goalkeeper");
  });

  it("builds preferred positions using normalised natural and alternate roles", () => {
    const player = makePlayer("p1", "Center Back", {
      natural_position: "Center Back",
      alternate_positions: ["Right Wing Back", "Defensive Midfielder"],
    });

    expect(getPreferredPositions(player)).toEqual([
      "CenterBack",
      "RightWingBack",
      "DefensiveMidfielder",
    ]);
  });

  it("detects out-of-position status using normalised roles", () => {
    const defender = makePlayer("p1", "Center Back", {
      natural_position: "Center Back",
      alternate_positions: ["Right Wing Back"],
    });

    expect(isPlayerOutOfPosition(defender, "Defender", cannedPositionTable())).toBe(false);
    expect(isPlayerOutOfPosition(defender, "Midfielder", cannedPositionTable())).toBe(true);
  });

  /**
   * Given a natural right winger with no alternates
   * When the screens grade him at right midfield and at left midfield
   * Then right midfield, his own flank one line back, is a position he can play, and left
   *      midfield is out of position: the backend's `is_flank_partner`
   */
  it("treats a winger at wide midfield on his own flank as a position he can play", () => {
    const winger = makePlayer("p1", "RightWinger", {
      natural_position: "RightWinger",
      alternate_positions: [],
    });

    expect(isPlayerOutOfPosition(winger, "RightMidfielder", cannedPositionTable())).toBe(false);
    expect(isPlayerOutOfPosition(winger, "LeftMidfielder", cannedPositionTable())).toBe(true);
  });

  it("parses 4-part formations correctly", () => {
    expect(parseFormationSlots("4-2-3-1")).toEqual({ def: 4, mid: 5, fwd: 1 });
  });

  it("builds five pitch rows for 4-part formations", () => {
    const rows = buildPitchRows("4-2-3-1");
    expect(rows.map((row) => row.label)).toEqual(["GK", "DEF", "DM", "AM", "FWD"]);
    expect(rows[1].positions).toHaveLength(4);
    expect(rows[2].positions).toHaveLength(2);
    expect(rows[3].positions).toHaveLength(3);
    expect(rows[4].positions).toHaveLength(1);
    expect(rows[1].positions).toEqual(["LeftBack", "CenterBack", "CenterBack", "RightBack"]);
  });

  it("keeps wide side-specific roles in left-to-right pitch order across formations", () => {
    expect(buildPitchRows("4-4-2")[2].positions).toEqual([
      "LeftMidfielder",
      "CentralMidfielder",
      "CentralMidfielder",
      "RightMidfielder",
    ]);
    expect(buildPitchRows("5-3-2")[1].positions).toEqual([
      "LeftWingBack",
      "CenterBack",
      "CenterBack",
      "CenterBack",
      "RightWingBack",
    ]);
    expect(buildPitchRows("4-2-3-1")[3].positions).toEqual([
      "LeftMidfielder",
      "AttackingMidfielder",
      "RightMidfielder",
    ]);
    expect(buildPitchRows("4-3-3")[3].positions).toEqual(["LeftWinger", "Striker", "RightWinger"]);
  });

  it("returns compact pitch widths for crowded rows", () => {
    expect(getPitchSlotWidth(5)).toBeLessThan(getPitchSlotWidth(3));
    expect(getPitchSlotWidth(1)).toBeGreaterThan(getPitchSlotWidth(4));
  });

  it("prefers persisted starting XI ids when enough valid players remain", () => {
    const available = [
      makePlayer("gk", "Goalkeeper"),
      makePlayer("d1", "Defender"),
      makePlayer("d2", "Defender"),
      makePlayer("d3", "Defender"),
      makePlayer("d4", "Defender"),
      makePlayer("m1", "Midfielder"),
      makePlayer("m2", "Midfielder"),
      makePlayer("m3", "Midfielder"),
      makePlayer("m4", "Midfielder"),
      makePlayer("f1", "Forward"),
      makePlayer("f2", "Forward"),
      makePlayer("b1", "Forward"),
    ];

    const ids = buildStartingXIIds(
      available,
      ["gk", "d1", "d2", "d3", "d4", "m1", "m2", "m3", "m4", "f1", "f2"],
      "4-4-2",
      cannedPositionTable(),
    );

    expect(ids).toEqual(["gk", "d1", "d2", "d3", "d4", "m1", "m2", "m3", "m4", "f1", "f2"]);
  });

  it("auto-selects players by formation role when persisted ids are missing", () => {
    const available = [
      makePlayer("gk", "Goalkeeper"),
      makePlayer("d1", "Defender"),
      makePlayer("d2", "Defender"),
      makePlayer("d3", "Defender"),
      makePlayer("d4", "Defender"),
      makePlayer("m1", "Midfielder"),
      makePlayer("m2", "Midfielder"),
      makePlayer("m3", "Midfielder"),
      makePlayer("m4", "Midfielder"),
      makePlayer("f1", "Forward"),
      makePlayer("f2", "Forward"),
    ];

    const ids = buildStartingXIIds(available, [], "4-4-2", cannedPositionTable());

    expect(ids).toHaveLength(11);
    expect(ids[0]).toBe("gk");
    expect(ids.slice(1, 5)).toEqual(["d1", "d2", "d3", "d4"]);
  });

  /**
   * Given a squad of twelve and a saved XI of which only three are still in it (fewer than eight,
   *       so the XI is rebuilt from the pool)
   * When the starting XI is built
   * Then it has eleven different players. The three kept ids used to be reserved and then left
   *      out of the rebuilt XI, so only the nine others were left to pick from: a nine-man XI.
   */
  it("rebuilds a full XI when fewer than eight saved players remain", () => {
    const available = Array.from({ length: 12 }, (_, index) =>
      makePlayer(`p${index}`, "Midfielder"),
    );

    const ids = buildStartingXIIds(available, ["p0", "p1", "p2"], "4-4-2", cannedPositionTable());

    expect(ids).toHaveLength(11);
    expect(new Set(ids).size).toBe(11);
  });

  /**
   * Given a squad of twenty whose only goalkeeper is one of three saved players still in it
   * When the starting XI is rebuilt from the pool (fewer than eight saved)
   * Then that goalkeeper is in goal: a saved player is not barred from the rebuild, in a squad
   *      big enough that barring him would not change the count.
   */
  it("rebuilds from the whole pool, saved players included", () => {
    const available = [
      makePlayer("gk", "Goalkeeper"),
      ...Array.from({ length: 19 }, (_, index) => makePlayer(`m${index}`, "Midfielder")),
    ];

    const ids = buildStartingXIIds(available, ["gk", "m0", "m1"], "4-4-2", cannedPositionTable());

    expect(ids[0]).toBe("gk");
  });

  it("prefers an exact slot match over a higher-ovr same-group player", () => {
    const available = [
      makePlayer("gk", "Goalkeeper"),
      makePlayer("lb", "Left Back", {
        natural_position: "Left Back",
        attributes: {
          pace: 55,
          stamina: 55,
          strength: 55,
          agility: 55,
          passing: 55,
          shooting: 40,
          tackling: 68,
          dribbling: 50,
          defending: 68,
          positioning: 62,
          vision: 52,
          decisions: 58,
          composure: 56,
          aggression: 58,
          teamwork: 60,
          leadership: 50,
          handling: 10,
          reflexes: 10,
          aerial: 10,
        },
      }),
      makePlayer("cb1", "Center Back", {
        natural_position: "Center Back",
        attributes: {
          pace: 70,
          stamina: 70,
          strength: 74,
          agility: 62,
          passing: 62,
          shooting: 42,
          tackling: 78,
          dribbling: 52,
          defending: 80,
          positioning: 74,
          vision: 58,
          decisions: 70,
          composure: 68,
          aggression: 71,
          teamwork: 68,
          leadership: 60,
          handling: 10,
          reflexes: 10,
          aerial: 10,
        },
      }),
      makePlayer("cb2", "Center Back"),
      makePlayer("rb", "Right Back", { natural_position: "Right Back" }),
      makePlayer("m1", "Midfielder"),
      makePlayer("m2", "Midfielder"),
      makePlayer("m3", "Midfielder"),
      makePlayer("m4", "Midfielder"),
      makePlayer("f1", "Forward"),
      makePlayer("f2", "Forward"),
    ];

    const ids = buildStartingXIIds(available, [], "4-4-2", cannedPositionTable());

    expect(ids[1]).toBe("lb");
  });

  it("builds pitch slot rows and active position map from xi ids", () => {
    const players = [
      makePlayer("gk", "Goalkeeper"),
      makePlayer("d1", "LeftBack"),
      makePlayer("d2", "CenterBack"),
      makePlayer("d3", "CenterBack"),
      makePlayer("d4", "RightBack"),
      makePlayer("m1", "LeftMidfielder"),
      makePlayer("m2", "CentralMidfielder"),
      makePlayer("m3", "CentralMidfielder"),
      makePlayer("m4", "RightMidfielder"),
      makePlayer("f1", "Striker"),
      makePlayer("f2", "Striker"),
    ];
    const xiIds = players.map((player) => player.id);
    const rows = buildPitchRows("4-4-2");
    const slotRows = buildPitchSlotRows(rows, xiIds, new Map(players.map((p) => [p.id, p])));
    const activeMap = buildActivePositionMap(slotRows);

    expect(slotRows[0].slots[0].player?.id).toBe("gk");
    expect(activeMap.get("d1")).toBe("LeftBack");
    expect(activeMap.get("m1")).toBe("LeftMidfielder");
    expect(activeMap.get("f2")).toBe("Striker");
  });

  it("preserves saved xi order for side-specific wide roles", () => {
    const available = [
      makePlayer("gk", "Goalkeeper"),
      makePlayer("rb", "RightBack", {
        natural_position: "RightBack",
        footedness: "Right",
        weak_foot: 1,
      }),
      makePlayer("cb1", "CenterBack"),
      makePlayer("cb2", "CenterBack"),
      makePlayer("lb", "LeftBack", {
        natural_position: "LeftBack",
        footedness: "Left",
        weak_foot: 1,
      }),
      makePlayer("rm", "RightMidfielder", {
        natural_position: "RightMidfielder",
        footedness: "Right",
        weak_foot: 1,
      }),
      makePlayer("cm1", "CentralMidfielder"),
      makePlayer("cm2", "CentralMidfielder"),
      makePlayer("lm", "LeftMidfielder", {
        natural_position: "LeftMidfielder",
        footedness: "Left",
        weak_foot: 1,
      }),
      makePlayer("st1", "Striker"),
      makePlayer("st2", "Striker"),
    ];

    const ids = buildStartingXIIds(
      available,
      ["gk", "rb", "cb1", "cb2", "lb", "rm", "cm1", "cm2", "lm", "st1", "st2"],
      "4-4-2",
      cannedPositionTable(),
    );

    expect(ids).toEqual(["gk", "rb", "cb1", "cb2", "lb", "rm", "cm1", "cm2", "lm", "st1", "st2"]);
  });

  it("swaps XI players when dragging from one slot to another", () => {
    const nextXiIds = applyLineupDrop(
      ["gk", "d1", "d2", "d3"],
      { playerId: "d1", from: "xi", slotIndex: 1 },
      3,
    );

    expect(nextXiIds).toEqual(["gk", "d3", "d2", "d1"]);
  });

  it("replaces the target slot when dropping a bench player onto the pitch", () => {
    const nextXiIds = applyLineupDrop(
      ["gk", "d1", "d2", "d3"],
      { playerId: "b1", from: "bench", slotIndex: null },
      2,
    );

    expect(nextXiIds).toEqual(["gk", "d1", "b1", "d3"]);
  });

  it("keeps order stable when a dragged bench player is already present in the xi", () => {
    const nextXiIds = applyLineupDrop(
      ["gk", "d1", "b1", "d3"],
      { playerId: "b1", from: "bench", slotIndex: null },
      1,
    );

    expect(nextXiIds).toEqual(["gk", "b1", "d1", "d3"]);
  });

  it("supports bench-to-xi and xi-to-xi swap actions", () => {
    expect(applyLineupSwap(["gk", "d1", "d2"], { id: "b1", from: "bench" }, "d2", "xi")).toEqual([
      "gk",
      "d1",
      "b1",
    ]);

    expect(applyLineupSwap(["gk", "d1", "d2"], { id: "d1", from: "xi" }, "d2", "xi")).toEqual([
      "gk",
      "d2",
      "d1",
    ]);
  });

  it("returns core position codes", () => {
    expect(positionCode("Center Back")).toBe("CB");
    expect(positionCode("Striker")).toBe("ST");
  });

  it("translates normalized position abbreviations with fallback codes", () => {
    const translate = (key: string): string => key;

    expect(translatePositionAbbreviation(translate, "Center Back")).toBe(
      "common.posAbbr.CenterBack",
    );
    expect(translatePositionAbbreviation(translate, "Striker")).toBe("common.posAbbr.Striker");
  });

  it("classifies tactical fit as natural, adapted, or out", () => {
    expect(
      getSquadTacticalFit(
        makePlayer("lb", "Left Back", { natural_position: "Left Back" }),
        "LeftBack",
        cannedPositionTable(),
      ),
    ).toBe("natural");

    // A player still on the coarse "Defender" is graded as a centre back, as the backend reads him.
    expect(
      getSquadTacticalFit(
        makePlayer("def", "Defender", { natural_position: "Defender" }),
        "CenterBack",
        cannedPositionTable(),
      ),
    ).toBe("natural");

    expect(
      getSquadTacticalFit(
        makePlayer("def2", "Defender", { natural_position: "Defender" }),
        "LeftBack",
        cannedPositionTable(),
      ),
    ).toBe("adapted");

    expect(
      getSquadTacticalFit(
        makePlayer("fwd", "Forward", { natural_position: "Forward" }),
        "CenterBack",
        cannedPositionTable(),
      ),
    ).toBe("out");
  });

  /**
   * Given a bench player the backend has not made eligible (an injury, say)
   * When he is promoted
   * Then nothing changes; and an injured player the backend fields in a crisis is promoted.
   */
  it("promotes only a bench player the backend has made eligible", () => {
    const xi = ["gk", "d1", "d2", "d3", "d4", "m1", "m2", "m3", "m4", "f1", "f2"];
    const base = [
      makePlayer("gk", "Goalkeeper"),
      makePlayer("d1", "Defender"),
      makePlayer("d2", "Defender"),
      makePlayer("d3", "Defender"),
      makePlayer("d4", "Defender"),
      makePlayer("m1", "Midfielder"),
      makePlayer("m2", "Midfielder"),
      makePlayer("m3", "Midfielder"),
      makePlayer("m4", "Midfielder"),
      makePlayer("f1", "Forward"),
      makePlayer("f2", "Forward"),
    ];
    const injured = { name: "Hamstring strain", days_remaining: 7 };
    const withBench = (bench: PlayerData) => new Map([...base, bench].map((p) => [p.id, p]));

    const refused = buildPromoteToStartingXi(
      xi,
      withBench(makePlayer("d5", "Defender", { injury: injured, match_day_eligible: false })),
      "4-4-2",
      "d5",
      cannedPositionTable(),
    );
    const fielded = buildPromoteToStartingXi(
      xi,
      withBench(makePlayer("d5", "Defender", { injury: injured, match_day_eligible: true })),
      "4-4-2",
      "d5",
      cannedPositionTable(),
    );

    expect(refused).toBeNull();
    expect(fielded).not.toBeNull();
    expect(fielded).toContain("d5");
  });

  it("promotes a bench player into the slot that fits them best", () => {
    const players = [
      makePlayer("gk", "Goalkeeper"),
      makePlayer("d1", "Defender"),
      makePlayer("d2", "Defender"),
      makePlayer("d3", "Defender"),
      makePlayer("d4", "Defender"),
      makePlayer("m1", "Midfielder"),
      makePlayer("m2", "Midfielder"),
      makePlayer("m3", "Midfielder"),
      makePlayer("m4", "Midfielder"),
      makePlayer("f1", "Forward"),
      makePlayer("f2", "Forward"),
      makePlayer("lb", "Left Back", { natural_position: "Left Back" }),
    ];
    const playersById = new Map(players.map((player) => [player.id, player]));

    expect(
      buildPromoteToStartingXi(
        ["gk", "d1", "d2", "d3", "d4", "m1", "m2", "m3", "m4", "f1", "f2"],
        playersById,
        "4-4-2",
        "lb",
        cannedPositionTable(),
      ),
    ).toEqual(["gk", "lb", "d2", "d3", "d4", "m1", "m2", "m3", "m4", "f1", "f2"]);
  });

  it("demotes a starter by replacing them with the best bench fit for the slot", () => {
    const players = [
      makePlayer("gk", "Goalkeeper"),
      makePlayer("d1", "Defender"),
      makePlayer("d2", "Defender"),
      makePlayer("d3", "Defender"),
      makePlayer("d4", "Defender"),
      makePlayer("m1", "Midfielder"),
      makePlayer("m2", "Midfielder"),
      makePlayer("m3", "Midfielder"),
      makePlayer("m4", "Midfielder"),
      makePlayer("f1", "Forward"),
      makePlayer("f2", "Forward"),
      makePlayer("lb", "Left Back", { natural_position: "Left Back" }),
    ];

    expect(
      buildDemoteFromStartingXi(
        ["gk", "d1", "d2", "d3", "d4", "m1", "m2", "m3", "m4", "f1", "f2"],
        players,
        "4-4-2",
        "d1",
        cannedPositionTable(),
      ),
    ).toEqual(["gk", "lb", "d2", "d3", "d4", "m1", "m2", "m3", "m4", "f1", "f2"]);
  });

  it("suggests a best role within the current formation shape", () => {
    expect(
      getBestRoleForFormation(
        makePlayer("lb", "Left Back", { natural_position: "Left Back" }),
        "4-4-2",
        cannedPositionTable(),
      ),
    ).toBe("LeftBack");

    expect(
      getBestRoleForFormation(
        makePlayer("mid", "Midfielder", { natural_position: "Midfielder" }),
        "4-2-3-1",
        cannedPositionTable(),
      ),
    ).toBe("CentralMidfielder");
  });

  it("prefers the natural position group over a tangential alternate", () => {
    // A DM with RB among alternates in a DM-less formation must resolve to a
    // midfield role, not jump across groups to RightBack.
    expect(
      getBestRoleForFormation(
        makePlayer("dm", "Defensive Midfielder", {
          natural_position: "Defensive Midfielder",
          alternate_positions: ["Right Back"],
        }),
        "4-4-2",
        cannedPositionTable(),
      ),
    ).toBe("CentralMidfielder");

    // The alternate is still used when no role in the player's own group fits.
    expect(
      getBestRoleForFormation(
        makePlayer("st", "Striker", {
          natural_position: "Striker",
          alternate_positions: ["Right Back"],
        }),
        "4-0-0",
        cannedPositionTable(),
      ),
    ).toBe("RightBack");
  });

  it("getCurrentPosition returns the assigned slot for XI players, natural otherwise", () => {
    const xiActivePosition = new Map<string, string>([["p1", "RightBack"]]);
    // A natural striker fielded at right-back reads as RightBack (his slot).
    const starter = makePlayer("p1", "Striker", { natural_position: "Striker" });
    expect(getCurrentPosition(starter, xiActivePosition)).toBe("RightBack");

    // A bench player (absent from the map) reads as his natural position.
    const benchPlayer = makePlayer("p2", "Forward", {
      natural_position: "Left Winger",
    });
    expect(getCurrentPosition(benchPlayer, xiActivePosition)).toBe("Left Winger");
  });

  // Parity guard: the TS pitch layout MUST match the Rust formation_slots layout
  // (src-tauri/crates/ofm_core/src/player_rating.rs tests). The backend role
  // validator and match engine resolve a player's slot from that ordering, so a
  // divergence here reintroduces the issue-#257 desync.
  it("buildPitchRows slot order matches the Rust formation_slots layout", () => {
    const slots = (formation: string) => buildPitchRows(formation).flatMap((row) => row.positions);

    expect(slots("4-4-2")).toEqual([
      "Goalkeeper",
      "LeftBack",
      "CenterBack",
      "CenterBack",
      "RightBack",
      "LeftMidfielder",
      "CentralMidfielder",
      "CentralMidfielder",
      "RightMidfielder",
      "Striker",
      "Striker",
    ]);

    expect(slots("4-3-3")).toEqual([
      "Goalkeeper",
      "LeftBack",
      "CenterBack",
      "CenterBack",
      "RightBack",
      "DefensiveMidfielder",
      "CentralMidfielder",
      "AttackingMidfielder",
      "LeftWinger",
      "Striker",
      "RightWinger",
    ]);

    expect(slots("5-3-2")).toEqual([
      "Goalkeeper",
      "LeftWingBack",
      "CenterBack",
      "CenterBack",
      "CenterBack",
      "RightWingBack",
      "DefensiveMidfielder",
      "CentralMidfielder",
      "AttackingMidfielder",
      "Striker",
      "Striker",
    ]);
  });

  it("summarises role coverage for the active shape", () => {
    const players = [
      makePlayer("gk", "Goalkeeper"),
      makePlayer("lb", "Left Back", { natural_position: "Left Back" }),
      makePlayer("cb1", "Center Back", { natural_position: "Center Back" }),
      makePlayer("cb2", "Center Back", { natural_position: "Center Back" }),
      makePlayer("rb", "Right Back", { natural_position: "Right Back" }),
      makePlayer("lm", "Left Midfielder", { natural_position: "Left Midfielder" }),
      makePlayer("cm1", "Central Midfielder", {
        natural_position: "Central Midfielder",
      }),
      makePlayer("cm2", "Central Midfielder", {
        natural_position: "Central Midfielder",
      }),
      makePlayer("rm", "Right Midfielder", { natural_position: "Right Midfielder" }),
      makePlayer("st1", "Striker", { natural_position: "Striker" }),
      makePlayer("st2", "Striker", { natural_position: "Striker" }),
      makePlayer("gk2", "Goalkeeper", { natural_position: "Goalkeeper" }),
      makePlayer("cb3", "Center Back", { natural_position: "Center Back" }),
    ];

    const coverage = buildRoleCoverageSummary(
      players,
      ["gk", "lb", "cb1", "cb2", "rb", "lm", "cm1", "cm2", "rm", "st1", "st2"],
      "4-4-2",
      cannedPositionTable(),
    );

    expect(coverage.find((role) => role.role === "Goalkeeper")).toMatchObject({
      requiredSlots: 1,
      naturalStarters: 1,
      benchOptions: 1,
      status: "covered",
    });

    expect(coverage.find((role) => role.role === "LeftBack")).toMatchObject({
      requiredSlots: 1,
      naturalStarters: 1,
      benchOptions: 0,
      status: "thin",
    });

    expect(coverage.find((role) => role.role === "RightMidfielder")).toMatchObject({
      requiredSlots: 1,
      naturalStarters: 1,
      benchOptions: 0,
      status: "thin",
    });
  });
});

describe("getDeployedPosition", () => {
  // Slot order must mirror the backend's formation_slot_rows
  // (ofm_core::player_rating): GK, defenders, [deep + attacking] midfield,
  // forwards — 4-2-3-1 → GK; LB CB CB RB; DM CM; LM AM RM; ST.
  const team = {
    formation: "4-2-3-1",
    starting_xi_ids: ["gk", "lb", "cb1", "cb2", "rb", "dm", "cm", "lm", "am", "rm", "st"],
  };

  it("derives the granular slot from formation and starting-XI order", () => {
    expect(getDeployedPosition(team, "gk")).toBe("Goalkeeper");
    expect(getDeployedPosition(team, "rb")).toBe("RightBack");
    expect(getDeployedPosition(team, "dm")).toBe("DefensiveMidfielder");
    expect(getDeployedPosition(team, "cm")).toBe("CentralMidfielder");
    expect(getDeployedPosition(team, "am")).toBe("AttackingMidfielder");
    expect(getDeployedPosition(team, "rm")).toBe("RightMidfielder");
    expect(getDeployedPosition(team, "st")).toBe("Striker");
  });

  it("returns null for players outside the starting XI", () => {
    expect(getDeployedPosition(team, "bench-player")).toBeNull();
  });

  describe("before the position table has loaded", () => {
    const notLoaded = () => createPositionTable([]);

    const xi = ["gk", "d1", "d2", "d3", "d4", "m1", "m2", "m3", "m4", "f1", "f2"];
    const squad = () =>
      new Map(
        [
          makePlayer("gk", "Goalkeeper"),
          makePlayer("d1", "CenterBack"),
          makePlayer("d2", "CenterBack"),
          makePlayer("d3", "LeftBack"),
          makePlayer("d4", "RightBack"),
          makePlayer("m1", "CentralMidfielder"),
          makePlayer("m2", "CentralMidfielder"),
          makePlayer("m3", "LeftMidfielder"),
          makePlayer("m4", "RightMidfielder"),
          makePlayer("f1", "Striker"),
          makePlayer("f2", "Striker"),
          makePlayer("rw", "RightWinger"),
        ].map((player) => [player.id, player] as const),
      );

    /**
     * Given a winger in the starting XI and a table that has not arrived (every slot would tie,
     *       and the lowest slot index, the keeper's, would win)
     * When his best-fit slot is asked for
     * Then the XI is left as it is, so no keeper-slot lineup can be saved; with the table loaded
     *      he is moved.
     */
    it("leaves the XI alone when asked for a best-fit slot", () => {
      const withWinger = [...xi.slice(0, 10), "rw"];

      expect(buildAssignBestFitSlot(withWinger, squad(), "4-4-2", "rw", notLoaded())).toEqual(
        withWinger,
      );
      expect(
        buildAssignBestFitSlot(withWinger, squad(), "4-4-2", "rw", cannedPositionTable()),
      ).not.toEqual(withWinger);
    });

    /**
     * Given a bench defender and a table that has not arrived
     * When he is promoted, and a starter is demoted
     * Then the XI is left as it is in both; with the table loaded both change it.
     */
    it("leaves the XI alone when a player is promoted or demoted", () => {
      const players = squad();
      players.set("bd", makePlayer("bd", "CenterBack"));
      const bench = [...players.values()].filter((player) => !xi.includes(player.id));

      expect(buildPromoteToStartingXi(xi, players, "4-4-2", "bd", notLoaded())).toEqual(xi);
      expect(
        buildPromoteToStartingXi(xi, players, "4-4-2", "bd", cannedPositionTable()),
      ).not.toEqual(xi);
      expect(buildDemoteFromStartingXi(xi, bench, "4-4-2", "d1", notLoaded())).toEqual(xi);
      expect(
        buildDemoteFromStartingXi(xi, bench, "4-4-2", "d1", cannedPositionTable()),
      ).not.toEqual(xi);
    });

    /**
     * Given a left back and a table that has not arrived (no line is known)
     * When he is asked about in a slot of another line
     * Then he is not called out of position: with no lines known the answer would be a guess.
     */
    it("does not call a player out of position", () => {
      const leftBack = makePlayer("lb", "Left Back", { natural_position: "Left Back" });

      expect(isPlayerOutOfPosition(leftBack, "Forward", notLoaded())).toBe(false);
    });

    /**
     * Given a forward put in a back's slot, and a table that has not arrived
     * When his tactical fit is asked for
     * Then it is not "out": exact and adapted are the only answers it can give.
     */
    it("does not grade a fit as out", () => {
      const forward = makePlayer("fwd", "Forward", { natural_position: "Forward" });

      expect(getSquadTacticalFit(forward, "CenterBack", notLoaded())).not.toBe("out");
    });
  });

  describe("when the screen reads the backend's familiarity", () => {
    // A table that says what the test says, whatever the player's own positions are: it proves the
    // helpers read the table and do not grade the player themselves.
    const saying = (word: Familiarity | null): FamiliarityTable => ({
      loaded: true,
      familiarityOf: () => word,
    });
    const leftBack = makePlayer("p1", "Left Back", { natural_position: "LeftBack" });

    /**
     * Given a left back whom the backend calls out of position at left back (contrary to his
     *       own positions)
     * When he is graded for that slot
     * Then he is out, not natural: the backend's word wins.
     */
    it("grades out of position when the backend says so", () => {
      const familiarity = saying("out_of_position");

      expect(getSquadTacticalFit(leftBack, "LeftBack", cannedPositionTable(), familiarity)).toBe(
        "out",
      );
      expect(isPlayerOutOfPosition(leftBack, "LeftBack", cannedPositionTable(), familiarity)).toBe(
        true,
      );
    });

    /**
     * Given a left back whom the backend calls natural at a slot he could not play by his own
     *       positions
     * When he is graded for it
     * Then he is natural.
     */
    it("grades natural when the backend says so", () => {
      expect(
        getSquadTacticalFit(leftBack, "Striker", cannedPositionTable(), saying("natural")),
      ).toBe("natural");
    });

    /**
     * Given a backend word of can play
     * When he is graded
     * Then he is adapted.
     */
    it("grades adapted for can play", () => {
      expect(
        getSquadTacticalFit(leftBack, "Striker", cannedPositionTable(), saying("can_play")),
      ).toBe("adapted");
    });

    /**
     * Given a table with no grade for the player (not loaded, or not in the club)
     * When he is graded for a slot
     * Then there is no verdict: not "adapted", which would read as a mark.
     */
    it("gives no verdict when the table has no grade for the player", () => {
      expect(
        getSquadTacticalFit(leftBack, "LeftBack", cannedPositionTable(), saying(null)),
      ).toBeNull();
    });

    /**
     * Given a pool of eighteen and a saved XI of three, with the familiarity not arrived and arrived
     * When the starting XI is built
     * Then before it arrives only the three saved players are drawn (nothing is filled by rating
     *      alone, which would put an outfielder in goal and then reorder), and once it has the
     *      other eight are filled in.
     */
    it("fills the XI only once the familiarity has loaded", () => {
      // A pool large enough to field eleven besides the three saved (a smaller one is its own bug).
      const pool = Array.from({ length: 18 }, (_, index) => makePlayer(`p${index}`, "Midfielder"));
      const saved = ["p0", "p1", "p2"];

      expect(
        buildStartingXIIds(pool, saved, "4-4-2", cannedPositionTable(), pendingFamiliarityTable()),
      ).toEqual(saved);
      expect(
        buildStartingXIIds(pool, saved, "4-4-2", cannedPositionTable(), saying("natural")),
      ).toHaveLength(11);
    });

    /**
     * Given a table that has not arrived
     * When a lineup action is asked for
     * Then nothing is picked: the squad is returned as it was, even with the position table loaded.
     */
    it("picks nothing until the familiarity has loaded", () => {
      const xi = ["a", "b"];
      const byId = new Map([["a", makePlayer("a", "Goalkeeper")]]);

      expect(
        buildPromoteToStartingXi(
          xi,
          byId,
          "4-4-2",
          "a",
          cannedPositionTable(),
          pendingFamiliarityTable(),
        ),
      ).toBe(xi);
      expect(lineupReady(cannedPositionTable(), pendingFamiliarityTable())).toBe(false);
      expect(lineupReady(cannedPositionTable(), saying("natural"))).toBe(true);
      expect(lineupReady(createPositionTable([]), saying("natural"))).toBe(false);
    });
  });
});
