import { useRatingTiers } from "../../hooks/useRatingTiers";
import { useContractRiskLevels } from "../../hooks/useContractWarningStages";
import { useId, useMemo, useRef, useState } from "react";
import type {
  GameStateData,
  PlayerData,
  PlayerSelectionOptions,
  TeamData,
} from "../../store/gameStore";
import { Badge, Card, DataTable, PositionBadges, Select, ViewSwitch } from "../ui";
import { MoreVertical, Users } from "lucide-react";
import { getPlayerOvr } from "../../lib/helpers";
import {
  isFirstTeamSquadPlayer,
  isMatchDayEligible,
  isRuledOutOfMatchDay,
} from "../../lib/playerSquad";
import { useTranslation } from "react-i18next";
import ContextMenu, { type ContextMenuHandle } from "../ContextMenu";
import { clearContractExitIntent, setContractExitIntent } from "../../services/contractService";
import { setStartingXi } from "../../services/squadService";
import { resolveBackendError } from "../../utils/backendI18n";
import {
  buildActivePositionMap,
  buildRoleCoverageSummary,
  buildDemoteFromStartingXi,
  getBestRoleForFormation,
  getCurrentPosition,
  buildPitchRows,
  buildPitchSlotRows,
  buildPromoteToStartingXi,
  buildStartingXIIds,
  getPreferredPositions,
  getSquadTacticalFit,
  lineupReady,
  isPlayerOutOfPosition,
  translatePositionAbbreviation,
  translatePositionLabel,
} from "./SquadTab.helpers";
import { useFamiliarity } from "../../hooks/useFamiliarity";
import { usePositionTable } from "../../hooks/usePositionGroups";
import { findTacticsPresetBySetup } from "../tactics/TacticsTab.helpers";
import { SquadNameAside, squadRosterColumns } from "./SquadRosterView.columns";
import { squadRowMenuItems } from "./SquadRosterView.menu";
import {
  DEFAULT_SQUAD_LIST_SORT_STATE,
  type SquadListSortKey,
  type SquadListSortState,
} from "./SquadRosterView.state";
import { useListView } from "../../hooks/useListView";
import { contextMenuPoint } from "../../lib/contextMenuPoint";
import type { DeployedPosition } from "./SquadCardGrid";
import SquadCardsView from "./SquadCardsView";
import { sortSquadRoster } from "./SquadRosterView.sort";

interface SquadRosterViewProps {
  players: PlayerData[];
  /** The squad's eligibility is the backend's for the current revision, not the previous one's. */
  squadAnswered: boolean;
  team: TeamData;
  clockDate: string;
  onSelectPlayer: (id: string, options?: PlayerSelectionOptions) => void;
  onMutationComplete?: (g: GameStateData) => void;
  sortState?: SquadListSortState;
  onSortStateChange?: (sortState: SquadListSortState) => void;
}

type FilterScope =
  | "all"
  | "xi"
  | "bench"
  | "naturalFit"
  | "needsCover"
  | "outOfPosition"
  | "injured";

export default function SquadRosterView({
  players,
  squadAnswered,
  team,
  clockDate,
  onSelectPlayer,
  onMutationComplete,
  sortState,
  onSortStateChange,
}: SquadRosterViewProps) {
  const tierOf = useRatingTiers();
  const { t, i18n } = useTranslation();
  const [view, setView] = useListView();
  const [playerSearch, setPlayerSearch] = useState("");
  // Ties each visible filter label to its control, so the control is announced by that label.
  const searchInputId = useId();
  const positionFilterId = useId();
  const statusFilterId = useId();
  const [positionFilter, setPositionFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState<FilterScope>("all");
  const [localSortState, setLocalSortState] = useState<SquadListSortState>(
    DEFAULT_SQUAD_LIST_SORT_STATE,
  );
  const [contractActionPlayerId, setContractActionPlayerId] = useState<string | null>(null);
  const [contractActionError, setContractActionError] = useState<string | null>(null);
  const menuRefs = useRef<Map<string, ContextMenuHandle>>(new Map());
  const [openMenuPlayerId, setOpenMenuPlayerId] = useState<string | null>(null);

  const positionTable = usePositionTable();
  const familiarity = useFamiliarity();
  // One flag for grading and for changing a lineup: the table, the familiarity and the squad's
  // answer for this revision.
  const canGradeLineup = lineupReady(positionTable, familiarity) && squadAnswered;
  const roster = players
    .filter((player) => isFirstTeamSquadPlayer(player))
    .sort(
      (a, b) =>
        positionTable.lineRankOf(a.position) - positionTable.lineRankOf(b.position) ||
        getPlayerOvr(b) - getPlayerOvr(a),
    );

  const playersById = useMemo(() => new Map(roster.map((player) => [player.id, player])), [roster]);
  const riskLevelOf = useContractRiskLevels(roster, clockDate);

  const available = roster.filter(isMatchDayEligible);
  // The saved XI is drawn from everyone the backend has not ruled out: before get_squad answers no
  // player carries a verdict (so `available` is empty) and the XI would not be drawn at all. Only
  // display reads this pool; a lineup action keeps the strict `available`.
  const drawable = roster.filter((player) => !isRuledOutOfMatchDay(player));
  const formation = team.formation || "4-4-2";
  const activePlayStyle = team.play_style || "Balanced";
  const currentPreset = findTacticsPresetBySetup(formation, activePlayStyle);
  const startingXiIds = useMemo(
    () =>
      buildStartingXIIds(
        drawable,
        team.starting_xi_ids || [],
        formation,
        positionTable,
        familiarity,
      ),
    [drawable, team.starting_xi_ids, formation, positionTable, familiarity],
  );
  const pitchSlotRows = buildPitchSlotRows(buildPitchRows(formation), startingXiIds, playersById);
  const xiActivePosition = buildActivePositionMap(pitchSlotRows);
  const xiIds = useMemo(() => new Set(startingXiIds), [startingXiIds]);
  const roleCoverage = useMemo(
    () => buildRoleCoverageSummary(drawable, startingXiIds, formation, positionTable, familiarity),
    [drawable, startingXiIds, formation, positionTable, familiarity],
  );
  const rolesNeedingCover = useMemo(
    () =>
      new Set(
        roleCoverage
          .filter((coverage) => coverage.status !== "covered")
          .map((coverage) => coverage.role),
      ),
    [roleCoverage],
  );
  const activeSortState = sortState ?? localSortState;
  const sortKey = activeSortState.sortKey;
  const sortDir = activeSortState.sortDir;

  const updateSortState = (nextSortState: SquadListSortState) => {
    if (onSortStateChange) {
      onSortStateChange(nextSortState);
      return;
    }

    setLocalSortState(nextSortState);
  };

  const toggleSort = (key: SquadListSortKey) => {
    if (sortKey === key) {
      updateSortState({
        sortKey,
        sortDir: sortDir === "asc" ? "desc" : "asc",
      });
      return;
    }

    // Sensible starting direction per column: OVR, condition, morale default
    // to desc (higher first); everything else defaults to asc.
    const descByDefault: SquadListSortKey[] = ["ovr", "condition", "morale"];
    updateSortState({
      sortKey: key,
      sortDir: descByDefault.includes(key) ? "desc" : "asc",
    });
  };

  const isOutOfPosition = (player: PlayerData): boolean => {
    return (
      xiIds.has(player.id) &&
      isPlayerOutOfPosition(
        player,
        getCurrentPosition(player, xiActivePosition),
        positionTable,
        familiarity,
      )
    );
  };

  const getTacticalFit = (player: PlayerData) => {
    return getSquadTacticalFit(
      player,
      getCurrentPosition(player, xiActivePosition),
      positionTable,
      familiarity,
    );
  };

  /** A starter's slot and how it suits him, as his row's badge and his card both say it. */
  const deployedPositionOf = (player: PlayerData): DeployedPosition | null =>
    xiIds.has(player.id)
      ? {
          position: getCurrentPosition(player, xiActivePosition),
          familiarity: getTacticalFit(player),
        }
      : null;

  const matchesFilters = (player: PlayerData): boolean => {
    const inXI = xiIds.has(player.id);
    const currentPos = positionTable.groupOf(getCurrentPosition(player, xiActivePosition));
    const preferredPositions = getPreferredPositions(player);
    const search = playerSearch.trim().toLowerCase();

    if (search) {
      const searchable = [
        player.full_name,
        player.match_name,
        currentPos,
        ...preferredPositions,
        ...preferredPositions.map((position) => translatePositionAbbreviation(t, position)),
      ]
        .join(" ")
        .toLowerCase();
      if (!searchable.includes(search)) return false;
    }

    if (
      positionFilter !== "All" &&
      currentPos !== positionFilter &&
      !preferredPositions.includes(positionFilter)
    ) {
      return false;
    }

    switch (statusFilter) {
      case "xi":
        return inXI;
      case "bench":
        return !inXI;
      case "naturalFit":
        return getTacticalFit(player) === "natural";
      case "needsCover":
        return rolesNeedingCover.has(getBestRoleForFormation(player, formation, positionTable));
      case "outOfPosition":
        return isOutOfPosition(player);
      case "injured":
        return Boolean(player.injury);
      default:
        return true;
    }
  };

  const filteredRoster = useMemo(() => {
    const list = roster.filter((player) => matchesFilters(player));

    return sortSquadRoster(
      list,
      { sortKey, sortDir },
      { isStarter: (player) => xiIds.has(player.id), positionRankOf: positionTable.rankOf },
      i18n.language,
    );
  }, [
    formation,
    i18n.language,
    playerSearch,
    positionFilter,
    positionTable,
    roleCoverage,
    roster,
    sortDir,
    sortKey,
    startingXiIds,
    statusFilter,
    t,
    xiActivePosition,
    xiIds,
  ]);

  const hasActiveFilters =
    playerSearch.trim().length > 0 || positionFilter !== "All" || statusFilter !== "all";
  const starterCount = startingXiIds.length;
  const benchCount = Math.max(roster.length - starterCount, 0);
  const naturalFitCount = roster.filter((player) => getTacticalFit(player) === "natural").length;
  const outOfPositionCount = roster.filter((player) => isOutOfPosition(player)).length;
  const injuredCount = roster.filter((player) => player.injury).length;
  const thinCoverageCount = roleCoverage.filter((coverage) => coverage.status !== "covered").length;

  // Every roster action that succeeds clears the last one's error: it no longer stands.
  const completeMutation = (game: GameStateData) => {
    setContractActionError(null);
    onMutationComplete?.(game);
  };

  const persistStartingXi = async (playerIds: string[]): Promise<void> => {
    // Nothing is saved from a lineup worked out before the table and the familiarity have loaded
    // or from a squad the backend has not answered for this revision (its eligibility is the
    // last one's).
    if (!canGradeLineup) return;
    const updated = await setStartingXi(playerIds);
    completeMutation(updated);
  };

  const updateContractExitIntent = async (
    playerId: string,
    shouldLetExpire: boolean,
  ): Promise<void> => {
    setContractActionPlayerId(playerId);
    setContractActionError(null);

    try {
      const result = shouldLetExpire
        ? await setContractExitIntent(playerId, "manager_squad_action")
        : await clearContractExitIntent(playerId);
      completeMutation(result.game);
    } catch (error) {
      setContractActionError(resolveBackendError(error));
    } finally {
      setContractActionPlayerId(null);
    }
  };

  const updateSquadPlanning = async (
    playerId: string,
    action: "promote" | "demote",
  ): Promise<void> => {
    const nextXiIds =
      action === "promote"
        ? buildPromoteToStartingXi(
            startingXiIds,
            playersById,
            formation,
            playerId,
            positionTable,
            familiarity,
          )
        : buildDemoteFromStartingXi(
            startingXiIds,
            available,
            formation,
            playerId,
            positionTable,
            familiarity,
          );

    if (!nextXiIds || nextXiIds.join(",") === startingXiIds.join(",")) {
      return;
    }

    try {
      await persistStartingXi(nextXiIds);
    } catch (error) {
      setContractActionError(resolveBackendError(error));
    }
  };

  const renderPreferredPositionMeta = (player: PlayerData) => {
    const [natural, ...alternates] = getPreferredPositions(player);
    const deployed = deployedPositionOf(player);
    return (
      <PositionBadges
        // Table C: one line of up to three, the deployed position kept, the rest as "+n".
        max={3}
        oneLine
        natural={natural}
        alternates={alternates}
        deployed={deployed?.position}
        familiarity={deployed?.familiarity ?? undefined}
        describe={(position) => ({
          label: translatePositionAbbreviation(t, position),
          name: translatePositionLabel(t, position),
        })}
      />
    );
  };

  const columns = squadRosterColumns({
    t,
    language: i18n.language,
    tierOf,
    riskLevelOf,
    renderPositions: renderPreferredPositionMeta,
  });
  const benchHasCover = available.some((candidate) => !xiIds.has(candidate.id));
  const menuContextFor = (player: PlayerData) => ({
    t,
    inStartingXi: xiIds.has(player.id),
    canBench: benchHasCover,
    contractRisk: riskLevelOf(player.id),
    contractActionPending: contractActionPlayerId === player.id,
    onSelectPlayer,
    onMutationComplete: completeMutation,
    lineupReady: canGradeLineup,
    updateSquadPlanning,
    updateContractExitIntent,
    onActionError: (error: unknown) => setContractActionError(resolveBackendError(error)),
  });

  return (
    <div className="flex flex-col gap-4">
      <Card>
        <div className="p-4 grid grid-cols-1 lg:grid-cols-[minmax(0,1.3fr)_220px_220px_auto_auto] gap-3 items-end">
          <div>
            <label
              htmlFor={searchInputId}
              className="text-caption font-heading font-bold uppercase tracking-label text-fg-muted mb-2 block"
            >
              {t("common.search")}
            </label>
            <input
              id={searchInputId}
              type="text"
              value={playerSearch}
              onChange={(event) => setPlayerSearch(event.target.value)}
              placeholder={t("squad.filterPlayers")}
              className="w-full rounded-control border border-line bg-panel px-3 py-2 text-body text-fg placeholder:text-fg-subtle focus:outline-none focus:ring-2 focus:ring-selected/40"
            />
          </div>
          <div>
            <label
              htmlFor={positionFilterId}
              className="text-caption font-heading font-bold uppercase tracking-label text-fg-muted mb-2 block"
            >
              {t("squad.pos")}
            </label>
            <Select
              id={positionFilterId}
              value={positionFilter}
              onChange={(event) => setPositionFilter(event.target.value)}
              fullWidth
            >
              <option value="All">{t("common.all")}</option>
              {positionTable.lines().map((position) => (
                <option key={position} value={position}>
                  {translatePositionAbbreviation(t, position)}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <label
              htmlFor={statusFilterId}
              className="text-caption font-heading font-bold uppercase tracking-label text-fg-muted mb-2 block"
            >
              {t("common.status")}
            </label>
            <Select
              id={statusFilterId}
              value={statusFilter}
              onChange={(event) => setStatusFilter(event.target.value as FilterScope)}
              fullWidth
            >
              <option value="all">{t("common.allPlayers")}</option>
              <option value="xi">{t("preMatch.startingXI")}</option>
              <option value="bench">{t("preMatch.substitutes")}</option>
              {/* The fit filters read the backend's lines and grade; until they arrive they would
                  show an empty list, or drop players they should keep, so they are not offered. */}
              {canGradeLineup ? <option value="naturalFit">{t("squad.naturalFit")}</option> : null}
              {canGradeLineup ? <option value="needsCover">{t("squad.needsCover")}</option> : null}
              {canGradeLineup ? (
                <option value="outOfPosition">{t("squad.outOfPosition")}</option>
              ) : null}
              <option value="injured">{t("common.injured")}</option>
            </Select>
          </div>
          <button
            type="button"
            onClick={() => {
              setPlayerSearch("");
              setPositionFilter("All");
              setStatusFilter("all");
            }}
            disabled={!hasActiveFilters}
            className={`px-3 py-2 rounded-control text-caption font-heading font-bold uppercase tracking-label transition-all ${
              hasActiveFilters
                ? "bg-hover text-fg-muted hover:bg-hover"
                : "bg-hover text-fg-subtle cursor-not-allowed"
            }`}
          >
            {t("common.clear")}
          </button>
          <ViewSwitch value={view} onChange={setView} />
        </div>
        <div className="px-4 pb-4 flex flex-wrap gap-2">
          <Badge variant="primary" size="sm">
            {starterCount} {t("squad.starter")}
          </Badge>
          <Badge variant="neutral" size="sm">
            {benchCount} {t("squad.benchOption")}
          </Badge>
          {canGradeLineup ? (
            <Badge variant="success" size="sm">
              {naturalFitCount} {t("squad.naturalFit")}
            </Badge>
          ) : null}
          {/* Coverage counts natural starters by the backend's grade: nothing is claimed before it. */}
          {canGradeLineup ? (
            <Badge variant={thinCoverageCount > 0 ? "accent" : "success"} size="sm">
              {thinCoverageCount} {t("squad.needsCover")}
            </Badge>
          ) : null}
          {canGradeLineup ? (
            <Badge variant={outOfPositionCount > 0 ? "danger" : "success"} size="sm">
              {outOfPositionCount} {t("squad.outOfPosition")}
            </Badge>
          ) : null}
          <Badge variant={injuredCount > 0 ? "danger" : "neutral"} size="sm">
            {injuredCount} {t("common.injured")}
          </Badge>
          <Badge variant="primary" size="sm">
            {filteredRoster.length} {t("squad.playersLabel")}
          </Badge>
        </div>
        {/* Why the lineup actions are disabled, so they are not silent. */}
        {canGradeLineup ? null : (
          <p role="status" className="px-4 pb-4 text-caption text-fg-muted">
            {t("common.lineupLoading")}
          </p>
        )}
      </Card>

      <Card>
        <div className="p-4 border-b border-line bg-panel rounded-t-xl">
          <h3 className="text-body font-heading font-bold text-fg uppercase tracking-label flex items-center gap-2">
            <Users className="w-4 h-4 text-warning" />
            {t("squad.title", { team: team.name })}
          </h3>
          <p className="text-caption text-fg-subtle mt-0.5">
            {filteredRoster.length} / {roster.length} {t("squad.playersLabel")}
          </p>
          <p className="text-caption text-fg-subtle mt-1">
            {t("squad.currentPlan")}: {formation} /{" "}
            {currentPreset
              ? t(`tactics.presetNames.${currentPreset.id}`, currentPreset.id)
              : t(`common.playStyles.${activePlayStyle}`, activePlayStyle)}
          </p>
          {canGradeLineup ? (
            <div className="mt-3 flex flex-col gap-2">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-caption font-heading font-bold uppercase tracking-label text-fg-subtle">
                  {t("squad.coverageTitle")}
                </span>
                <Badge variant={thinCoverageCount > 0 ? "danger" : "success"} size="sm">
                  {thinCoverageCount > 0
                    ? t("squad.coverageNeedsAttention", {
                        count: thinCoverageCount,
                      })
                    : t("squad.coverageStable")}
                </Badge>
              </div>
              <div className="flex flex-wrap gap-2">
                {roleCoverage.map((coverage) => (
                  <Badge
                    key={coverage.role}
                    variant={
                      coverage.status === "covered"
                        ? "success"
                        : coverage.status === "thin"
                          ? "accent"
                          : "danger"
                    }
                    size="sm"
                    className="gap-1"
                  >
                    <span>{translatePositionAbbreviation(t, coverage.role)}</span>
                    <span>
                      {t("squad.coverageBadge", {
                        starters: coverage.naturalStarters,
                        required: coverage.requiredSlots,
                        bench: coverage.benchOptions,
                      })}
                    </span>
                  </Badge>
                ))}
              </div>
            </div>
          ) : null}
        </div>
        {view === "cards" ? (
          <SquadCardsView
            players={filteredRoster}
            teamName={team.name}
            kit={team.colors}
            isStarter={(player) => xiIds.has(player.id)}
            deployedPositionOf={deployedPositionOf}
            riskLevelOf={riskLevelOf}
            menuItemsFor={(player) => squadRowMenuItems(player, menuContextFor(player))}
            onSelectPlayer={onSelectPlayer}
            sortKey={sortKey}
            sortDir={sortDir}
            onSort={toggleSort}
          />
        ) : (
          <DataTable
            label={t("squad.title", { team: team.name })}
            columns={columns}
            rows={filteredRoster}
            rowKey={(player) => player.id}
            rowName={(player) => player.match_name}
            sort={{ key: sortKey, direction: sortDir }}
            onSortChange={(key) => toggleSort(key as SquadListSortKey)}
            onOpen={(player) => onSelectPlayer(player.id)}
            rowAccent={(player) =>
              xiIds.has(player.id) ? "selected" : isRuledOutOfMatchDay(player) ? "danger" : null
            }
            onRowContextMenu={(player, event) => {
              const point = contextMenuPoint(event, event.currentTarget);
              menuRefs.current.get(player.id)?.open(point.x, point.y);
            }}
            primaryAside={(player) => (
              <SquadNameAside player={player} starting={xiIds.has(player.id)} t={t} />
            )}
            rowAction={{
              header: t("common.actions"),
              cell: (player) => (
                <ContextMenu
                  items={squadRowMenuItems(player, menuContextFor(player))}
                  ref={(handle) => {
                    if (handle) menuRefs.current.set(player.id, handle);
                    else menuRefs.current.delete(player.id);
                  }}
                  onOpenChange={(open) => {
                    setOpenMenuPlayerId((prev) => {
                      if (open) return player.id;
                      return prev === player.id ? null : prev;
                    });
                  }}
                >
                  <button
                    type="button"
                    onClick={(e) => {
                      const rect = e.currentTarget.getBoundingClientRect();
                      menuRefs.current.get(player.id)?.open(rect.left, rect.bottom + 4);
                    }}
                    aria-label={t("common.playerActions", { name: player.match_name })}
                    aria-haspopup="menu"
                    aria-expanded={openMenuPlayerId === player.id}
                    className="relative rounded-md p-1.5 text-fg-subtle transition-colors hover:text-fg focus:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-focus"
                  >
                    <MoreVertical className="h-4 w-4" />
                    {player.injury || riskLevelOf(player.id) !== "stable" ? (
                      // Decoration: the injury and the contract stage are said in words in the row.
                      <span
                        aria-hidden="true"
                        className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-warning-solid"
                      />
                    ) : null}
                  </button>
                </ContextMenu>
              ),
            }}
            empty={t("squad.noPlayers")}
          />
        )}
      </Card>

      {contractActionError ? (
        <div
          role="alert"
          className="rounded-control border border-danger bg-danger-tint px-4 py-3 text-body text-danger"
        >
          {contractActionError}
        </div>
      ) : null}
    </div>
  );
}
