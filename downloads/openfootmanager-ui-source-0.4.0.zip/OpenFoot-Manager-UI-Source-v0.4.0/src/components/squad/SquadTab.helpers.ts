import { canonicalPosition, naturalPositionOf } from "../../lib/positions";
import type { FamiliarityTable } from "../../hooks/useFamiliarity";
import type { PositionTable } from "../../lib/positionTable";

import type { PlayerData } from "../../store/gameStore";
import { getPlayerOvr } from "../../lib/helpers";
import { isMatchDayEligible } from "../../lib/playerSquad";

export type SquadSection = "xi" | "bench";
export type DragState = {
  playerId: string;
  from: SquadSection;
  slotIndex: number | null;
};

export type PitchRow = { label: string; y: string; positions: string[] };
export type PitchSlot = {
  index: number;
  position: string;
  player: PlayerData | null;
};
export type PitchSlotRow = PitchRow & { slots: PitchSlot[] };
export type SquadTacticalFit = "natural" | "adapted" | "out";
export type SquadRoleCoverageStatus = "covered" | "thin" | "uncovered";
export type SquadRoleCoverage = {
  role: string;
  requiredSlots: number;
  naturalStarters: number;
  benchOptions: number;
  status: SquadRoleCoverageStatus;
};

const POSITION_LABELS: Record<string, string> = {
  Goalkeeper: "Goalkeeper",
  Defender: "Defender",
  Midfielder: "Midfielder",
  Forward: "Forward",
  RightBack: "Right Back",
  CenterBack: "Center Back",
  LeftBack: "Left Back",
  RightWingBack: "Right Wing-Back",
  LeftWingBack: "Left Wing-Back",
  DefensiveMidfielder: "Defensive Midfielder",
  CentralMidfielder: "Central Midfielder",
  AttackingMidfielder: "Attacking Midfielder",
  RightMidfielder: "Right Midfielder",
  LeftMidfielder: "Left Midfielder",
  RightWinger: "Right Winger",
  LeftWinger: "Left Winger",
  Striker: "Striker",
};

const POSITION_CODES: Record<string, string> = {
  Goalkeeper: "GK",
  Defender: "DEF",
  Midfielder: "MID",
  Forward: "FWD",
  RightBack: "RB",
  CenterBack: "CB",
  LeftBack: "LB",
  RightWingBack: "RWB",
  LeftWingBack: "LWB",
  DefensiveMidfielder: "DM",
  CentralMidfielder: "CM",
  AttackingMidfielder: "AM",
  RightMidfielder: "RM",
  LeftMidfielder: "LM",
  RightWinger: "RW",
  LeftWinger: "LW",
  Striker: "ST",
};

const GROUP_ROLE_PREFERENCES: Record<string, string[]> = {
  Goalkeeper: ["Goalkeeper"],
  Defender: ["CenterBack", "LeftBack", "RightBack", "LeftWingBack", "RightWingBack"],
  Midfielder: [
    "CentralMidfielder",
    "DefensiveMidfielder",
    "AttackingMidfielder",
    "LeftMidfielder",
    "RightMidfielder",
  ],
  Forward: ["Striker", "LeftWinger", "RightWinger"],
};

export function parseFormationSlots(formation: string): {
  def: number;
  mid: number;
  fwd: number;
} {
  const parts = formation.split("-").map(Number);
  if (parts.length === 4) {
    return { def: parts[0], mid: parts[1] + parts[2], fwd: parts[3] };
  }
  if (parts.length === 3) {
    return { def: parts[0], mid: parts[1], fwd: parts[2] };
  }
  return { def: 4, mid: 4, fwd: 2 };
}

export function positionCode(position: string): string {
  const normalized = canonicalPosition(position);
  return POSITION_CODES[normalized] || normalized.substring(0, 3).toUpperCase();
}

export function translatePositionLabel(
  translate: (key: string, options?: { defaultValue?: string }) => string,
  position: string,
): string {
  const canonical = canonicalPosition(position);

  return translate(`common.positions.${canonical}`, {
    defaultValue: POSITION_LABELS[canonical] || canonical,
  });
}

export function translatePositionAbbreviation(
  translate: (key: string, options?: { defaultValue?: string }) => string,
  position: string,
): string {
  const normalized = canonicalPosition(position);

  return translate(`common.posAbbr.${normalized}`, {
    defaultValue: positionCode(position),
  });
}

/**
 * The position a player is currently in: their assigned pitch slot when they are
 * in the starting XI (`xiActivePosition` only holds XI players), otherwise their
 * natural position. `player.position` is only a last-resort fallback because on
 * legacy saves it can still hold a coarse bucket.
 */
export function getCurrentPosition(
  player: PlayerData,
  xiActivePosition: Map<string, string>,
): string {
  return xiActivePosition.get(player.id) || naturalPositionOf(player);
}

export function getPreferredPositions(player: PlayerData): string[] {
  return [
    ...new Set(
      [naturalPositionOf(player), ...(player.alternate_positions || [])]
        .filter(Boolean)
        .map(canonicalPosition),
    ),
  ];
}

export function buildPitchRows(formation: string): PitchRow[] {
  const parts = formation
    .split("-")
    .map(Number)
    .filter((value) => !Number.isNaN(value));

  const defenderLine = (count: number): string[] => {
    switch (count) {
      case 3:
        return ["CenterBack", "CenterBack", "CenterBack"];
      case 4:
        return ["LeftBack", "CenterBack", "CenterBack", "RightBack"];
      case 5:
        return ["LeftWingBack", "CenterBack", "CenterBack", "CenterBack", "RightWingBack"];
      default:
        return Array(count).fill("CenterBack");
    }
  };

  const midfieldLine = (count: number): string[] => {
    switch (count) {
      case 2:
        return ["CentralMidfielder", "CentralMidfielder"];
      case 3:
        return ["DefensiveMidfielder", "CentralMidfielder", "AttackingMidfielder"];
      case 4:
        return ["LeftMidfielder", "CentralMidfielder", "CentralMidfielder", "RightMidfielder"];
      case 5:
        return [
          "LeftMidfielder",
          "DefensiveMidfielder",
          "CentralMidfielder",
          "AttackingMidfielder",
          "RightMidfielder",
        ];
      default:
        return Array(count).fill("CentralMidfielder");
    }
  };

  const deepMidfieldLine = (count: number): string[] => {
    switch (count) {
      case 1:
        return ["DefensiveMidfielder"];
      case 2:
        return ["DefensiveMidfielder", "CentralMidfielder"];
      default:
        return Array(count).fill("DefensiveMidfielder");
    }
  };

  const attackingMidfieldLine = (count: number): string[] => {
    switch (count) {
      case 1:
        return ["AttackingMidfielder"];
      case 2:
        return ["AttackingMidfielder", "AttackingMidfielder"];
      case 3:
        return ["LeftMidfielder", "AttackingMidfielder", "RightMidfielder"];
      default:
        return Array(count).fill("AttackingMidfielder");
    }
  };

  const forwardLine = (count: number): string[] => {
    switch (count) {
      case 1:
        return ["Striker"];
      case 2:
        return ["Striker", "Striker"];
      case 3:
        return ["LeftWinger", "Striker", "RightWinger"];
      default:
        return Array(count).fill("Striker");
    }
  };

  if (parts.length === 4) {
    const forwardY = parts[3] === 1 ? "16%" : "20%";
    const attackingMidY = parts[3] === 1 ? "40%" : "38%";

    return [
      { label: "GK", y: "88%", positions: ["Goalkeeper"] },
      { label: "DEF", y: "70%", positions: defenderLine(parts[0]) },
      { label: "DM", y: "54%", positions: deepMidfieldLine(parts[1]) },
      { label: "AM", y: attackingMidY, positions: attackingMidfieldLine(parts[2]) },
      { label: "FWD", y: forwardY, positions: forwardLine(parts[3]) },
    ];
  }

  const slots = parseFormationSlots(formation);
  const forwardY = slots.fwd === 1 ? "18%" : "22%";
  const midfieldY = slots.fwd === 1 ? "50%" : "46%";

  return [
    { label: "GK", y: "88%", positions: ["Goalkeeper"] },
    { label: "DEF", y: "70%", positions: defenderLine(slots.def) },
    { label: "MID", y: midfieldY, positions: midfieldLine(slots.mid) },
    { label: "FWD", y: forwardY, positions: forwardLine(slots.fwd) },
  ];
}

export function getPitchSlotWidth(slotCount: number): number {
  if (slotCount >= 5) return 66;
  if (slotCount === 4) return 70;
  if (slotCount === 3) return 74;
  if (slotCount === 2) return 78;
  return 82;
}

/**
 * Order candidates for a pitch slot, best first.
 *
 * Players who can play the slot at all lead: it is one of their preferred
 * positions, or at least in the same position group. Among those, a player
 * whose natural position *is* the slot goes ahead of one merely covering it.
 * Then the higher rating, then the fresher legs, with name as a stable
 * tiebreak so the order never wobbles between renders.
 *
 * Squad and Tactics both auto-fill from this, so the precedence is a shared
 * contract, not a local preference: changing it moves players in Squad's
 * best-fit assignment and Tactics' auto-pick at the same time. Change it
 * deliberately, or not at all.
 */
export function comparePlayersForSlot(
  leftPlayer: PlayerData,
  rightPlayer: PlayerData,
  slotPosition: string,
  positionTable: PositionTable,
  familiarity?: FamiliarityTable,
): number {
  return (
    Number(isPlayerOutOfPosition(leftPlayer, slotPosition, positionTable, familiarity)) -
      Number(isPlayerOutOfPosition(rightPlayer, slotPosition, positionTable, familiarity)) ||
    Number(!isPlayerExactForSlot(leftPlayer, slotPosition, familiarity)) -
      Number(!isPlayerExactForSlot(rightPlayer, slotPosition, familiarity)) ||
    getPlayerOvr(rightPlayer) - getPlayerOvr(leftPlayer) ||
    rightPlayer.condition - leftPlayer.condition ||
    leftPlayer.full_name.localeCompare(rightPlayer.full_name)
  );
}

export function buildStartingXIIds(
  available: PlayerData[],
  savedIds: string[],
  formation: string,
  positionTable: PositionTable,
  familiarity?: FamiliarityTable,
): string[] {
  const rows = buildPitchRows(formation);
  const slotPositions = rows.flatMap((row) => row.positions);
  const byId = new Map(available.map((player) => [player.id, player]));
  const validSavedIds: string[] = [];
  const used = new Set<string>();

  for (const id of savedIds) {
    const player = byId.get(id);
    if (player && !used.has(id)) {
      validSavedIds.push(id);
      used.add(id);
    }
  }

  // Until the backend's grade arrives every player ties on fit and rating alone would fill each
  // slot (an outfielder in goal), then the XI would reorder. The saved ids are all that is drawn
  // until it does; the rest is filled once it can be done properly.
  if (familiarity && !familiarity.loaded) return validSavedIds.slice(0, 11);

  if (validSavedIds.length >= 8) {
    const xi = [...validSavedIds];
    while (xi.length < 11) {
      const slotPosition = slotPositions[xi.length];
      const candidates = available.filter((player) => !used.has(player.id));
      const bestPlayer = candidates.sort((a, b) =>
        comparePlayersForSlot(a, b, slotPosition, positionTable, familiarity),
      )[0];

      if (!bestPlayer) break;
      xi.push(bestPlayer.id);
      used.add(bestPlayer.id);
    }
    return xi.slice(0, 11);
  }

  // Too few saved players to keep: the XI is rebuilt from the whole pool, so the ids reserved above
  // for the kept ones are released. Left reserved, they were barred from the rebuild in any squad,
  // and a small one came up short (nine of eleven from twelve with three saved).
  used.clear();
  const xi: string[] = [];
  slotPositions.slice(0, 11).forEach((slotPosition) => {
    const candidates = available.filter((player) => !used.has(player.id));
    const bestPlayer = candidates.sort((a, b) =>
      comparePlayersForSlot(a, b, slotPosition, positionTable, familiarity),
    )[0];

    if (bestPlayer) {
      xi.push(bestPlayer.id);
      used.add(bestPlayer.id);
    }
  });

  return xi;
}

export function buildPitchSlotRows(
  rows: PitchRow[],
  xiIds: string[],
  playersById: Map<string, PlayerData>,
): PitchSlotRow[] {
  let slotIndex = 0;
  return rows.map((row) => ({
    ...row,
    slots: row.positions.map((position) => {
      const slot: PitchSlot = {
        index: slotIndex,
        position,
        player: playersById.get(xiIds[slotIndex]) ?? null,
      };
      slotIndex += 1;
      return slot;
    }),
  }));
}

/**
 * Front-end mirror of the backend's `deployed_position`
 * (ofm_core::player_rating): the granular slot a player occupies, derived from
 * the team's formation and starting-XI order. Returns null for players outside
 * the starting XI; callers fall back to the natural position, matching how the
 * backend validates `set_player_role`.
 */
export function getDeployedPosition(
  team: { formation: string; starting_xi_ids: string[] },
  playerId: string,
): string | null {
  const slotIndex = team.starting_xi_ids.indexOf(playerId);
  if (slotIndex < 0) return null;
  const slots = buildPitchRows(team.formation).flatMap((row) => row.positions);
  return slots[slotIndex] ?? null;
}

export function buildActivePositionMap(pitchSlotRows: PitchSlotRow[]): Map<string, string> {
  const map = new Map<string, string>();
  pitchSlotRows.forEach((row) => {
    row.slots.forEach((slot) => {
      if (slot.player) {
        map.set(slot.player.id, canonicalPosition(slot.position));
      }
    });
  });
  return map;
}

/** The granular position a legacy bucket is graded as, as the backend reads it. */
const BUCKET_AS_GRANULAR: Record<string, string> = {
  Defender: "CenterBack",
  Midfielder: "CentralMidfielder",
  Forward: "Striker",
};

/**
 * The positions the backend's `is_legacy_bucket` names: the goalkeeper is among them, so a player
 * whose natural position is Goalkeeper is read by his `position`.
 */
const LEGACY_BUCKETS = new Set(["Goalkeeper", ...Object.keys(BUCKET_AS_GRANULAR)]);

/** A position as it is graded: a legacy bucket as its granular position, anything else as it is. */
function gradedPosition(position: string): string {
  const canonical = canonicalPosition(position);
  return BUCKET_AS_GRANULAR[canonical] ?? canonical;
}

/**
 * The position a player is graded as playing: his natural position, or his coarse `position` when
 * the natural one is still a legacy bucket. This is the backend's `primary_position`, kept here
 * only while the screens grade a fit themselves (a copy to retire once they read the backend's).
 */
function primaryPositionOf(player: PlayerData): string {
  const natural = canonicalPosition(player.natural_position || "");
  const naturalIsBucket = natural === "" || LEGACY_BUCKETS.has(natural);
  return gradedPosition(naturalIsBucket ? player.position : natural);
}

/**
 * A winger and the wide midfielder on his side, one line apart on the same flank: the backend's
 * `is_flank_partner` (player_rating.rs), which steps between them as within a line.
 */
const FLANK_PARTNERS: ReadonlySet<string> = new Set([
  "RightWinger:RightMidfielder",
  "RightMidfielder:RightWinger",
  "LeftWinger:LeftMidfielder",
  "LeftMidfielder:LeftWinger",
]);

/**
 * Whether the slot is neither the player's position, one of his alternates, a position in his
 * own line, nor the wide position on his flank in the next line: the backend's `out_of_position`. Until the backend's position table has loaded no line
 * is known, and "out of position" would be a guess that reads every granular player as out, so it
 * says no.
 */
export function isPlayerOutOfPosition(
  player: PlayerData,
  currentPos: string,
  positionTable: PositionTable,
  familiarity?: FamiliarityTable,
): boolean {
  // The backend's grade, when the screen has it; null (not loaded, or not the club's) is no.
  if (familiarity) {
    return (
      familiarity.familiarityOf(player.id, canonicalPosition(currentPos)) === "out_of_position"
    );
  }
  if (!positionTable.loaded) return false;
  const slot = gradedPosition(currentPos);
  const primary = primaryPositionOf(player);
  if (slot === primary) return false;
  if ((player.alternate_positions || []).some((alternate) => gradedPosition(alternate) === slot)) {
    return false;
  }
  if (FLANK_PARTNERS.has(`${primary}:${slot}`)) return false;
  return positionTable.groupOf(primary) !== positionTable.groupOf(slot);
}

export function isPlayerExactForSlot(
  player: PlayerData,
  currentPos: string,
  familiarity?: FamiliarityTable,
): boolean {
  if (familiarity) {
    return familiarity.familiarityOf(player.id, canonicalPosition(currentPos)) === "natural";
  }
  return primaryPositionOf(player) === gradedPosition(currentPos);
}

export function getSquadTacticalFit(
  player: PlayerData,
  currentPos: string,
  positionTable: PositionTable,
  familiarity?: FamiliarityTable,
): SquadTacticalFit | null {
  if (familiarity) {
    // No grade (not loaded, a player outside the club) is no verdict, not "adapted".
    const word = familiarity.familiarityOf(player.id, canonicalPosition(currentPos));
    if (word === null) return null;
    if (word === "natural") return "natural";
    return word === "out_of_position" ? "out" : "adapted";
  }
  if (isPlayerExactForSlot(player, currentPos)) {
    return "natural";
  }

  if (isPlayerOutOfPosition(player, currentPos, positionTable, familiarity)) {
    return "out";
  }

  return "adapted";
}

export function getBestRoleForFormation(
  player: PlayerData,
  formation: string,
  positionTable: PositionTable,
): string {
  const formationSlots = buildPitchRows(formation).flatMap((row) => row.positions);
  // Best role is an ability recommendation, so it is driven by the player's
  // natural position (not player.position, which is only a coarse bucket).
  const naturalPosition = canonicalPosition(naturalPositionOf(player));
  const alternatePositions = (player.alternate_positions || []).map(canonicalPosition);

  // 1. The player's natural position has an exact slot in this formation.
  if (formationSlots.includes(naturalPosition)) {
    return naturalPosition;
  }

  // 2. The closest role within the player's primary position group. This is
  //    preferred over tangential alternates so a DM in a DM-less formation
  //    resolves to CM, never to an unrelated alternate such as RB.
  const playerGroup = positionTable.groupOf(naturalPosition);
  const groupRolePreferences = GROUP_ROLE_PREFERENCES[playerGroup] ?? [];
  const preferredGroupRole = groupRolePreferences.find((position) =>
    formationSlots.includes(position),
  );
  if (preferredGroupRole) {
    return preferredGroupRole;
  }

  // 3. An alternate position the player can play that exists in the formation.
  const exactAlternateRole = alternatePositions.find((position) =>
    formationSlots.includes(position),
  );
  if (exactAlternateRole) {
    return exactAlternateRole;
  }

  // 4. Fallbacks: any slot in the player's group, else first preferred position.
  const firstGroupRole = formationSlots.find(
    (position) => positionTable.groupOf(position) === playerGroup,
  );

  return firstGroupRole ?? getPreferredPositions(player)[0] ?? naturalPosition;
}

export function buildRoleCoverageSummary(
  availablePlayers: PlayerData[],
  currentXiIds: string[],
  formation: string,
  positionTable: PositionTable,
  familiarity?: FamiliarityTable,
): SquadRoleCoverage[] {
  const slotPositions = buildPitchRows(formation).flatMap((row) => row.positions);
  const requiredByRole = new Map<string, number>();
  const naturalStartersByRole = new Map<string, number>();
  const benchOptionsByRole = new Map<string, number>();
  const xiSet = new Set(currentXiIds);
  const playersById = new Map(availablePlayers.map((player) => [player.id, player] as const));

  slotPositions.forEach((role) => {
    requiredByRole.set(role, (requiredByRole.get(role) ?? 0) + 1);
  });

  currentXiIds.forEach((playerId, slotIndex) => {
    const player = playersById.get(playerId);
    const slotPosition = slotPositions[slotIndex];

    if (!player || !slotPosition) {
      return;
    }

    if (getSquadTacticalFit(player, slotPosition, positionTable, familiarity) === "natural") {
      naturalStartersByRole.set(slotPosition, (naturalStartersByRole.get(slotPosition) ?? 0) + 1);
    }
  });

  availablePlayers
    .filter((player) => !xiSet.has(player.id))
    .forEach((player) => {
      const preferredPositions = new Set(getPreferredPositions(player));
      requiredByRole.forEach((_, role) => {
        if (preferredPositions.has(role)) {
          benchOptionsByRole.set(role, (benchOptionsByRole.get(role) ?? 0) + 1);
        }
      });
    });

  return [...requiredByRole.entries()]
    .map(([role, requiredSlots]) => {
      const naturalStarters = naturalStartersByRole.get(role) ?? 0;
      const benchOptions = benchOptionsByRole.get(role) ?? 0;
      const status: SquadRoleCoverageStatus =
        naturalStarters === 0 && benchOptions === 0
          ? "uncovered"
          : naturalStarters < requiredSlots || benchOptions === 0
            ? "thin"
            : "covered";

      return {
        role,
        requiredSlots,
        naturalStarters,
        benchOptions,
        status,
      };
    })
    .sort((leftRole, rightRole) => {
      const statusOrder: Record<SquadRoleCoverageStatus, number> = {
        uncovered: 0,
        thin: 1,
        covered: 2,
      };

      return (
        statusOrder[leftRole.status] - statusOrder[rightRole.status] ||
        leftRole.role.localeCompare(rightRole.role)
      );
    });
}

/**
 * Whether the screen can grade a lineup yet: the backend's position table has loaded and, for a
 * screen that reads the backend's familiarity, that has too. Nothing is picked or saved before.
 */
export function lineupReady(positionTable: PositionTable, familiarity?: FamiliarityTable): boolean {
  return positionTable.loaded && (familiarity?.loaded ?? true);
}

function getFitScore(
  player: PlayerData,
  currentPos: string,
  positionTable: PositionTable,
  familiarity?: FamiliarityTable,
): number {
  const fit = getSquadTacticalFit(player, currentPos, positionTable, familiarity);

  if (fit === "natural") return 2;
  if (fit === "adapted") return 1;
  // Out of position, or no grade: nothing is picked on a missing one (the builders wait for it).
  return 0;
}

export function buildPromoteToStartingXi(
  currentXiIds: string[],
  playersById: Map<string, PlayerData>,
  formation: string,
  playerId: string,
  positionTable: PositionTable,
  familiarity?: FamiliarityTable,
): string[] | null {
  // As for the best-fit slot: no lines known yet means no pick that could be saved.
  if (!lineupReady(positionTable, familiarity)) return currentXiIds;
  if (currentXiIds.includes(playerId)) {
    return currentXiIds;
  }

  const promotedPlayer = playersById.get(playerId);

  if (!promotedPlayer) {
    return null;
  }

  if (!isMatchDayEligible(promotedPlayer)) {
    return null;
  }

  const slotPositions = buildPitchRows(formation).flatMap((row) => row.positions);

  const targetSlotIndex = slotPositions
    .map((slotPosition, slotIndex) => {
      const incumbentId = currentXiIds[slotIndex];
      const incumbentPlayer = incumbentId ? (playersById.get(incumbentId) ?? null) : null;

      return {
        incumbentPlayer,
        slotIndex,
        slotPosition,
      };
    })
    .sort((leftSlot, rightSlot) => {
      const promotedLeftScore = getFitScore(
        promotedPlayer,
        leftSlot.slotPosition,
        positionTable,
        familiarity,
      );
      const promotedRightScore = getFitScore(
        promotedPlayer,
        rightSlot.slotPosition,
        positionTable,
        familiarity,
      );
      const incumbentLeftScore = leftSlot.incumbentPlayer
        ? getFitScore(leftSlot.incumbentPlayer, leftSlot.slotPosition, positionTable, familiarity)
        : -1;
      const incumbentRightScore = rightSlot.incumbentPlayer
        ? getFitScore(rightSlot.incumbentPlayer, rightSlot.slotPosition, positionTable, familiarity)
        : -1;
      const incumbentLeftOvr = leftSlot.incumbentPlayer
        ? getPlayerOvr(leftSlot.incumbentPlayer)
        : -1;
      const incumbentRightOvr = rightSlot.incumbentPlayer
        ? getPlayerOvr(rightSlot.incumbentPlayer)
        : -1;
      const incumbentLeftCondition = leftSlot.incumbentPlayer?.condition ?? -1;
      const incumbentRightCondition = rightSlot.incumbentPlayer?.condition ?? -1;

      return (
        promotedRightScore - promotedLeftScore ||
        incumbentLeftScore - incumbentRightScore ||
        incumbentLeftOvr - incumbentRightOvr ||
        incumbentLeftCondition - incumbentRightCondition ||
        leftSlot.slotIndex - rightSlot.slotIndex
      );
    })[0]?.slotIndex;

  if (targetSlotIndex == null || targetSlotIndex < 0) {
    return null;
  }

  const nextXiIds = [...currentXiIds];
  nextXiIds[targetSlotIndex] = playerId;
  return nextXiIds;
}

export function buildAssignStartingXiSlot(
  currentXiIds: string[],
  playerId: string,
  targetSlotIndex: number,
): string[] | null {
  const currentSlotIndex = currentXiIds.indexOf(playerId);

  if (currentSlotIndex < 0) {
    return null;
  }

  if (targetSlotIndex < 0 || targetSlotIndex >= currentXiIds.length) {
    return currentXiIds;
  }

  if (currentSlotIndex === targetSlotIndex) {
    return currentXiIds;
  }

  const nextXiIds = [...currentXiIds];
  [nextXiIds[currentSlotIndex], nextXiIds[targetSlotIndex]] = [
    nextXiIds[targetSlotIndex],
    nextXiIds[currentSlotIndex],
  ];

  return nextXiIds;
}

export function buildAssignBestFitSlot(
  currentXiIds: string[],
  playersById: Map<string, PlayerData>,
  formation: string,
  playerId: string,
  positionTable: PositionTable,
  familiarity?: FamiliarityTable,
): string[] | null {
  // Fit is graded by the backend's lines; without them every slot ties and the lowest index wins,
  // which is the keeper's. A pick made on that would be saved, so nothing is picked yet.
  if (!lineupReady(positionTable, familiarity)) return currentXiIds;
  const currentSlotIndex = currentXiIds.indexOf(playerId);

  if (currentSlotIndex < 0) {
    return null;
  }

  const slotPositions = buildPitchRows(formation).flatMap((row) => row.positions);
  const player = playersById.get(playerId);

  if (!player) {
    return null;
  }

  const bestSlotIndex = slotPositions
    .map((slotPosition, slotIndex) => ({
      fitScore: getFitScore(player, slotPosition, positionTable, familiarity),
      slotIndex,
    }))
    .sort((leftSlot, rightSlot) => {
      return rightSlot.fitScore - leftSlot.fitScore || leftSlot.slotIndex - rightSlot.slotIndex;
    })[0]?.slotIndex;

  if (bestSlotIndex == null) {
    return currentXiIds;
  }

  return buildAssignStartingXiSlot(currentXiIds, playerId, bestSlotIndex);
}

export function buildDemoteFromStartingXi(
  currentXiIds: string[],
  availablePlayers: PlayerData[],
  formation: string,
  playerId: string,
  positionTable: PositionTable,
  familiarity?: FamiliarityTable,
): string[] | null {
  // As for the best-fit slot: no lines known yet means no replacement that could be saved.
  if (!lineupReady(positionTable, familiarity)) return currentXiIds;
  const slotIndex = currentXiIds.indexOf(playerId);

  if (slotIndex < 0) {
    return currentXiIds;
  }

  const slotPosition = buildPitchRows(formation).flatMap((row) => row.positions)[slotIndex];
  const benchCandidates = availablePlayers.filter(
    (player) => !currentXiIds.includes(player.id) && player.id !== playerId,
  );
  const replacement = benchCandidates.sort((leftPlayer, rightPlayer) =>
    comparePlayersForSlot(leftPlayer, rightPlayer, slotPosition, positionTable, familiarity),
  )[0];

  if (!replacement) {
    return null;
  }

  const nextXiIds = [...currentXiIds];
  nextXiIds[slotIndex] = replacement.id;
  return nextXiIds;
}

export function applyLineupDrop(
  currentXiIds: string[],
  dragState: DragState,
  slotIndex: number,
): string[] {
  const nextXiIds = [...currentXiIds];

  if (slotIndex < 0 || slotIndex >= nextXiIds.length) {
    return nextXiIds;
  }

  if (dragState.from === "xi") {
    const fromIndex = dragState.slotIndex ?? nextXiIds.indexOf(dragState.playerId);
    if (fromIndex < 0 || fromIndex === slotIndex) {
      return nextXiIds;
    }
    [nextXiIds[fromIndex], nextXiIds[slotIndex]] = [nextXiIds[slotIndex], nextXiIds[fromIndex]];
    return nextXiIds;
  }

  const existingIndex = nextXiIds.indexOf(dragState.playerId);
  if (existingIndex === slotIndex) {
    return nextXiIds;
  }
  if (existingIndex >= 0) {
    nextXiIds.splice(existingIndex, 1);
    if (existingIndex < slotIndex) {
      slotIndex -= 1;
    }
    nextXiIds.splice(slotIndex, 0, dragState.playerId);
    return nextXiIds.slice(0, currentXiIds.length);
  }
  if (slotIndex >= nextXiIds.length) {
    nextXiIds.push(dragState.playerId);
  } else {
    nextXiIds[slotIndex] = dragState.playerId;
  }
  return nextXiIds.slice(0, currentXiIds.length);
}

export function applyLineupSwap(
  currentXiIds: string[],
  swapSource: { id: string; from: SquadSection },
  playerId: string,
  from: SquadSection,
): string[] | null {
  if (swapSource.from === "xi" && from === "bench") {
    return currentXiIds.map((id) => (id === swapSource.id ? playerId : id));
  }

  if (swapSource.from === "bench" && from === "xi") {
    return currentXiIds.map((id) => (id === playerId ? swapSource.id : id));
  }

  if (swapSource.from === "xi" && from === "xi") {
    const firstIndex = currentXiIds.indexOf(swapSource.id);
    const secondIndex = currentXiIds.indexOf(playerId);
    if (firstIndex < 0 || secondIndex < 0 || firstIndex === secondIndex) {
      return currentXiIds;
    }
    const nextXiIds = [...currentXiIds];
    nextXiIds[firstIndex] = playerId;
    nextXiIds[secondIndex] = swapSource.id;
    return nextXiIds;
  }

  return null;
}
