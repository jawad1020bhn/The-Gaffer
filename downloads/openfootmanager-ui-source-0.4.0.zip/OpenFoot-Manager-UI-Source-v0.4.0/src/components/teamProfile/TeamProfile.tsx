import { useTranslation } from "react-i18next";

import { usePlayerKnowledge } from "../../hooks/usePlayerKnowledge";
import { gameKnowledgeRevision } from "../../lib/playerKnowledge";

import type { TeamProfileProps } from "./TeamProfile.types";
import TeamProfileAdvancedStatsCard from "./TeamProfileAdvancedStatsCard";
import TeamProfileClubDetailsCard from "./TeamProfileClubDetailsCard";
import TeamProfileHeroCard from "./TeamProfileHeroCard";
import TeamProfileHistoryCard from "./TeamProfileHistoryCard";
import TeamProfileLeagueStandingCard from "./TeamProfileLeagueStandingCard";
import TeamProfileRecentMatchesCard from "./TeamProfileRecentMatchesCard";
import TeamProfileRosterCard from "./TeamProfileRosterCard";
import TeamProfileSummaryCard from "./TeamProfileSummaryCard";
import { useClubLeagueStanding } from "./useClubLeagueStanding";
import { useTeamAverageRating } from "./useTeamAverageRating";
import { useTeamProfileStats } from "./useTeamProfileStats";
import { buildTeamProfileViewModel } from "./TeamProfile.viewModel";
import { usePositionTable } from "../../hooks/usePositionGroups";

export default function TeamProfile({
  team,
  gameState,
  isOwnTeam,
  onSelectPlayer,
}: TeamProfileProps) {
  const { t, i18n } = useTranslation();
  const { standing: leagueStanding } = useClubLeagueStanding(team.id, gameState.clock.current_date);
  const positions = usePositionTable();
  const viewModel = buildTeamProfileViewModel(team, gameState, leagueStanding, positions);
  const { teamStatsOverview, recentMatches } = useTeamProfileStats(team.id);
  const revision = gameKnowledgeRevision(gameState, { playerClubId: team.id });
  const knowledgeOf = usePlayerKnowledge(
    viewModel.roster.map((player) => player.id),
    revision,
  );
  // The backend's average, never one worked out here: none for a club outside the division.
  const averageRating = useTeamAverageRating(team.id, revision);

  return (
    <div className="max-w-6xl mx-auto">
      <TeamProfileHeroCard
        team={team}
        viewModel={viewModel}
        averageRating={averageRating}
        locale={i18n.language}
        t={t}
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <TeamProfileClubDetailsCard team={team} t={t} />
        <TeamProfileSummaryCard
          team={team}
          isOwnTeam={isOwnTeam}
          viewModel={viewModel}
          averageRating={averageRating}
          t={t}
        />
        <TeamProfileLeagueStandingCard standings={viewModel.standings} t={t} />

        {teamStatsOverview && <TeamProfileAdvancedStatsCard overview={teamStatsOverview} t={t} />}

        <TeamProfileRecentMatchesCard matches={recentMatches} t={t} />

        <TeamProfileRosterCard
          roster={viewModel.roster}
          knowledgeOf={knowledgeOf}
          isOwnTeam={isOwnTeam}
          locale={i18n.language}
          t={t}
          onSelectPlayer={onSelectPlayer}
        />
        <TeamProfileHistoryCard history={team.history} t={t} />
      </div>
    </div>
  );
}
