import { describe, expect, it } from "vitest";

import type { GameStateData, PlayerData, TeamData } from "../../store/gameStore";
import type { ClubLeagueStanding } from "./TeamProfile.types";
import { cannedPositionTable } from "../../test-utils/positionTable";
import { buildTeamProfileViewModel } from "./TeamProfile.viewModel";
import { createSeasonContext } from "../../test-utils/factories";

function createTeam(overrides: Partial<TeamData> = {}): TeamData {
  return {
    id: "team-1",
    name: "Alpha FC",
    short_name: "ALP",
    country: "BR",
    city: "Rio",
    stadium_name: "Alpha Arena",
    stadium_capacity: 50000,
    finance: 500000,
    manager_id: "manager-1",
    reputation: 60,
    wage_budget: 100000,
    transfer_budget: 250000,
    season_income: 150000,
    season_expenses: 0,
    formation: "4-4-2",
    play_style: "Balanced",
    training_focus: "Physical",
    training_intensity: "Medium",
    training_schedule: "Balanced",
    founded_year: 1900,
    colors: { primary: "#111111", secondary: "#ffffff" },
    starting_xi_ids: [],
    form: [],
    history: [],
    ...overrides,
  };
}

function createPlayer(overrides: Partial<PlayerData> = {}): PlayerData {
  return {
    id: "player-1",
    match_name: "J. Smith",
    full_name: "John Smith",
    date_of_birth: "2000-01-01",
    nationality: "BR",
    position: "Forward",
    natural_position: "Forward",
    alternate_positions: [],
    training_focus: null,
    attributes: {
      pace: 60,
      stamina: 60,
      strength: 60,
      agility: 60,
      passing: 60,
      shooting: 60,
      tackling: 60,
      dribbling: 60,
      defending: 60,
      positioning: 60,
      vision: 60,
      decisions: 60,
      composure: 60,
      aggression: 60,
      teamwork: 60,
      leadership: 60,
      handling: 20,
      reflexes: 20,
      aerial: 60,
    },
    condition: 85,
    morale: 80,
    injury: null,
    team_id: "team-1",
    retired: false,
    contract_end: null,
    wage: 12000,
    market_value: 350000,
    stats: {
      appearances: 0,
      goals: 0,
      assists: 0,
      clean_sheets: 0,
      yellow_cards: 0,
      red_cards: 0,
      avg_rating: 0,
      minutes_played: 0,
    },
    career: [],
    transfer_listed: false,
    loan_listed: false,
    transfer_offers: [],
    traits: [],
    ovr: 60,
    ...overrides,
  };
}

function createGameState(overrides: Partial<GameStateData> = {}): GameStateData {
  return {
    season_context: createSeasonContext(),
    clock: {
      current_date: "2026-08-10T00:00:00Z",
      start_date: "2026-07-01T00:00:00Z",
    },
    manager: {
      display_name: "Jane Doe",
      id: "manager-1",
      first_name: "Jane",
      last_name: "Doe",
      date_of_birth: "1980-01-01",
      nationality: "BR",
      reputation: 50,
      satisfaction: 50,
      fan_approval: 50,
      team_id: "team-1",
      career_stats: {
        matches_managed: 0,
        wins: 0,
        draws: 0,
        losses: 0,
        trophies: 0,
        best_finish: null,
      },
      career_history: [],
    },
    teams: [createTeam()],
    players: [
      createPlayer({
        id: "goalkeeper",
        full_name: "Goal Keeper",
        position: "Goalkeeper",
        natural_position: "Goalkeeper",
      }),
      createPlayer({
        id: "forward",
        full_name: "Front Man",
        position: "Forward",
        natural_position: "Forward",
      }),
      createPlayer({
        id: "midfielder",
        full_name: "Mid Field",
        position: "Midfielder",
        natural_position: "Midfielder",
      }),
    ],
    staff: [],
    messages: [],
    news: [],
    league: {
      id: "league-1",
      name: "League",
      season: 1,
      fixtures: [],
      standings: [
        {
          team_id: "team-2",
          played: 1,
          won: 1,
          drawn: 0,
          lost: 0,
          goals_for: 2,
          goals_against: 0,
          points: 3,
        },
        {
          team_id: "team-1",
          played: 1,
          won: 0,
          drawn: 0,
          lost: 1,
          goals_for: 0,
          goals_against: 2,
          points: 0,
        },
      ],
    },
    scouting_assignments: [],
    board_objectives: [],
    ...overrides,
  };
}

describe("TeamProfile.viewModel", () => {
  it("builds a sorted roster and derived team summary", () => {
    const gameState = createGameState();

    const viewModel = buildTeamProfileViewModel(
      createTeam(),
      gameState,
      null,
      cannedPositionTable(),
    );

    expect(viewModel.roster.map((player) => player.id)).toEqual([
      "goalkeeper",
      "midfielder",
      "forward",
    ]);
    expect(viewModel.totalWages).toBe(36000);
    expect(viewModel.totalValue).toBe(1050000);
    expect(viewModel.manager?.id).toBe("manager-1");
  });

  it("sorts a roster whose positions are granular, not legacy buckets", () => {
    // The sort above passes only because its fixture uses the four legacy
    // bucket names. `domain::player::Position` has thirteen granular variants
    // as well — and `is_legacy_bucket()` exists precisely because the buckets
    // are the old shape. A generated squad is granular, so this is the case
    // the team profile actually renders.
    const gameState = createGameState();
    gameState.players = [
      createPlayer({
        id: "striker",
        full_name: "S. Triker",
        position: "Striker",
        natural_position: "Striker",
      }),
      createPlayer({
        id: "keeper",
        full_name: "K. Eeper",
        position: "Goalkeeper",
        natural_position: "Goalkeeper",
      }),
      createPlayer({
        id: "centre-back",
        full_name: "C. Back",
        position: "CenterBack",
        natural_position: "CenterBack",
      }),
    ];

    const viewModel = buildTeamProfileViewModel(
      createTeam(),
      gameState,
      null,
      cannedPositionTable(),
    );

    expect(viewModel.roster.map((player) => player.id)).toEqual([
      "keeper",
      "centre-back",
      "striker",
    ]);
  });

  it("counts loan wage commitments instead of full current-roster wages", () => {
    const team = createTeam({ id: "team-1" });
    const gameState = createGameState({
      players: [
        createPlayer({
          id: "owned-player",
          team_id: "team-1",
          wage: 10000,
        }),
        createPlayer({
          id: "loaned-out",
          team_id: "team-2",
          wage: 20000,
          active_loan: {
            parent_team_id: "team-1",
            loan_team_id: "team-2",
            start_date: "2026-08-01",
            end_date: "2027-01-28",
            wage_contribution_pct: 60,
            buy_option_fee: null,
          },
        }),
        createPlayer({
          id: "loaned-in",
          team_id: "team-1",
          wage: 30000,
          active_loan: {
            parent_team_id: "team-2",
            loan_team_id: "team-1",
            start_date: "2026-08-01",
            end_date: "2027-01-28",
            wage_contribution_pct: 50,
            buy_option_fee: null,
          },
        }),
      ],
    });

    const viewModel = buildTeamProfileViewModel(team, gameState, null, cannedPositionTable());

    expect(viewModel.roster.map((player) => player.id)).toEqual(["owned-player", "loaned-in"]);
    expect(viewModel.totalWages).toBe(33000);
  });

  const backendStanding: ClubLeagueStanding = {
    competition_id: "division-2",
    competition_name: "Division 2",
    league_pos: 4,
    standing: {
      played: 10,
      won: 6,
      drawn: 2,
      lost: 2,
      goals_for: 18,
      goals_against: 9,
      points: 20,
    },
  };

  /**
   * Given the backend's answer for a club's league table
   * When the profile view model is built
   * Then it shows the backend's position and record, whatever the game state's own league holds
   */
  it("shows the backend's league position and standing", () => {
    const viewModel = buildTeamProfileViewModel(
      createTeam(),
      createGameState(),
      backendStanding,
      cannedPositionTable(),
    );

    expect(viewModel.leaguePos).toBe(4);
    expect(viewModel.standings?.points).toBe(20);
  });

  /**
   * Given the backend has no league table for the club (a cup only, or no competition)
   * When the view model is built
   * Then there is no league position and no standing
   */
  it("shows no league position when the backend has none", () => {
    const viewModel = buildTeamProfileViewModel(
      createTeam(),
      createGameState(),
      null,
      cannedPositionTable(),
    );

    expect(viewModel.leaguePos).toBe(0);
    expect(viewModel.standings).toBeNull();
  });
});
