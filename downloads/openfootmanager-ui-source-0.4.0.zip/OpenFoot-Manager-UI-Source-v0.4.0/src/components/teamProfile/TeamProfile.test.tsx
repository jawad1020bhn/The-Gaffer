import { fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { describe, expect, it, vi, beforeEach } from "vitest";
import { invoke } from "@tauri-apps/api/core";

import type { GameStateData, PlayerData, TeamData } from "../../store/gameStore";
import type { PlayerKnowledge } from "../../services/scoutingService";
import { ratingTierClass } from "../../lib/ratingTier";
import TeamProfile from "./TeamProfile";
import { createSeasonContext } from "../../test-utils/factories";

vi.mock("../../hooks/usePositionGroups", async () => {
  const { cannedPositionsModule } = await import("../../test-utils/positionTable");
  return cannedPositionsModule();
});

vi.mock("../../hooks/useRatingTiers", async () => {
  const { cannedRatingTiersModule } = await import("../../test-utils/ratingTiers");
  return cannedRatingTiersModule();
});

vi.mock("@tauri-apps/api/core", () => ({
  invoke: vi.fn(),
}));

// What the club knows about each player, as the backend's `player_knowledge` would answer, by id.
// Everyone not named reads as the club's own, which most of these tests render.
const knowledge = vi.hoisted(() => ({
  current: {} as Record<string, PlayerKnowledge>,
}));

vi.mock("../../hooks/usePlayerKnowledge", () => ({
  usePlayerKnowledge: () => (playerId: string) =>
    knowledge.current[playerId] ?? ({ kind: "own" } as const),
}));

vi.mock("react-i18next", () => ({
  initReactI18next: {
    type: "3rdParty",
    init: () => {},
  },
  useTranslation: () => ({
    t: (key: string) => {
      const map: Record<string, string> = {
        "common.back": "Back",
        "teams.avgOvr": "Avg OVR",
        "teams.rep": "Rep",
        "teams.squad": "Squad",
        "teams.est": "Est.",
        "manager.reputation": "Reputation",
        "teamProfile.leaguePos": "League Pos",
        "teamProfile.managerLabel": "Manager:",
        "teamProfile.clubInfo": "Club Information",
        "teamProfile.stadium": "Stadium",
        "teamProfile.capacity": "Capacity",
        "dashboard.finances": "Finances",
        "teamProfile.balance": "Balance",
        "teamProfile.totalWages": "Total Wages",
        "teamProfile.squadOverview": "Squad Overview",
        "teamProfile.squadSize": "Squad Size",
        "teamProfile.leagueStanding": "League Standing",
        "teamProfile.advancedStats": "Team Stats",
        "teamProfile.matchesPlayed": "Matches",
        "teamProfile.possession": "Possession",
        "teamProfile.goalDifference": "Goal Difference",
        "teamProfile.shots": "Shots",
        "teamProfile.shotsOnTarget": "Shots On Target",
        "teamProfile.passes": "Passes",
        "teamProfile.tacklesWon": "Tackles Won",
        "teamProfile.interceptions": "Interceptions",
        "teamProfile.foulsCommitted": "Fouls Committed",
        "teamProfile.perMatch": "Per Match",
        "teamProfile.passAccuracy": "Pass Accuracy",
        "finances.wageBudget": "Wage Budget",
        "finances.transferBudget": "Transfer Budget",
        "finances.squadValue": "Squad Value",
        "finances.seasonIncome": "Season Income",
        "finances.perWeekSuffix": "/wk",
        "tactics.formation": "Formation",
        "tactics.playStyle": "Play Style",
        "common.played": "P",
        "common.won": "W",
        "common.drawn": "D",
        "common.lost": "L",
        "common.gf": "GF",
        "common.ga": "GA",
        "common.gd": "GD",
        "common.pts": "Pts",
        "common.position": "Pos",
        "common.name": "Name",
        "common.age": "Age",
        "common.nationality": "Nationality",
        "common.value": "Value",
        "common.ovr": "OVR",
        "squad.viewProfile": "View profile",
      };

      return map[key] ?? key;
    },
    i18n: { language: "en" },
  }),
}));

vi.mock("../../lib/countries", () => ({
  countryName: () => "England",
  isValidCountryCode: () => true,
  normaliseNationality: (value: string) => value,
  resolveCountryFlagCode: () => "GB",
}));

function createTeam(overrides: Partial<TeamData> = {}): TeamData {
  return {
    id: "team-1",
    name: "Alpha FC",
    short_name: "ALP",
    country: "GB",
    city: "London",
    stadium_name: "Alpha Ground",
    stadium_capacity: 30000,
    finance: 500000,
    manager_id: "manager-1",
    reputation: 50,
    wage_budget: 50000,
    transfer_budget: 250000,
    season_income: 100000,
    season_expenses: 0,
    formation: "4-4-2",
    play_style: "Balanced",
    training_focus: "General",
    training_intensity: "Balanced",
    training_schedule: "Balanced",
    founded_year: 1900,
    colors: { primary: "#000000", secondary: "#ffffff" },
    starting_xi_ids: [],
    form: [],
    history: [],
    ...overrides,
  };
}

function createPlayer(overrides: Partial<PlayerData> = {}): PlayerData {
  return {
    id: "player-1",
    match_name: "J. Smith",
    full_name: "John Smith",
    date_of_birth: "2000-01-01",
    nationality: "GB",
    position: "Forward",
    natural_position: "Forward",
    alternate_positions: [],
    training_focus: null,
    attributes: {
      pace: 60,
      stamina: 60,
      strength: 60,
      agility: 60,
      passing: 60,
      shooting: 60,
      tackling: 60,
      dribbling: 60,
      defending: 60,
      positioning: 60,
      vision: 60,
      decisions: 60,
      composure: 60,
      aggression: 60,
      teamwork: 60,
      leadership: 60,
      handling: 20,
      reflexes: 20,
      aerial: 60,
    },
    condition: 80,
    morale: 75,
    injury: null,
    team_id: "team-1",
    retired: false,
    contract_end: null,
    wage: 12000,
    market_value: 350000,
    stats: {
      appearances: 0,
      goals: 0,
      assists: 0,
      clean_sheets: 0,
      yellow_cards: 0,
      red_cards: 0,
      avg_rating: 0,
      minutes_played: 0,
    },
    career: [],
    transfer_listed: false,
    loan_listed: false,
    transfer_offers: [],
    traits: [],
    ...overrides,
  };
}

function createGameState(team: TeamData): GameStateData {
  return {
    season_context: createSeasonContext(),
    clock: {
      current_date: "2026-08-10T00:00:00Z",
      start_date: "2026-07-01T00:00:00Z",
    },
    manager: {
      display_name: "Jane Doe",
      id: "manager-1",
      first_name: "Jane",
      last_name: "Doe",
      date_of_birth: "1980-01-01",
      nationality: "GB",
      reputation: 50,
      satisfaction: 50,
      fan_approval: 50,
      team_id: team.id,
      career_stats: {
        matches_managed: 0,
        wins: 0,
        draws: 0,
        losses: 0,
        trophies: 0,
        best_finish: null,
      },
      career_history: [],
    },
    teams: [team],
    players: [createPlayer()],
    staff: [],
    messages: [],
    news: [],
    league: {
      id: "league-1",
      name: "League",
      season: 1,
      fixtures: [],
      standings: [
        {
          team_id: team.id,
          played: 2,
          won: 1,
          drawn: 1,
          lost: 0,
          goals_for: 5,
          goals_against: 1,
          points: 4,
        },
      ],
    },
    scouting_assignments: [],
    board_objectives: [],
  };
}

describe("TeamProfile", () => {
  beforeEach(() => {
    knowledge.current = {};
    vi.mocked(invoke).mockReset();
    vi.mocked(invoke).mockResolvedValue(null);
  });

  /**
   * Given a club's profile, shown under the dashboard header that already has a Back
   * When it renders
   * Then it adds no second Back of its own
   */
  it("leaves Back to the dashboard header", async () => {
    const team = createTeam();

    render(<TeamProfile team={team} gameState={createGameState(team)} isOwnTeam={false} />);

    expect(await screen.findByText(team.name)).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Back" })).not.toBeInTheDocument();
  });

  /**
   * Given a club the backend places 3rd in its own division's table
   * When its profile opens
   * Then the position and the league standing card come from that answer
   */
  it("shows the league position the backend gives for the club", async () => {
    const team = createTeam();
    vi.mocked(invoke).mockImplementation(async (command: string, args?: unknown) => {
      if (command === "get_club_league_standing") {
        expect(args).toEqual({ teamId: team.id });
        return {
          competition_id: "division-2",
          competition_name: "Division 2",
          league_pos: 3,
          standing: {
            played: 7,
            won: 4,
            drawn: 1,
            lost: 2,
            goals_for: 11,
            goals_against: 6,
            points: 13,
          },
        };
      }
      return null;
    });
    const state = createGameState(team);
    state.league = null;

    render(<TeamProfile team={team} gameState={state} isOwnTeam={false} />);

    expect(await screen.findAllByText("#3")).not.toHaveLength(0);
    expect(screen.getByText("13")).toBeInTheDocument();
  });

  it("loads and renders team stats overview from the backend", async () => {
    const team = createTeam();
    vi.mocked(invoke).mockImplementation(async (command: string) => {
      if (command === "get_team_stats_overview") {
        return {
          matchesPlayed: 12,
          goalsFor: 24,
          goalsAgainst: 10,
          goalDifference: 14,
          possessionAverage: 57.5,
          metrics: {
            shots: { total: 160, perMatch: 13.3 },
            shotsOnTarget: { total: 68, perMatch: 5.7 },
            passes: { completed: 5400, attempted: 6300, accuracy: 85.7 },
            tacklesWon: { total: 220, perMatch: 18.3 },
            interceptions: { total: 150, perMatch: 12.5 },
            foulsCommitted: { total: 110, perMatch: 9.2 },
          },
        };
      }

      return null;
    });

    render(<TeamProfile team={team} gameState={createGameState(team)} isOwnTeam />);

    await waitFor(() => {
      expect(invoke).toHaveBeenCalledWith("get_team_stats_overview", {
        teamId: "team-1",
      });
      expect(screen.getByText("Team Stats")).toBeInTheDocument();
      expect(screen.getByText("24")).toBeInTheDocument();
      expect(screen.getByText("57.5%")).toBeInTheDocument();
      expect(screen.getByText("5400 / 6300")).toBeInTheDocument();
      expect(screen.getByText("85.7%")).toBeInTheDocument();
    });
  });

  it("loads and renders recent team match history from the backend", async () => {
    const team = createTeam();
    vi.mocked(invoke).mockImplementation(async (command: string) => {
      if (command === "get_team_match_history") {
        return [
          {
            fixtureId: "fixture-2",
            date: "2026-08-01",
            competition: "League",
            matchday: 1,
            opponentTeamId: "team-2",
            opponentName: "Bravo FC",
            goalsFor: 3,
            goalsAgainst: 1,
            possessionPct: 62,
            shots: 16,
            shotsOnTarget: 7,
          },
        ];
      }

      if (command === "get_team_stats_overview") {
        return null;
      }

      return null;
    });

    render(<TeamProfile team={team} gameState={createGameState(team)} isOwnTeam />);

    await waitFor(() => {
      expect(invoke).toHaveBeenCalledWith("get_team_match_history", {
        teamId: "team-1",
        limit: 5,
      });
      expect(screen.getByText("Bravo FC")).toBeInTheDocument();
      expect(screen.getByText("3-1")).toBeInTheDocument();
      expect(screen.getByText("62.0%")).toBeInTheDocument();
    });
  });

  /**
   * Given the user's own club with players rated 76 and 77 (and a rival's, whose ratings are hidden)
   * When the roster renders
   * Then the own club's ratings take the colour of their backend tier, and a hidden one reads as the rest.
   */
  it("colours the own club's ratings by their backend tier", async () => {
    const team = createTeam();
    const state = createGameState(team);
    state.players = [
      createPlayer({ id: "p-76", full_name: "Seventy Six", match_name: "S. Six", ovr: 76 }),
      createPlayer({ id: "p-77", full_name: "Seventy Seven", match_name: "S. Seven", ovr: 77 }),
    ].map((player) => ({ ...player, team_id: team.id }));

    render(<TeamProfile team={team} gameState={state} isOwnTeam />);

    const ratingOf = async (name: string, rating: string) =>
      within((await screen.findByText(name)).closest("tr") as HTMLElement).getByText(rating);
    expect(await ratingOf("Seventy Seven", "77")).toHaveClass(
      ...ratingTierClass("A", "text").split(" "),
    );
    expect(await ratingOf("Seventy Six", "76")).toHaveClass(
      ...ratingTierClass("B", "text").split(" "),
    );
  });

  // A rival club's profile opened from the user's club: one rival player rated 77.
  function renderRivalWith(playerKnowledge: PlayerKnowledge) {
    const mine = createTeam({ id: "mine", name: "Mine FC" });
    const rival = createTeam({ id: "rival", name: "Rival FC" });
    const state = createGameState(mine);
    state.teams = [mine, rival];
    state.players = [
      createPlayer({
        id: "r-77",
        full_name: "Rival Seventy Seven",
        match_name: "R. Seven",
        ovr: 77,
        team_id: "rival",
      }),
    ];
    knowledge.current = { "r-77": playerKnowledge };

    render(<TeamProfile team={rival} gameState={state} isOwnTeam={false} />);
    // His row's cell under the roster's OVR column, found by role and name, not by test id.
    return async () => {
      const row = (await screen.findByText("Rival Seventy Seven")).closest("tr") as HTMLElement;
      const headers = within(row.closest("table") as HTMLElement).getAllByRole("columnheader");
      const ovrColumn = headers.findIndex((header) => header.textContent === "OVR");
      return within(row).getAllByRole("cell")[ovrColumn].firstElementChild as HTMLElement;
    };
  }

  /**
   * Given a rival club in the user's own division, its player rated 77
   * When its roster renders
   * Then his rating shows, in its backend tier's colour, as the staff see him every season
   */
  it("shows a known rival's rating on his club's roster", async () => {
    const rating = await renderRivalWith({ kind: "known" })();

    expect(rating).toHaveTextContent("77");
    expect(rating).toHaveClass(...ratingTierClass("A", "text").split(" "));
  });

  /**
   * Given a rival club in another division, its player never scouted
   * When its roster renders
   * Then his rating reads "–", as on his profile: nothing the club could not know
   */
  it("shows an unknown rival's rating as a dash on his club's roster", async () => {
    const rating = await renderRivalWith({ kind: "unknown" })();

    expect(rating).toHaveTextContent("–");
    expect(rating).not.toHaveTextContent("77");
  });

  /**
   * Given a rival club in another division, its player scouted (the report holds his attributes,
   *      not a rating)
   * When its roster renders
   * Then his rating reads "–", as on his profile until a scout's estimate exists
   */
  it("shows a scouted rival's rating as a dash on his club's roster", async () => {
    const rating = await renderRivalWith({
      kind: "scouted",
      scouted_on: "2026-07-20",
      current: true,
    })();

    expect(rating).toHaveTextContent("–");
  });

  it("offers a roster context menu action to view the player profile", async () => {
    const team = createTeam();
    const onSelectPlayer = vi.fn();

    render(
      <TeamProfile
        team={team}
        gameState={createGameState(team)}
        isOwnTeam
        onSelectPlayer={onSelectPlayer}
      />,
    );

    await waitFor(() => {
      expect(invoke).toHaveBeenCalledWith("get_team_stats_overview", {
        teamId: "team-1",
      });
      expect(invoke).toHaveBeenCalledWith("get_team_match_history", {
        teamId: "team-1",
        limit: 5,
      });
    });

    fireEvent.contextMenu(screen.getByTestId("team-profile-roster-player-1"));
    fireEvent.click(screen.getByRole("menuitem", { name: "View profile" }));

    expect(onSelectPlayer).toHaveBeenCalledWith("player-1");
  });
});

describe("the team profile's average rating", () => {
  beforeEach(() => {
    knowledge.current = {};
    vi.mocked(invoke).mockReset();
  });

  // A rival club, its one player rated 61, so an average worked out on screen would read 61; the
  // backend's card says 73 when the club may see it.
  const rival = createTeam({ id: "rival", name: "Rival FC", reputation: 64 });
  const rivalState = (): GameStateData => {
    const state = createGameState(createTeam());
    return { ...state, players: [createPlayer({ team_id: rival.id, ovr: 61 })] };
  };

  /** The card the backend sends for the rival, with `avgOvr` as its average (null: withheld). */
  function answerCard(avgOvr: number | null) {
    vi.mocked(invoke).mockImplementation(async (command: string, args?: unknown) => {
      if (command !== "get_team_card") return null;
      expect(args).toEqual({ teamId: rival.id });
      return { team: { id: rival.id, reputation: rival.reputation }, avg_ovr: avgOvr };
    });
  }

  /** Every average the profile shows: the hero's (wide and narrow layouts) and the summary's. */
  const shownAverages = () =>
    screen.getAllByText("Avg OVR").map((label) => label.nextElementSibling?.textContent);

  /** The summary card: its heading sits in the card's header, which sits in the card. */
  const summaryCard = (): HTMLElement => {
    const card = screen.getByRole("heading", { name: "Squad Overview" }).parentElement
      ?.parentElement;
    if (!card) throw new Error("no summary card");
    return card;
  };

  /**
   * Given a rival in the manager's division, whose card the backend sends with an average of 73
   * When his club's profile opens
   * Then the hero and the summary show the backend's 73, not an average worked out on screen
   */
  it("shows the average the backend gives for a club in the manager's division", async () => {
    answerCard(73);

    render(<TeamProfile team={rival} gameState={rivalState()} isOwnTeam={false} />);

    await waitFor(() => expect(shownAverages()).toEqual(["73", "73", "73"]));
  });

  /**
   * Given a club outside the manager's division, whose card the backend sends with no average
   * When its profile opens
   * Then the hero shows "–" for the average, and the summary shows the club's reputation instead
   */
  it("shows a dash, and the reputation in the summary, for a club outside the division", async () => {
    answerCard(null);

    render(<TeamProfile team={rival} gameState={rivalState()} isOwnTeam={false} />);

    await waitFor(() => expect(invoke).toHaveBeenCalledWith("get_team_card", { teamId: "rival" }));
    expect(shownAverages()).toEqual(["–", "–"]);
    const summary = within(summaryCard());
    expect(summary.queryByText("Avg OVR")).not.toBeInTheDocument();
    expect(summary.getByText("Reputation").nextElementSibling).toHaveTextContent(/^64$/);
  });

  /**
   * Given a rival's profile showing his club's average of 73
   * When the manager takes a job at another club and the card for the new club's view is still
   *      on its way
   * Then the average reads "–": the old club's answer is not the new club's
   */
  it("hides the old club's average while the new club's card is on its way", async () => {
    answerCard(73);
    const before = rivalState();
    const { rerender } = render(<TeamProfile team={rival} gameState={before} isOwnTeam={false} />);
    await waitFor(() => expect(shownAverages()).toEqual(["73", "73", "73"]));
    vi.mocked(invoke).mockImplementation(() => new Promise(() => {}));

    rerender(
      <TeamProfile
        team={rival}
        gameState={{ ...before, manager: { ...before.manager, team_id: "elsewhere" } }}
        isOwnTeam={false}
      />,
    );

    await waitFor(() => expect(shownAverages()).toEqual(["–", "–"]));
  });
});
