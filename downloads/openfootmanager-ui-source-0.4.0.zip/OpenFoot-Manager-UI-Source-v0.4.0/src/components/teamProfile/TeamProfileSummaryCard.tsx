import { DollarSign, Star, Trophy, Users } from "lucide-react";

import { weeklyWageAmount } from "../../lib/finance";
import { formatVal, formatWeeklyWage } from "../../lib/helpers";
import type { TeamData } from "../../store/gameStore";
import { Card, CardBody, CardHeader } from "../ui";
import type { TeamProfileTranslate, TeamProfileViewModel } from "./TeamProfile.types";
import { InfoRow } from "./TeamProfile.primitives";

interface TeamProfileSummaryCardProps {
  team: TeamData;
  isOwnTeam: boolean;
  viewModel: TeamProfileViewModel;
  /** The squad's average rating as the backend gives it; null when the club may not see it. */
  averageRating: number | null;
  t: TeamProfileTranslate;
}

export default function TeamProfileSummaryCard({
  team,
  isOwnTeam,
  viewModel,
  averageRating,
  t,
}: TeamProfileSummaryCardProps) {
  if (isOwnTeam) {
    return (
      <Card accent="accent">
        <CardHeader>{t("dashboard.finances")}</CardHeader>
        <CardBody>
          <div className="flex flex-col gap-3">
            <InfoRow
              icon={<DollarSign className="w-4 h-4" />}
              label={t("teamProfile.balance")}
              value={formatVal(team.finance)}
            />
            <InfoRow
              icon={<DollarSign className="w-4 h-4" />}
              label={t("finances.wageBudget")}
              value={formatWeeklyWage(weeklyWageAmount(team.wage_budget), "compact")}
            />
            <InfoRow
              icon={<DollarSign className="w-4 h-4" />}
              label={t("finances.transferBudget")}
              value={formatVal(team.transfer_budget)}
            />
            <InfoRow
              icon={<DollarSign className="w-4 h-4" />}
              label={t("teamProfile.totalWages")}
              value={formatWeeklyWage(weeklyWageAmount(viewModel.totalWages), "compact")}
            />
            <InfoRow
              icon={<DollarSign className="w-4 h-4" />}
              label={t("finances.squadValue")}
              value={formatVal(viewModel.totalValue)}
            />
            <InfoRow
              icon={<DollarSign className="w-4 h-4" />}
              label={t("finances.seasonIncome")}
              value={formatVal(team.season_income)}
            />
          </div>
        </CardBody>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>{t("teamProfile.squadOverview")}</CardHeader>
      <CardBody>
        <div className="flex flex-col gap-3">
          <InfoRow
            icon={<Users className="w-4 h-4" />}
            label={t("teamProfile.squadSize")}
            value={String(viewModel.roster.length)}
          />
          <InfoRow
            icon={<DollarSign className="w-4 h-4" />}
            label={t("finances.squadValue")}
            value={formatVal(viewModel.totalValue)}
          />
          {/* A squad the club does not know shows the club's public standing instead of its
              average: never an average of the few players a scout has seen (maintainer, L2c). */}
          {averageRating === null ? (
            <InfoRow
              icon={<Star className="w-4 h-4" />}
              label={t("manager.reputation")}
              value={String(team.reputation)}
            />
          ) : (
            <InfoRow
              icon={<Trophy className="w-4 h-4" />}
              label={t("teams.avgOvr")}
              value={String(averageRating)}
            />
          )}
        </div>
      </CardBody>
    </Card>
  );
}
