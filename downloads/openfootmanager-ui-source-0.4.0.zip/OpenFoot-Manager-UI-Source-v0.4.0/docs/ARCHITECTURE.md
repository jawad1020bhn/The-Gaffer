# Architecture

OpenFoot Manager is a desktop football management simulation built with **Tauri** (Rust backend) and **React** (TypeScript frontend). This document describes the project structure, key architectural decisions, and how the pieces fit together.

---

## Technology Stack

| Layer | Technology | Purpose |
|-------|-----------|---------|
| **Desktop shell** | Tauri v2 | Native window, IPC, file system access |
| **Backend** | Rust | Game logic, simulation, persistence |
| **Frontend** | React + TypeScript | UI rendering, user interaction |
| **Styling** | Tailwind CSS | Utility-first CSS framework |
| **State (frontend)** | Zustand | Lightweight stores for game and settings |
| **i18n** | i18next + react-i18next | Internationalization (7 locales) |
| **Build** | Vite | Frontend bundler and dev server |

---

## Project Structure

```
openfootmanager/
├── src/                          # Frontend (React + TypeScript)
│   ├── components/               # Reusable UI components
│   │   ├── match/                # Match day sub-components
│   │   └── ui/                   # Design system primitives (Badge, ThemeToggle)
│   ├── context/                  # React contexts (ThemeContext)
│   ├── i18n/                     # Internationalization config + locale files
│   │   └── locales/              # en.json, de.json, es.json, fr.json, it.json, pt.json, pt-BR.json
│   ├── lib/                      # Shared utilities (helpers.ts, countries.ts)
│   ├── pages/                    # Route-level pages
│   ├── services/                 # Frontend Tauri/invoke wrappers
│   ├── store/                    # Zustand stores (gameStore, settingsStore)
│   ├── utils/                    # Frontend helpers and i18n adapters
│   ├── App.tsx                   # Router setup
│   └── main.tsx                  # Entry point
├── src-tauri/                    # Backend (Rust + Tauri)
│   ├── src/
│   │   └── lib.rs                # Tauri commands, app setup, settings
│   ├── crates/
│   │   ├── domain/               # Pure data types (no logic)
│   │   ├── engine/               # Match simulation engine
│   │   ├── ofm_core/             # Game logic, state, turn processing
│   │   └── db/                   # Save/load persistence
│   ├── data/                     # External definition files (names, teams JSON)
│   └── databases/                # Bundled world database files
├── docs/                         # Documentation
├── public/                       # Static assets
└── images/                       # Branding assets
```

---

## Crate Architecture

The Rust workspace holds seven packages — four library crates, two binaries, and the Tauri
application itself — with these dependency boundaries:

Listed rather than drawn, because the previous box diagram put `engine` on top of `domain` — the
one edge this codebase forbids — and put `db` below `ofm_core`, which is backwards. Each arrow
below is a `path` dependency in that crate's own `Cargo.toml`, and
`src-tauri/tests/architecture.rs` fails the build if the two leaves ever gain one.

```text
  Tauri commands          src/commands/, src/application/, src/mcp_server/
                          → domain, engine, ofm_core, db

  db                      SQLite persistence
                          → domain, ofm_core

  ofm_core                game logic, state, turn processing
                          → domain, engine

  engine                  match simulation          → nothing in this workspace
  domain                  pure data types           → nothing in this workspace

  ofm-cli                 standalone CLI binary     → ofm_core
  sim-bench               balance benchmark harness → engine
  season-harness          multi-season invariant gate → domain, ofm_core
```

Two things about this graph are worth stating plainly, because both have been documented backwards
before:

- **`engine` and `domain` are independent leaves.** Neither depends on anything else in the
  workspace — `engine`'s only dependencies are `log`, `rand` and `serde`. `engine` in particular
  does *not* sit on `domain`; see "Engine Isolation" below for why that is deliberate.
- **`db` depends on `ofm_core`, not the other way round.** Persistence sits *above* game logic
  here. That is a layering inversion against how the crates are usually described, and it is
  recorded because it is true, not because it is the intended design.

### `domain` — Pure Data Types

Contains only structs and enums with no game logic. All other crates depend on it.

- **`player.rs`** — `Player`, `PlayerAttributes` (19 attributes), `Position`, `PlayerTrait` (20 traits), `PlayerSeasonStats`, `Injury`, `TransferOffer`
- **`team.rs`** — `Team`, `PlayStyle`, `TrainingFocus`, `TrainingIntensity`, `TrainingSchedule`, `TeamColors`
- **`staff.rs`** — `Staff`, `StaffRole` (4 roles), `CoachingSpecialization` (7 specializations), `StaffAttributes`
- **`manager.rs`** — `Manager`, `ManagerCareerStats`, `ManagerCareerEntry`
- **`league.rs`** — `League`, `Fixture`, `StandingEntry`, `MatchResult`, `GoalEvent`
- **`message.rs`** — `InboxMessage`, `MessageCategory` (15 categories), `MessagePriority`, `MessageAction`, `ActionType`
- **`news.rs`** — `NewsArticle`, `NewsCategory` (8 categories), `NewsMatchScore`

**Design decision**: Domain types use `#[serde(default)]` extensively on newer fields for backward compatibility with old save files.

### `engine` — Match Simulation

Self-contained simulation engine, deliberately **decoupled from `domain`**. Defines its own mirror types (`PlayerData`, `TeamData`, `Position`, `PlayStyle`) so it can be tested and evolved independently.

See [MATCH_SIMULATION.md](MATCH_SIMULATION.md) for full details.

- **`engine.rs`** — Instant full-match simulation (`simulate()`, `simulate_with_rng()`). Reached only by the tools now — `sim-bench` and the `sim_lab` command — since every fixture in an actively simulated competition goes through `live_match`
- **`live_match.rs`** — Step-by-step `LiveMatchState` with phase management, commands, substitutions. The path every match in an active competition takes, watched or not. Dormant competitions and national-team fixtures use their own cheaper models
- **`ai.rs`** — AI manager decisions (`AiProfile`, `ai_decide()`)
- **`types.rs`** — Engine-specific data types and `MatchConfig`
- **`event.rs`** — `MatchEvent` + `EventType` (22 variants)
- **`report.rs`** — `MatchReport`, `TeamStats`, `PlayerMatchStats`, `GoalDetail`

### `ofm_core` — Game Logic

The core game loop — ties domain, engine, and all game systems together.

- **`game.rs`** — `Game` struct (the root game state: clock, manager, teams, players, staff, messages, news, league)
- **`clock.rs`** — `GameClock` with date tracking and day advancement
- **`state.rs`** — `StateManager` with `Mutex<Option<Game>>` and `Mutex<Option<LiveMatchSession>>` for thread-safe Tauri access
- **`turn.rs`** — Day processing: match simulation, domain↔engine conversion, stats application, news generation
- **`training.rs`** — Training system: attribute gains, condition management, staff bonuses, fitness warnings
- **`schedule.rs`** — Round-robin league schedule generation (circle method)
- **`generator.rs`** — World generation: name/team definition loading, player/staff/team creation
- **`live_match_manager.rs`** — `LiveMatchSession` wrapping the engine's `LiveMatchState` with RNG, AI profiles
- **`messages.rs`** — Inbox message generation (welcome, match previews/results, board directives, etc.)
- **`job_offers.rs`** — Vacancy-backed job opportunities, direct applications, offer responses, and offer expiry
- **`firing.rs`** — Board warning/firing flow and managerial-change dismissal news
- **`ai_hiring.rs`** — AI manager seeding, vacancy aging, and delayed replacement hires
- **`board_objectives.rs`** — Board objective messages and objective tracking
- **`news.rs`** — News article generation (match reports, league roundups, standings, season previews, managerial appointments)

### `db` — Persistence

Save/load functionality:

- **`save_manager.rs`** — Save slot orchestration, load/save flows, and round-trip tests
- **`game_persistence.rs`** — `Game` serialization/deserialization between runtime state and storage records
- **`repositories/`** — SQLite repositories for saves, metadata, news, and related persistence records
- Persistence policy: repository queries use static SQL with bound parameters for runtime values, and save writes are committed transactionally to avoid partial persistence.

---

## State Management

### Backend State

The `StateManager` (in `ofm_core/state.rs`) holds the active game and live match session behind `Mutex` locks:

```rust
pub struct StateManager {
    pub active_game: Mutex<Option<Game>>,
    pub live_match: Mutex<Option<LiveMatchSession>>,
}
```

This is registered as Tauri managed state and accessed by all commands via `State<StateManager>`.

**Key pattern**: Commands acquire the mutex, clone the `Game` for return, and release the lock. Mutations happen inside the lock scope.

### Screen writes and the career check

A request a screen sends can arrive after another career has been installed (a load, a new game,
an agent switching careers). So every screen command that changes the active game carries the
career token the screen was given, and the check is made **inside the write**:

- `Game::career_token` is stamped by `install_career` (from `StateManager::next_career_token`, never
  repeated, never 0) and travels to the screen with the game. It is not saved. A live match carries
  its career's token too (`LiveMatchSession::career_token`).
- `ofm_core::state::Career` is `Active` (an agent or in-process caller acting on whichever career is
  open) or `Token(u64)` (a screen). `StateManager::update_game_for(career, f)` runs `f` only if the
  token is the active game's, under the same lock, and otherwise returns `be.error.careerChanged`.
  `mutate_active_game_for` (commands) and `persist_active_game` take a `Career` the same way.
- Screen commands take `career_token: u64` and pass `Career::Token(..)`. **MCP tools pass
  `Career::Active`**: an agent acts on the active career by definition and holds no token.
- On the frontend `invokeForCareer` (`src/services/careerInvoke.ts`) adds `careerToken` from the
  store's game to every command in `SCREEN_WRITE_COMMANDS`.

Enforced by tests, not convention: `src-tauri/tests/screen_writes.rs` fails if production code calls
`update_game`, `set_game` or `clear_game` outside the two places that install or close a career,
or if a `#[tauri::command]` writes for `Career::Active`; and
`src/services/careerInvoke.architecture.test.ts` fails if the TypeScript list differs from the Rust
commands that take a `career_token`, or if any source calls one of them with a bare `invoke`.

### Frontend State

Two Zustand stores:

- **`gameStore`** — Active game state (`GameStateData`), manager info, `hasActiveGame` flag. Updated after every Tauri command that returns game state.
- **`settingsStore`** — `AppSettings` (theme, language, currency, match preferences). Loaded once on Settings page mount, persisted via Tauri commands.

---

## Tauri Command Interface (IPC)

All frontend↔backend communication goes through Tauri's `invoke()` mechanism. Commands are defined in `src-tauri/src/lib.rs` and registered in the Tauri builder.

### Game Lifecycle Commands

| Command | Parameters | Returns | Description |
|---------|-----------|---------|-------------|
| `list_world_databases` | — | `Vec<WorldDatabaseInfo>` | Scan for available world databases |
| `start_new_game` | first_name, last_name, dob?, nationality, startup_options?, world_source?, package_ids? | `Game` | Create game, generate or load world. `dob` is optional: the create-manager form no longer asks for one, and an omitted (or empty) value derives a manager exactly 45 years old on the day the career opens. An explicit `dob` is still parsed and age-checked against that opening date, so older callers keep their behaviour |
| `validate_manager_dob` | dob, start_year, start_phase | `Option<String>` | The translation key of what is wrong with a manager's date of birth on the day a generated-world career opens (1 June in a World Cup summer, else 1 July, plus 120 days mid-season), or null. The same age rule `start_new_game` applies. Retained for callers that still collect a birth date; the create-manager form no longer calls it. A historical package can set its own opening date, so `start_new_game` still has the last word |
| `choose_team` | team_id | `Game` | Assign manager to a team |
| `get_active_game` | — | `GameStateData` | Get current game state |
| `get_career_stage` | — | `awaitingClub` \| `unemployed` \| `employed` | Decided in Rust (`career_stage`): a manager with no club who has never held one is awaiting a club, so the menu and dashboard send them to team selection; a sacked manager stays on the dashboard |
| `advance_time` | — | `Game` | Advance one day |
| `advance_time_with_mode` | mode | `{action, game?, snapshot?}` | Advance with match mode preference |
| `skip_to_match_day` | — | `Game` | Fast-forward to next fixture |
| `save_game` | — | — | Persist current game |
| `load_game` | save_id | — | Load a saved game |
| `exit_to_menu` | — | — | Save and clear active game |

### Match Commands

| Command | Parameters | Returns | Description |
|---------|-----------|---------|-------------|
| `start_live_match` | fixture_index, mode, allows_extra_time | `MatchSnapshot` | Initialize a live match session |
| `step_live_match` | minutes | `Vec<MinuteResult>` | Advance simulation by N minutes |
| `apply_match_command` | command | `MatchSnapshot` | Send a tactical command |
| `get_match_snapshot` | — | `MatchSnapshot` | Get current match state |
| `finish_live_match` | — | `Game` | Apply results and clean up |

### Team Management Commands

| Command | Parameters | Returns | Description |
|---------|-----------|---------|-------------|
| `get_club_league_standing` | team_id | The club's league table, position and standing, or null | Any club, not only the manager's; in a split season the half the year is on; cups have no table |
| `get_team_card` | team_id | The club's card from the clubs directory (`slices::teams::query_team_card`), or null for an id no club has | `avg_ovr` is null for a club outside the manager's division (`KnowledgeView::knows_squad_at`), so the team profile and the directory show the same average or the same "–" |
| `get_team_selection_ratings` | — | Every club's squad, best rated first, with its average by the club card's rule (`slices::team_selection`) | Only before a career begins (no club, no career behind him); an empty list once one has, when the knowledge rule decides what the manager sees |
| `get_scouted_report` | player_id | The scout's dated attribute snapshot with `out_of_date`, or null | Out of date means scouted before the last season rollover (`Game::last_season_rollover_on`), when every player aged and the season's growth applied; decided in Rust |
| `get_player_knowledge` | player_ids | Per player: `own`, `known` (a club in the manager's division), `scouted` (with `scouted_on` and `current`) or `unknown` (a player the club has not scouted); an id that matches no player is omitted from the answer | The one rule for what the manager's club knows about a player (`ofm_core::player_knowledge`); screens hide what it does not know. The serialized `Game` still carries every value |
| `get_visible_wage` | player_id | `exact` (the club's own player), `approximate` (a scouted player: two significant figures) or `hidden`, each with `weekly` where shown; null for an id no player has | `ofm_core::player_knowledge::visible_wage`; for one player's profile only, never a list |
| `get_potential_opinion` | player_id | The club's opinion of his potential: `low`–`high` (a range that held the true value on the day it was formed: today for the coaches, the report's day for a scout), `band` (the tier of its middle), `certainty` (`confident`, `fairly_sure`, `unsure`, `guess`: the judge's eye, read off the range's width) and `source` (`scout` with `scout_name`, `scouted_on` and `current`: false for a report from before the last season end, shown as an old report; or `coaches`); null when the club holds none | `ofm_core::player_knowledge::potential_opinion`: the coaches' live opinion of a player who has trained with the club for 42 days, otherwise the range a scout wrote into his report (v062). Never the true potential, and never on a list |
| `get_youth_prospect_opinions` | message_id | The reporting scout's opinion of each prospect in a youth scouting report, by prospect id, in `get_potential_opinion`'s shape (always a `scout` source); empty for a report written before reports carried opinions | `ofm_core::player_knowledge::youth_prospect_opinions`: the range the scout gave each prospect when the report was written (`MessageContext.youth_prospect_opinions`), read as a scout report. Signing a prospect hands the same opinion to his scout report |
| `get_position_ratings` | player_id | What he is worth at each position he plays: `source` (`live`, or `report` with `scouted_on` and `current`) and `rows` of `position`, `rating`, `familiarity` (`natural`, `can_play`, `out_of_position`), `deployed` and `key_attributes` (`attribute`, `value`): natural first, then alternates, then (own player only) the slot he is played in; null for a player the club knows nothing of | `ofm_core::position_ratings::position_ratings`, through the knowledge rule: live attributes for the club's own player and a division rival, the report's for a scouted one. The key attributes are `player_rating::key_attributes`, the list the rating's critical penalty reads. No "fit" verdict (maintainer, 21 Oct) |
| `get_familiarity` | (none) | How each of the manager's club's players stands at every position: `players` of `player_id` and `by_position`, a map from the 17 position names to `natural`, `can_play` or `out_of_position`. Only the club's own players; no club is `be.error.noTeamAssigned` | `ofm_core::familiarity_projection::familiarity_projection`, which calls `player_rating::familiarity` for each (player, position): no screen reads it yet: the squad and tactics screens still grade locally, and slices 2-4 of #589 connect them (slice 4 rewrites this row) |
| `get_manager_standing` | (none) | `board` (`very_pleased`, `satisfied`, `concerned`, `under_threat`) `fans` (`adore`, `behind`, `mixed`, `restless`, `unrest`) and `warning` (`none`, `warned`, `final_warning`: the board's warning on record, which lapses once the board is satisfied again, at 50, the same constant as the `satisfied` band) for the user's manager | `ofm_core::manager_standing`: the board is under threat at or below `firing`'s warning threshold (25), where the board actually warns; the Manager tab shows these words instead of picking them from the numbers |
| `get_managers_page` | status (`all`, `employed`, `unemployed`) | `managers`: every active manager (`id`, `display_name`, `nationality`, `club` `{id, name}` or null, `interim`, `reputation` `{value, band, tone}`, `record` `{matches, trophies}`), by club name then name, those between jobs last; `vacancies`: every club with no manager (`club_id`, `club_name`, `club_reputation`) | `ofm_core::slices::managers::query_managers_page`. The band is `manager_reputation::ReputationBand` (seven words: World class ≥670, Established, Great, Good, Average, Below average, Unknown <250) and its `RatedTone`; managers retired into the archive are not listed. The record is public, so there is no knowledge gate |
| `get_squad` | team_id | Player rows with `match_day_eligible` | Complete club roster with computed match-day eligibility; youth call-ups retain their academy role |
| `set_formation` | formation | `Game` | Change team formation |
| `set_play_style` | play_style | `Game` | Change play style |
| `apply_tactic_preset` | formation, play_style | `Game` | Pick a tactic preset: formation + play style, and reset the phase blueprint to that style's default |
| `list_custom_tactics` | - | `CustomTactic[]` | The tactics the player saved (career-scoped, in the save) |
| `save_custom_tactic` | tactic, careerToken | `CustomTactic[]` | Add a saved tactic, or replace the one with the same id; returns the library |
| `save_current_tactic` | tactic, careerToken | `CustomTactic[]` | Save the team's tactic as it stands, whole (#1189: formation, style, every instruction, the eleven slot by slot with their roles, the set-piece takers), under the draft's id and name; returns the library |
| `apply_custom_tactic` | id, careerToken | `Game` | Put a saved tactic on the team: its formation and style, and for a tactic that holds them its instructions, eleven, roles and takers. A player who has left gives his slot and his armband back to the team's current choice |
| `rename_custom_tactic` | id, name, careerToken | `CustomTactic[]` | Rename a saved tactic, keeping all it holds; returns the library |
| `delete_custom_tactic` | id, careerToken | `CustomTactic[]` | Remove a saved tactic; returns what is left. Every write here is refused with `be.error.careerChanged` when `careerToken` (`Game.career_token`, stamped by `install_career`) is not the active career's |
| `legacy_tactics_import_pending` | - | `bool` | Whether the old browser library still has to be copied into this career |
| `mark_legacy_tactics_imported` | careerToken | - | Record that it has been copied in; it never is again |
| `get_tactics_blueprint_status` | — | `{ modified }` | Whether the user's phase dials differ from the blueprint their play style implies (`blueprint_for`); feeds the Tactics unsaved-changes badge |
| `set_training` | focus, intensity | `Game` | Set training focus and intensity |
| `set_training_schedule` | schedule | `Game` | Set weekly training schedule |
| `get_training_focus_attributes` | - | `TrainingFocusAttributes[]` | Which attributes each training focus trains, for outfield players and for goalkeepers; the same table the daily gains use |
| `get_position_groups` | - | `{ position, group }[]` (17 entries) | The group (`Goalkeeper`, `Defender`, `Midfielder`, `Forward`) of every position, from `ofm_core::position_group` over `Position::to_group_position`, the one rule. Needs no game; feeds `PositionBadge`'s tone through `usePositionGroups` |
| `get_rating_tiers` | - | `PlayerTier[]` (100 entries) | The tier (`S` 81+, `A` 77-80, `B` 70-76, `Rest`) of every rating from 0 to 99, from `ofm_core::player_tier`, the one rule. Needs no game, so the package editor reads it too; the frontend colours a rating by looking it up (`useRatingTiers`) |
| `get_hall_of_fame_legends` | - | `HallOfFameLegend[]` | The retired players of the world's archive, ranked by league titles, appearances, goals, then name. A title is a season at a club that won its country's top flight (`ofm_core::hall_of_fame`); a record with a blank or unresolvable `competition_id` keeps the old reading, first place |
| `get_hall_of_fame_champions` | - | `PastChampion[]` | Every league title in the world's past, latest season first, then more wins, then club name. A title is first place in tier 0 of the country's ladder (`ofm_core::hall_of_fame`); a record with a blank or unresolvable `competition_id` keeps the old reading, first place |
| `get_retired_player` | player_id | `Player` | A retiree's profile, read from the archive |
| `get_free_agent_opening_offer` | player_id | `{ weekly_wage, contract_years }` | The terms the contract form opens on for a free agent: the wage he expects from the manager's club, for the years a player his age expects (`expected_wage` and `expected_contract_years` in `ofm_core::contracts`). Never under the wage that would insult him; the manager may still offer less. Rejects a player at a club, a retired one, an unknown id, or a manager with no club |
| `hire_staff` | staff_id | `Game` | Hire an unattached staff member |
| `release_staff` | staff_id | `Game` | Release a staff member |

### Manager Profile Commands

Reusable manager identities, stored in `profiles.json` in the app data directory. The new-game
wizard fills its name and nationality fields from one of these.

| Command | Parameters | Returns | Description |
|---------|-----------|---------|-------------|
| `get_manager_profiles` | — | `Vec<ManagerProfile>` | Every saved identity, most recently used first |
| `save_manager_profile` | first_name, last_name, dob?, nationality, force? | `ManagerProfile` | Save an identity. An existing one with the same name, birth date and nationality is reused and touched rather than duplicated; `force` skips that dedup. With `dob` omitted, an existing identity's stored date is reused, else a placeholder is stored — the career derives the playable age itself |
| `update_manager_profile` | id, first_name, last_name, dob?, nationality | `Option<ManagerProfile>` | Edit an identity in place, keeping its id and `created_at`. An omitted `dob` preserves the stored date, so the wizard cannot erase a field it no longer shows |
| `delete_manager_profile` | id | `bool` | Remove an identity |
| `touch_manager_profile` | id | `bool` | Record that an identity was just used, which orders the list |

### Settings Commands

| Command | Parameters | Returns | Description |
|---------|-----------|---------|-------------|
| `get_settings` | — | `AppSettings` | Load settings from disk. Includes `ui_density` (`comfortable` \| `compact`), which defaults on read so settings files written before it existed still load |
| `save_settings` | settings | — | Persist settings |
| `clear_all_saves` | — | — | Delete all save files |
| `export_world_database` | export_path | `String` | Export world to JSON |
| `collect_diagnostics` | — | `DiagnosticsReport` | App version, platform and webview, for a bug report |
| `export_report_bundle` | output_path, report_text, include_save | `BundleSummary` | Write the redacted report bundle where the player chose |
| `redact_report_fields` | values | `Vec<String>` | Redact free text for anything leaving outside the bundle |
| `suggested_report_file_name` | — | `String` | Dated default name for the save dialog |
| `report_upload_available` | — | `bool` | Whether OFMHub takes reports right now: reads its `/bug-reports/config` (the kill switch). Debug builds honour `OFM_BUG_REPORT_URL` |
| `upload_report_bundle` | request (`reportText`, `fields`, `includeSave`, `consent`, `screenshotPaths`, `packagePaths`) | `UploadReceipt` | With consent, build the bundle privately and send it to OFMHub as multipart ([contract](api/bug-reports.md)); a retry with the same request resends the first build's bytes; records the reference. Rejects with `{kind, key, retry_after_seconds}` |
| `discard_prepared_report` | — | — | The report dialog is gone: remove the held build (which may contain the save). A stale `ofm-upload-*` folder in the cache dir is also swept at startup |
| `list_submitted_reports` | — | `Vec<SubmittedReport>` | Reference codes from `reports.json`, newest first |
| `crash_notice` | — | `Option<CrashNotice>` | When the last session crashed (time and version only), until the player answers the launch prompt |
| `dismiss_crash_notice` | — | — | The launch crash prompt was answered; not offered again this launch |

---

## Data Flow

### New Game Flow

```
MainMenu → Create Manager → Choose World → Choose Team → Dashboard
    │              │               │              │
    │         form input     generate_world   choose_team
    │                        or load JSON      command
    │                             │              │
    │                        ┌────┴────┐    ┌────┴────┐
    │                        │Generator│    │  Game   │
    │                        │  +JSON  │    │ created │
    │                        └─────────┘    └─────────┘
```

### Daily Turn Flow

```
Dashboard → "Continue" button → advance_time_with_mode
                                        │
                           ┌────────────┼────────────┐
                           │            │            │
                      No match     Live match    Delegate
                           │            │            │
                    process_day()  start_live    simulate
                           │       _match()     instantly
                    ┌──────┴──────┐     │            │
                    │ Training    │  Navigate     apply
                    │ + Recovery  │  to /match    results
                    │ + Messages  │     │            │
                    │ + Clock++   │  [interactive]   │
                    └─────────────┘     │      ┌─────┴─────┐
                                   finish_live  Return to
                                   _match()     Dashboard
                                        │
                                   apply results
                                   + news + clock
```

---

## Frontend Architecture

### Routing

| Route | Component | Description |
|-------|-----------|-------------|
| `/` | `MainMenu` | Main menu with new/load/settings |
| `/team-selection` | `TeamSelection` | Choose club to manage |
| `/dashboard` | `Dashboard` | Main game interface |
| `/match` | `MatchSimulation` | Live match simulation |
| `/settings` | `Settings` | App settings |

### Dashboard Component Architecture

The Dashboard is a slim layout shell (~524 lines) with a sidebar, header, and content area. Content is rendered by tab-specific components:

```
Dashboard.tsx (layout shell)
├── Sidebar: NavItem buttons for each tab
├── Header: Back button, tab title, date, search, finances, Continue
└── Content area (conditional rendering by activeTab):
    ├── HomeTab         — Overview, next match, standings, squad summary
    ├── InboxTab        — Two-pane email client with categories
    ├── ManagerTab      — Manager profile, career stats
    ├── SquadTab        — Player roster table
    ├── TacticsTab      — Formation picker, pitch visualization
    ├── TrainingTab     — Focus/intensity/schedule selection, fitness
    ├── StaffTab        — Staff management (hire/release)
    ├── FinancesTab     — Financial overview
    ├── TransfersTab    — Transfer market with 4 views
    ├── PlayersListTab  — Full player database browser
    ├── TeamsListTab    — All teams grid
    ├── TournamentsTab  — League standings and fixtures
    ├── ScheduleTab     — Calendar of fixtures
    ├── NewsTab         — News feed
    ├── PlayerProfile   — Detailed player view (inline)
    └── TeamProfile     — Detailed team view (inline)
```

**Navigation history**: The Dashboard maintains a `navHistory` stack for back navigation when drilling into player/team profiles from any tab.

### Match Day Components

The match simulation uses a multi-stage orchestrator:

```
MatchSimulation.tsx (orchestrator)
├── PreMatchSetup    — Team sheet, formation, set pieces
├── MatchLive        — Live simulation with events, stats, controls
├── HalfTimeBreak    — Team talk, tactical changes
├── PostMatchScreen  — Result summary, scorers, team talk
└── PressConference  — Post-match press questions
```

Flow: `prematch → first_half → halftime → second_half → postmatch → press`

### Design Language

The UI follows a **"Matchday" broadcast-quality** design language:

- **Colors**: Emerald green primary (#10b981), gold accent (#ffd60a), dark navy backgrounds
- **Typography**: Barlow Condensed (headings, uppercase tracking) + Inter (body)
- **Fonts**: Bundled locally via `@fontsource` packages (no CDN). Inter covers Latin, Latin-ext and Cyrillic; Barlow Condensed has no Cyrillic, so headings fall back to Fira Sans Extra Condensed for Russian, which `src/i18n/fontCoverage.test.ts` pins. Chinese is not bundled: it falls through to the system CJK face.
- **Dark/Light**: Full theme support with system detection

---

## Key Architectural Decisions

### 1. Engine Isolation

The `engine` crate has **no dependency on `domain`**. It defines its own `PlayerData`, `TeamData`, etc. This means:
- The engine can be tested with synthetic data (no need to generate full game worlds)
- Engine types can evolve independently (e.g., adding engine-only fields)
- The `turn.rs` bridge in `ofm_core` handles all type conversion

### 2. `#[serde(default)]` for Backward Compatibility

Every new field added to domain types uses `#[serde(default)]` or a custom default function. This ensures old save files can be loaded without migration scripts. The trade-off is that new features gracefully degrade (e.g., old saves have no traits, empty training schedules) rather than failing.

### 3. Generation Data Lives in Files, Not Rust

Generator definition files (`default_names.json`, `default_nations.json`) live in
`crates/ofm_core/data/` and are resolved through three tiers: the user's
`<app-data>/data/` directory, then the copy bundled beside the installed game,
then the same files compiled in with `include_str!`. This means:
- Users can customize by placing a definition file in their data directory — the
  documented behaviour, which for a long time was documented but not implemented
- The game always works, even from an incomplete install or a dev build with no
  bundled resources
- **There is one copy of the data.** The embedded tier is the *same file* as the
  bundled one, so the compiled-in fallback cannot drift from what ships — which
  is what happened when the fallback was a separate hand-maintained Rust array

Definition files configure *generation*. Hand-authored content — specific clubs,
players, competitions — belongs in `.ofm` packages instead, which merge and
stack. See [DEFINITIONS.md](DEFINITIONS.md).

### 4. Mutex-Based State Management

The backend uses `Mutex<Option<Game>>` rather than `RwLock` or actor patterns. This is simpler and sufficient because:
- Only one game is active at a time
- Commands are sequential from the UI perspective
- Lock contention is negligible (commands are fast)

### 5. `PlayerSnap` Pattern in Engine

The engine uses a "snapshot" pattern (`PlayerSnap`) to work around Rust's borrow checker. Before resolving an action, it clones the relevant player data into a lightweight struct, releasing the immutable borrow on `MatchContext`. This allows event emission (which needs `&mut self`) to happen in the same function.

### 6. Football Identity Codes

The game now distinguishes between general country data and football-facing identity data.
Most countries still use ISO 3166-1 alpha-2 codes (for example, `"ES"`, `"DE"`, `"BR"`), but football-specific identities can use project-owned short codes where the sport diverges from ISO country data, such as `"ENG"`, `"SCO"`, `"WAL"`, and `"NIR"`.

This enables:
- Locale-aware country and football-nation display
- Backward compatibility for legacy demonyms and `GB` saves
- Correct modeling of football nations without forcing a full non-ISO rewrite for the rest of the world

### 7. Frontend Tab Architecture

The Dashboard uses conditional rendering (not routing) for tabs. This means:
- Tab state is preserved when switching between tabs
- No URL changes for tab navigation (clean URLs)
- Profile views (player/team) overlay on top of the current tab with a back-navigation stack

---

## Modding System

OpenFoot Manager supports user-created content through the `.ofm` package format. Packages are ZIP archives containing JSON/YAML entity files and optional image assets.

### Package Loading Pipeline

```
packages/ directory
    │
    ▼
list_world_databases (scan for .ofm files)
    │
    ▼
load_world_package_from_ofm (extract + validate archive)
  or load_world_package (directory)
    │
    ├── load_world_package_files()
    │     Walk recursively → classify by "schema" field
    │     → Parse entity structs → check id uniqueness
    │
    └── Cross-reference validation
          countries → confederations
          teams → countries
          players → teams + countries
          competitions → teams, countries, regions, selector sources
    │
    ▼
merge_world_packages (multiple packages: last-wins by id)
    │
    ▼
Game world (passed to world generator)
```

`ofm_core::generator::package` is the authoritative validator — the same code path runs in the game, the CLI, and the Package Editor Tauri commands.

### `ofm-cli` Binary Crate

`src-tauri/crates/ofm-cli/` is a standalone binary crate that statically links `ofm_core`. It is **not** part of the Tauri app; it compiles to an independent executable.

```
ofm-cli
  └── ofm_core  (shared library: package loading, validation, export)
```

This means CLI validation results are guaranteed to match in-game validation results — they use the same code.

### Package Editor Tauri Commands

Four commands in `src-tauri/src/commands/package_editor.rs` expose package authoring to the React frontend:

| Command | What it does |
|---------|-------------|
| `create_package_project` | `mkdir` + write `package.json` manifest + empty stub files for each entity type |
| `read_package_project` | `load_world_package(dir)` → return `PackageProjectData` (meta, confederations, countries, teams, players, names, competitions, issues) |
| `save_package_project` | Atomically overwrite all entity files: `package.json`, `confederations/`, `countries/`, `teams/`, `players/`, `names/`, `competitions/` (write to temp → rename) |
| `build_ofm` | Save → validate → `export_directory_to_ofm(dir, output)` |

All entity types (`WorldMetaDef`, `ConfederationDef`, `CountryDef`, `TeamDef`, `PlayerDef`, `NamesDefinition`, `CompetitionDefinition`) are passed directly through Tauri's invoke boundary — they are the same types `ofm_core` uses internally, so no translation layer is needed.

### `.ofm` Archive Format

- Standard ZIP with deflate compression
- Size limits: 256 MB compressed, 1 GB uncompressed, 10,000 files
- Security: paths validated against zip-slip attacks and symlinks
- `read_package_manifest_from_ofm()` reads only `package.json` without full extraction (used by `ofm-cli info` and the world selector)
