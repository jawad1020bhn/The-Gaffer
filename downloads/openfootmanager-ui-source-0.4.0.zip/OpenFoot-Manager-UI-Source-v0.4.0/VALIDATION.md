# UI source archive validation

Validated on 2026-11-08 against source commit
`b38e5043e3321d9ae6e7399ae9bdbd184aaecc1d`.

## Passed

- **Source integrity:** all 1,171 selected source/support files were checked
  against their recorded SHA-256 hashes and match the repository byte for byte.
- **Frontend coverage:** all 1,064 tracked files under `src/` are included,
  including every one of the 305 non-test `.tsx` files and all 12 locale JSON
  files. All five tracked `public/` assets are included.
- **Dependency installation:** `npm ci --ignore-scripts --no-audit --fund=false`
  completed successfully in an isolated copy, installing 236 packages from the
  included lockfile. Environment: Node.js 22.22.3, npm 10.9.8, Linux.
- **Targeted UI checks:** 4 test files, 49 tests passed:
  - `src/dev/styleGuide/StyleGuide.test.tsx`: 8 tests, including rendering every
    section without a backend.
  - `src/designSystem.test.ts`: 34 tests.
  - `src/context/ThemeContext.test.tsx`: 5 tests.
  - `src/lib/uiDensity.test.ts`: 2 tests.
- **Development entry:** Vite served the style-guide HTML, its main module,
  `StyleGuide.tsx`, compiled `App.css`, the i18n loader and English/French locale
  modules with HTTP 200. The transformed i18n loader referenced all 12 locales.
  The temporary validation server was stopped afterward.

The passing style-guide tests emitted caught warnings about loading position
groups without Tauri. This is expected outside the desktop shell and did not
cause test failures. HTTP checks are not a browser screenshot or layout audit.

## Deliberate limitations / not validated

- **Not a full application build.** The Rust implementation, full Tauri build
  environment, optional game databases and CI files are outside this UI source
  archive. Full-game compilation and gameplay were not tested here.
- **Generated fixture absent.** `src/dev/pageHarness/fixture.generated.ts` is not
  tracked in the source repository. The full build/test pre-hook generates it
  using Rust. The page harness and tests depending on that career cannot run
  from this subset alone.
- A production build of the shared style-guide entry was attempted with the
  Vite build API and failed at the expected unresolved `./fixture.generated`
  import in `src/dev/pageHarness/mount.tsx`. The development style-guide route
  and its backend-free rendering tests passed; no production style-guide build
  is claimed.
- `src/designTokens.test.ts` needs the generated fixture. Its nation colour
  palette input is included, but that test was not run.
- The complete test suite was not run. Some included architecture tests read
  excluded Rust sources or GitHub issue templates and need the full repository.
- No installed `node_modules` or build output is packaged. Fonts and other npm
  assets are supplied by the included package manifest and lockfile when
  dependencies are installed.

See `README.md` for the supported local preview and targeted test commands,
`UI_FILE_MAP.md` for every included file, and `SOURCE_MANIFEST.json` for
per-file provenance and hashes.